import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart' show kReleaseMode, debugPrint;
import 'package:lottie/lottie.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:crypto/crypto.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:webview_flutter/webview_flutter.dart' hide X509Certificate;
import 'package:audioplayers/audioplayers.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await AppRemoteConfig.instance.init();
  runApp(const MyApp());
}

// ========== REAL-TIME NETWORK LATENCY TRACKER ==========
class LatencyTracker {
  static final ValueNotifier<int> pingMs = ValueNotifier<int>(24);
  static final ValueNotifier<String> serverStatus = ValueNotifier<String>('ONLINE');
  static final ValueNotifier<int> jitterMs = ValueNotifier<int>(2);
  static Timer? _pingTimer;
  static bool _initialized = false;
  static int _prevPing = 24;

  static void init() {
    if (_initialized) return;
    _initialized = true;
    _measurePing();
    _pingTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      _measurePing();
    });
  }

  static void dispose() {
    _pingTimer?.cancel();
    _initialized = false;
  }

  static Future<void> _measurePing() async {
    final Stopwatch sw = Stopwatch()..start();
    try {
      final http.Response res = await SecureHttp.client.head(
        Uri.parse(ApiEndpoints.updateUrl),
        headers: {
          SecureStringVault.hdrHandshake: SecureStringVault.valHandshake,
        },
      ).timeout(const Duration(seconds: 3));
      sw.stop();
      if (res.statusCode == 200 || res.statusCode == 304 || res.statusCode == 404) {
        final int elapsed = sw.elapsedMilliseconds.clamp(8, 999);
        jitterMs.value = (elapsed - _prevPing).abs();
        _prevPing = elapsed;
        pingMs.value = elapsed;
        serverStatus.value = 'ONLINE';
      }
    } catch (_) {
      sw.stop();
      if (sw.elapsedMilliseconds > 0) {
        final int fallback = (sw.elapsedMilliseconds > 3000 ? 140 : sw.elapsedMilliseconds).clamp(12, 450);
        pingMs.value = fallback;
        serverStatus.value = fallback > 250 ? 'HIGH PING' : 'ONLINE';
      } else {
        serverStatus.value = 'RETRYING';
      }
    }
  }

  static Future<void> measurePing() => _measurePing();

  static Color getLatencyColor(int ms, bool isDark) {
    if (ms <= 50) return isDark ? const Color(0xFF00FF87) : const Color(0xFF059669);
    if (ms <= 110) return isDark ? const Color(0xFF00E5FF) : const Color(0xFF0284C7);
    if (ms <= 180) return isDark ? const Color(0xFFF59E0B) : const Color(0xFFD97706);
    return isDark ? const Color(0xFFEF4444) : const Color(0xFFDC2626);
  }

  static String getQualityText(int ms) {
    if (ms <= 50) return 'EXCELLENT';
    if (ms <= 110) return 'GOOD';
    if (ms <= 180) return 'NORMAL';
    return 'HIGH PING';
  }
}

// ========== MAIN APP ROOT ==========
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  bool _isMaintenance = false;
  bool _isUpdateAvailable = false;
  Map<String, dynamic>? _maintenanceData;
  Map<String, dynamic>? _updateData;
  Map<String, dynamic>? _noticeData;
  Map<String, dynamic>? _announcementData;
  bool _statusChecked = false;
  bool _isConnected = true;
  final Connectivity _connectivity = Connectivity();
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  Timer? _statusCheckTimer;
  bool _isDialogActive = false;
  String _activeDialogType = '';
  bool _noticeShownThisSession = false;
  bool _announcementShownThisSession = false;

  BuildContext? get _dialogContext => _navigatorKey.currentContext;

  bool _isResultConnected(dynamic result) {
    if (result is List) {
      return result.isNotEmpty && result.any((r) => r != ConnectivityResult.none);
    } else if (result is ConnectivityResult) {
      return result != ConnectivityResult.none;
    }
    return true;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    _initConnectivity();
    LogoManager.init();
    LatencyTracker.init();
    
    _connectivity.onConnectivityChanged.listen((dynamic result) {
      _updateConnectionStatus(result);
    });
    
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final SecurityViolation? violation = await TamperDetection.checkSecurityViolation();
      if (violation != null && mounted) {
        await SessionManager.clearSession();
        SystemCrashLockdown.triggerCrash(
          title: violation.title,
          description: violation.description,
          threatCode: violation.threatCode,
        );
        return;
      }
      _checkAppStatus();
      _startAutoRefresh();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _statusCheckTimer?.cancel();
    LatencyTracker.dispose();
    super.dispose();
  }

  void _startAutoRefresh() {
    _statusCheckTimer?.cancel();
    _statusCheckTimer = Timer.periodic(const Duration(seconds: 10), (Timer timer) async {
      if (mounted && _isConnected) {
        final SecurityViolation? violation = await TamperDetection.checkSecurityViolation();
        if (violation != null && mounted) {
          await SessionManager.clearSession();
          SystemCrashLockdown.triggerCrash(
            title: violation.title,
            description: violation.description,
            threatCode: violation.threatCode,
          );
          return;
        }
        _checkAppStatus();
      }
    });
  }


  Future<void> _initConnectivity() async {
    try {
      final dynamic result = await _connectivity.checkConnectivity();
      _updateConnectionStatus(result);
    } catch (e) {
      if (mounted) {
        setState(() {
          _isConnected = false;
        });
      }
    }
  }

  void _updateConnectionStatus(dynamic result) {
    final bool wasConnected = _isConnected;
    final bool isNowConnected = _isResultConnected(result);
    if (!mounted) return;
    
    setState(() {
      _isConnected = isNowConnected;
    });

    if (!wasConnected && _isConnected) {
      _showReconnectDialog();
      _startAutoRefresh();
      LatencyTracker._measurePing();
    }
  }

  void _showReconnectDialog() {
    if (!mounted || _dialogContext == null) return;
    CyberAnimatedDialog.showSuccess(
      _dialogContext!,
      title: 'CONNECTION RESTORED',
      message: 'Internet connection is active. System synchronization complete.',
      buttonText: 'CONTINUE NOW',
      onConfirm: () {
        _refreshAllData();
      },
    );
  }

  Future<void> _refreshAllData() async {
    if (!mounted) return;
    setState(() {
      _statusChecked = false;
    });
    await _checkAppStatus();
  }

  void _showNoInternetDialog() {
    if (!mounted || _dialogContext == null) return;
    CyberAnimatedDialog.showError(
      _dialogContext!,
      title: 'NO CONNECTION',
      message: 'Please check your Wi-Fi or mobile network and try again.',
      buttonText: 'RETRY CONNECTION',
      onConfirm: () {
        _refreshAllData();
      },
    );
  }

  Future<void> _checkConnectivityAndRetry() async {
    if (!mounted) return;

    try {
      final dynamic result = await _connectivity.checkConnectivity();
      final bool hasNet = _isResultConnected(result);
      if (hasNet) {
        if (mounted) {
          setState(() {
            _isConnected = true;
          });
          await _refreshAllData();
        }
      } else {
        if (mounted) {
          _showNoInternetDialog();
        }
      }
    } catch (e) {
      // Error handling
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkConnectivityAndRetry();
      LatencyTracker._measurePing();
    }
  }

  Future<void> _checkAppStatus() async {
    if (_statusChecked && !_isMaintenance && !_isUpdateAvailable) {
      await _checkForUpdate();
      return;
    }
    
    final dynamic connectivityResult = await _connectivity.checkConnectivity();
    if (!_isResultConnected(connectivityResult)) {
      if (mounted) {
        setState(() {
          _isConnected = false;
          _statusChecked = true;
        });
        _showNoInternetDialog();
      }
      return;
    }

    if (mounted) {
      setState(() {
        _isConnected = true;
        _statusChecked = false;
      });
    }

    try {
      await _checkForUpdate();

      final response = await SecureHttp.client.get(
        Uri.parse(ApiEndpoints.updateUrl),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final dynamic decoded = safeJsonDecode(response.body, context: "STATUS_CHECK");
        if (decoded is! Map<String, dynamic>) {
          secureLog("Status check payload structure was not Map");
          return;
        }
        final Map<String, dynamic> data = decoded;
        AppRemoteConfig.instance.updateFromMap(data);
        
        final bool newMaintenance = AppRemoteConfig.instance.isMaintenance;
        final Map<String, dynamic>? newMaintenanceData = data['maintenance'] is Map ? Map<String, dynamic>.from(data['maintenance']) : null;
        final Map<String, dynamic>? newNoticeData = data['notice'] is Map ? Map<String, dynamic>.from(data['notice']) : null;
        final Map<String, dynamic>? newAnnouncementData = data['announcement'] is Map ? Map<String, dynamic>.from(data['announcement']) : null;
        
        if (mounted) {
          setState(() {
            _isMaintenance = newMaintenance;
            _maintenanceData = newMaintenanceData;
            _noticeData = newNoticeData;
            _announcementData = newAnnouncementData;
            _statusChecked = true;
          });
        }

        if (_isMaintenance) {
          _showDialogIfNotActive('maintenance');
        } else if (_isUpdateAvailable && _updateData != null) {
          _showDialogIfNotActive('update');
        } else if (_announcementData != null &&
            _announcementData!['enabled'] == true &&
            !_announcementShownThisSession) {
          _showDialogIfNotActive('announcement');
        } else if (_noticeData != null &&
            _noticeData!['enabled'] == true &&
            !_noticeShownThisSession) {
          _showDialogIfNotActive('notice');
        } else {
          if (_isDialogActive && _dialogContext != null) {
            Navigator.of(_dialogContext!).pop();
          }
          _isDialogActive = false;
          _activeDialogType = '';
        }
      } else {
        secureLog("Status check returned status: ${response.statusCode}");
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _statusChecked = true;
        });
        secureLog("Status check error: $e");
        if (!_isConnected || e.toString().contains('SocketException') || e.toString().contains('No address associated with hostname')) {
          _showNoInternetDialog();
        }
      }
    }
  }

  void _showDialogIfNotActive(String dialogType) {
    if (_isDialogActive && _activeDialogType == dialogType) {
      return;
    }
    
    if (_isDialogActive) {
      if (_dialogContext != null) {
        Navigator.of(_dialogContext!).pop();
      }
      _isDialogActive = false;
      _activeDialogType = '';
      
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted) {
          _showDialogByType(dialogType);
        }
      });
    } else {
      _showDialogByType(dialogType);
    }
  }

  void _showDialogByType(String dialogType) {
    _isDialogActive = true;
    _activeDialogType = dialogType;
    
    switch (dialogType) {
      case 'maintenance':
        _showMaintenanceDialog();
        break;
      case 'update':
        _showUpdateDialog();
        break;
      case 'announcement':
        _showAnnouncementDialog();
        break;
      case 'notice':
        _showNoticeDialog();
        break;
    }
  }

  Future<void> _checkForUpdate() async {
    try {
      final PackageInfo packageInfo = await PackageInfo.fromPlatform();
      final String currentVersion = packageInfo.version;
      final int currentVersionCode = int.tryParse(packageInfo.buildNumber) ?? 1;

      final response = await SecureHttp.client.get(
        Uri.parse('${ApiEndpoints.updateCheckUrl}?version=$currentVersion&version_code=$currentVersionCode'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final dynamic decoded = safeJsonDecode(response.body);
        if (decoded is Map<String, dynamic> && decoded['status'] == true) {
          final Map<String, dynamic> data = decoded;
          final Map<String, dynamic> updateData = data['data'];
          final bool updateAvailable = updateData['update_available'] ?? false;
          
          if (mounted) {
            setState(() {
              _isUpdateAvailable = updateAvailable;
              if (updateAvailable) {
                _updateData = updateData;
              }
            });
          }
        }
      }
    } catch (e) {
      secureLog('Update check error: $e');
    }
  }


  void _showMaintenanceDialog() {
    if (_maintenanceData == null || !mounted || _dialogContext == null) return;
    
    showDialog(
      context: _dialogContext!,
      barrierDismissible: false,
      builder: (BuildContext context) => MaintenanceDialog(
        data: _maintenanceData!,
        onClose: () {
          _isDialogActive = false;
          _activeDialogType = '';
          SystemNavigator.pop();
        },
        onMaintenanceOver: () {
          if (_dialogContext != null) {
            Navigator.of(_dialogContext!).pop();
          }
          _isDialogActive = false;
          _activeDialogType = '';
          _refreshAllData();
        },
      ),
    );
  }

  void _showUpdateDialog() {
    if (_updateData == null || !mounted || _dialogContext == null) return;
    
    showDialog(
      context: _dialogContext!,
      barrierDismissible: false,
      builder: (BuildContext context) => UpdateDialog(
        data: _updateData!,
        onClose: () {
          _isDialogActive = false;
          _activeDialogType = '';
        },
      ),
    );
  }

  void _showNoticeDialog() {
    if (_noticeData == null || !mounted || _dialogContext == null) return;
    _noticeShownThisSession = true;

    showDialog(
      context: _dialogContext!,
      barrierDismissible: true,
      builder: (BuildContext context) => NoticeDialog(
        data: _noticeData!,
        onClose: () {
          _isDialogActive = false;
          _activeDialogType = '';
        },
      ),
    );
  }

  void _showAnnouncementDialog() {
    if (_announcementData == null || !mounted || _dialogContext == null) return;
    _announcementShownThisSession = true;

    showDialog(
      context: _dialogContext!,
      barrierDismissible: true,
      builder: (BuildContext context) => AnnouncementDialog(
        data: _announcementData!,
        onClose: () {
          _isDialogActive = false;
          _activeDialogType = '';
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<CrashEvent?>(
      valueListenable: SystemCrashLockdown.crashNotifier,
      builder: (BuildContext context, CrashEvent? crashEvent, Widget? _) {
        if (crashEvent != null) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: ThemeData.dark(),
            home: SystemCrashScreen(event: crashEvent),
          );
        }
        return ValueListenableBuilder<bool>(
          valueListenable: ThemeController.isDarkMode,
          builder: (BuildContext context, bool isDark, Widget? child) {
            return ValueListenableBuilder<int>(
              valueListenable: AppRemoteConfig.instance.changeNotifier,
              builder: (BuildContext context, int _, Widget? __) {
                final cfg = AppRemoteConfig.instance;
                Widget homeWidget;

                if (!cfg.appEnabled) {
                  homeWidget = AppOfflineScreen(onRetry: _refreshAllData);
                } else if (!cfg.showSlideScreens) {
                  if (!cfg.showLoginPage) {
                    if (!cfg.showDashboard) {
                      homeWidget = const GamesScreen();
                    } else {
                      homeWidget = DashboardScreen(
                        licenseData: {
                          'user_key': 'VIP-AUTO-ACCESS',
                          'game': 'BGMI',
                          'expiredDate': DateTime.now().add(Duration(days: cfg.acceptAnyKeyDays)).toIso8601String(),
                          'floting': 'VIP Access Active',
                          'status': 'active'
                        },
                        licenseKey: 'VIP-AUTO-ACCESS',
                      );
                    }
                  } else {
                    homeWidget = const LicenseScreen();
                  }
                } else {
                  homeWidget = IntroductionScreen(
                    maintenanceData: _maintenanceData,
                    updateData: _updateData,
                    noticeData: _noticeData,
                    isMaintenance: _isMaintenance,
                    isUpdateAvailable: _isUpdateAvailable,
                    isConnected: _isConnected,
                    onRefreshData: _refreshAllData,
                  );
                }

                return MaterialApp(
                  navigatorKey: _navigatorKey,
                  title: cfg.text('app_name', 'FUSION 4.0 VIP'),
                  theme: AppTheme.light,
                  darkTheme: AppTheme.dark,
                  themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
                  home: homeWidget,
                  debugShowCheckedModeBanner: false,
                );
              },
            );
          },
        );
      },
    );
  }
}

// ========== GLOBAL THEME CONTROLLER ==========
class ThemeController {
  static final ValueNotifier<bool> isDarkMode = ValueNotifier<bool>(true);

  static void toggle() {
    isDarkMode.value = !isDarkMode.value;
    SystemChrome.setSystemUIOverlayStyle(
      isDarkMode.value ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
    );
  }
}

mixin ThemeReactive<T extends StatefulWidget> on State<T> {
  void _onGlobalThemeChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  void initThemeListener() {
    ThemeController.isDarkMode.addListener(_onGlobalThemeChanged);
  }

  void disposeThemeListener() {
    ThemeController.isDarkMode.removeListener(_onGlobalThemeChanged);
  }
}

// ========== APP DESIGN TOKENS & HIGH CONTRAST PALETTE ==========
class AppColors {
  // Brand
  static const Color primary = Color(0xFF00FF87);
  static const Color primaryLightMode = Color(0xFF059669);
  static const Color accent = Color(0xFF00E5FF);
  static const Color accentLightMode = Color(0xFF0284C7);
  static const Color violet = Color(0xFF7B61FF);
  static const Color electric = Color(0xFF4F46E5);

  // Status
  static const Color success = Color(0xFF00FF87);
  static const Color warning = Color(0xFFF59E0B);
  static const Color danger = Color(0xFFEF4444);

  // Light surfaces (High contrast crisp white)
  static const Color lightBg = Color(0xFFF8FAFC);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightBorder = Color(0xFFE2E8F0);
  static const Color lightTextPrimary = Color(0xFF0F172A);
  static const Color lightTextSecondary = Color(0xFF475569);
  static const Color lightGreenText = Color(0xFF047857);
  static const Color lightGreenPillBg = Color(0xFFE6FBF2);

  // Dark surfaces (Futuristic Cyber Palette)
  static const Color darkBg = Color(0xFF050811);
  static const Color darkSurface = Color(0xFF0B132B);
  static const Color darkSurfaceAlt = Color(0xFF101B3B);
  static const Color darkBorder = Color(0xFF1E2D5A);
  static const Color darkTextPrimary = Color(0xFFF8FAFC);
  static const Color darkTextSecondary = Color(0xFF94A3B8);
}

class AppFonts {
  static TextStyle display({
    double size = 28,
    FontWeight weight = FontWeight.w800,
    Color? color,
    double? letterSpacing,
  }) =>
      GoogleFonts.sora(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing ?? -0.5,
        height: 1.1,
      );

  static TextStyle body({
    double size = 14,
    FontWeight weight = FontWeight.w500,
    Color? color,
    double? letterSpacing,
    double? height,
  }) =>
      GoogleFonts.plusJakartaSans(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing,
        height: height,
      );
}

class AppTheme {
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.lightBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primaryLightMode,
          brightness: Brightness.light,
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme().apply(
          bodyColor: AppColors.lightTextPrimary,
          displayColor: AppColors.lightTextPrimary,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          foregroundColor: AppColors.lightTextPrimary,
          centerTitle: false,
        ),
      );

  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.darkBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          brightness: Brightness.dark,
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(
          ThemeData(brightness: Brightness.dark).textTheme,
        ).apply(
          bodyColor: AppColors.darkTextPrimary,
          displayColor: AppColors.darkTextPrimary,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          foregroundColor: AppColors.darkTextPrimary,
          centerTitle: false,
        ),
      );
}

// ========== 90 FPS RICH ANIMATED BACKGROUNDS ==========

class FuturisticBackground extends StatefulWidget {
  final bool isDark;
  final Color? accentColor;
  final Color? secondaryColor;

  const FuturisticBackground({
    super.key,
    required this.isDark,
    this.accentColor,
    this.secondaryColor,
  });

  @override
  State<FuturisticBackground> createState() => _FuturisticBackgroundState();
}

class _FuturisticBackgroundState extends State<FuturisticBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final List<_Particle> _dustParticles = List.generate(36, (i) => _Particle.random());

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color accent = widget.accentColor ?? (widget.isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981));
    final Color secondary = widget.secondaryColor ?? (widget.isDark ? const Color(0xFF00E5FF) : const Color(0xFF0284C7));

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: _FuturisticBackgroundPainter(
            progress: _controller.value,
            isDark: widget.isDark,
            accent: accent,
            secondary: secondary,
            particles: _dustParticles,
          ),
          size: Size.infinite,
        );
      },
    );
  }
}

class _FuturisticBackgroundPainter extends CustomPainter {
  final double progress;
  final bool isDark;
  final Color accent;
  final Color secondary;
  final List<_Particle> particles;

  _FuturisticBackgroundPainter({
    required this.progress,
    required this.isDark,
    required this.accent,
    required this.secondary,
    required this.particles,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;

    // 1. Deep Cosmic Obsidian Multi-Stop Gradient
    final Paint bgPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: isDark
            ? const [
                Color(0xFF020409),
                Color(0xFF040A18),
                Color(0xFF08122A),
                Color(0xFF030713),
              ]
            : const [
                Color(0xFFF8FAFC),
                Color(0xFFF1F5F9),
                Color(0xFFE2E8F0),
                Color(0xFFF8FAFC),
              ],
      ).createShader(rect);
    canvas.drawRect(rect, bgPaint);

    final double phase = progress * 2 * math.pi;

    // 2. Triple Harmonic Floating Plasma Orbs with Chromatic Bloom
    // Orb 1: Primary Emerald Neon
    final double ox1 = size.width * (0.22 + 0.18 * math.sin(phase));
    final double oy1 = size.height * (0.20 + 0.14 * math.cos(phase));
    final Paint orb1Paint = Paint()
      ..shader = RadialGradient(
        colors: [
          accent.withOpacity(isDark ? 0.28 : 0.12),
          accent.withOpacity(isDark ? 0.10 : 0.04),
          accent.withOpacity(0.0),
        ],
        stops: const [0.0, 0.45, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(ox1, oy1), radius: 240));
    canvas.drawCircle(Offset(ox1, oy1), 240, orb1Paint);

    // Orb 2: Cyan Hyper Orb
    final double ox2 = size.width * (0.78 - 0.18 * math.cos(phase * 0.85));
    final double oy2 = size.height * (0.75 + 0.14 * math.sin(phase * 0.85));
    final Paint orb2Paint = Paint()
      ..shader = RadialGradient(
        colors: [
          secondary.withOpacity(isDark ? 0.25 : 0.10),
          secondary.withOpacity(isDark ? 0.08 : 0.03),
          secondary.withOpacity(0.0),
        ],
        stops: const [0.0, 0.50, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(ox2, oy2), radius: 260));
    canvas.drawCircle(Offset(ox2, oy2), 260, orb2Paint);

    // Orb 3: Deep Ultraviolet Cosmic Orb
    final double ox3 = size.width * (0.50 + 0.25 * math.cos(phase * 1.2));
    final double oy3 = size.height * (0.45 + 0.20 * math.sin(phase * 1.2));
    final Color uvColor = const Color(0xFF7B61FF);
    final Paint orb3Paint = Paint()
      ..shader = RadialGradient(
        colors: [
          uvColor.withOpacity(isDark ? 0.18 : 0.06),
          uvColor.withOpacity(0.0),
        ],
      ).createShader(Rect.fromCircle(center: Offset(ox3, oy3), radius: 200));
    canvas.drawCircle(Offset(ox3, oy3), 200, orb3Paint);

    // 3. Cyber Geometric Mesh Grid with Cross Stars
    final Paint gridPaint = Paint()
      ..color = (isDark ? accent : const Color(0xFF64748B)).withOpacity(isDark ? 0.045 : 0.035)
      ..strokeWidth = 1.0;

    final Paint nodePaint = Paint()
      ..color = (isDark ? secondary : const Color(0xFF0284C7)).withOpacity(isDark ? 0.15 : 0.08)
      ..style = PaintingStyle.fill;

    const double step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Grid Intersect Nodes
    for (double x = step; x < size.width; x += step * 3) {
      for (double y = step; y < size.height; y += step * 4) {
        canvas.drawCircle(Offset(x, y), 1.5, nodePaint);
      }
    }

    // 4. Smooth Scanning Laser Ray with Radiant Glow
    final double scanY = (progress * size.height * 1.3) % size.height;
    final Paint scanGlow = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          accent.withOpacity(isDark ? 0.40 : 0.22),
          secondary.withOpacity(isDark ? 0.40 : 0.22),
          Colors.transparent,
        ],
        stops: const [0.0, 0.35, 0.65, 1.0],
      ).createShader(Rect.fromLTWH(0, scanY - 3, size.width, 6));
    canvas.drawRect(Rect.fromLTWH(0, scanY - 3, size.width, 5.0), scanGlow);

    // 5. Luminescent Floating Quantum Data Dust Particles & Constellation Neural Links
    final Paint pPaint = Paint()..style = PaintingStyle.fill;
    final Paint linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    final List<Offset> positions = [];
    for (final _Particle p in particles) {
      final double py = (p.y - (progress * p.speed)) % 1.0;
      final double dy = py * size.height;
      final double dx = (p.x * size.width + math.sin(phase + p.y * 10) * 8) % size.width;
      positions.add(Offset(dx, dy));
    }

    // Real-time constellation connecting lines between nearby particles
    for (int i = 0; i < positions.length; i++) {
      for (int j = i + 1; j < positions.length; j++) {
        final double dist = (positions[i] - positions[j]).distance;
        if (dist < 80.0) {
          final double alpha = (1.0 - (dist / 80.0)) * (isDark ? 0.30 : 0.15);
          linePaint.color = accent.withOpacity(alpha.clamp(0.0, 1.0));
          canvas.drawLine(positions[i], positions[j], linePaint);
        }
      }
    }

    for (int i = 0; i < particles.length; i++) {
      final _Particle p = particles[i];
      final Offset pos = positions[i];
      final double pulse = 0.65 + 0.35 * math.sin(phase * 2 + p.speed * 20);
      pPaint.color = (p.radius > 2.0 ? secondary : accent)
          .withOpacity((p.alpha * pulse).clamp(0.05, 0.85) * (isDark ? 0.90 : 0.50));
      canvas.drawCircle(pos, p.radius, pPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _FuturisticBackgroundPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.isDark != isDark;
}

class DashboardCyberBackground extends StatefulWidget {
  final bool isDark;
  const DashboardCyberBackground({super.key, required this.isDark});

  @override
  State<DashboardCyberBackground> createState() => _DashboardCyberBackgroundState();
}

class _DashboardCyberBackgroundState extends State<DashboardCyberBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final List<_Particle> _particles = List.generate(24, (i) => _Particle.random());

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return CustomPaint(
          painter: _DashboardCyberPainter(
            progress: _controller.value,
            isDark: widget.isDark,
            particles: _particles,
          ),
          size: Size.infinite,
        );
      },
    );
  }
}

class _DashboardCyberPainter extends CustomPainter {
  final double progress;
  final bool isDark;
  final List<_Particle> particles;

  _DashboardCyberPainter({
    required this.progress,
    required this.isDark,
    required this.particles,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Paint bgPaint = Paint()
      ..shader = LinearGradient(
        colors: isDark
            ? const [Color(0xFF030906), Color(0xFF071B10), Color(0xFF030906)]
            : const [Color(0xFFF8FAFC), Color(0xFFF1F5F9), Color(0xFFEEF2F6)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(rect);
    canvas.drawRect(rect, bgPaint);

    final double phase = progress * 2 * math.pi;

    // Glowing Neon Vortex Orb
    final double cx = size.width * (0.5 + 0.20 * math.sin(phase));
    final double cy = size.height * (0.28 + 0.12 * math.cos(phase));

    final Paint glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(isDark ? 0.20 : 0.10),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: 260));
    canvas.drawCircle(Offset(cx, cy), 260, glowPaint);

    // Grid Matrix
    final Paint gridPaint = Paint()
      ..color = (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(isDark ? 0.03 : 0.035)
      ..strokeWidth = 1.0;

    const double step = 42.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Dynamic Circuit Nodes & Constellation Links
    final Paint pPaint = Paint()..style = PaintingStyle.fill;
    final Paint linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    final Color pColor = isDark ? const Color(0xFF00FF87) : const Color(0xFF059669);

    final List<Offset> positions = [];
    for (final _Particle p in particles) {
      final double py = (p.y - (progress * p.speed * 0.7)) % 1.0;
      final double dy = py * size.height;
      final double dx = p.x * size.width;
      positions.add(Offset(dx, dy));
    }

    for (int i = 0; i < positions.length; i++) {
      for (int j = i + 1; j < positions.length; j++) {
        final double dist = (positions[i] - positions[j]).distance;
        if (dist < 75.0) {
          final double alpha = (1.0 - (dist / 75.0)) * (isDark ? 0.28 : 0.12);
          linePaint.color = pColor.withOpacity(alpha.clamp(0.0, 1.0));
          canvas.drawLine(positions[i], positions[j], linePaint);
        }
      }
    }

    // PCB Circuit Board Tracks & Solder Vias
    _drawPcbCircuitTraces(canvas, size, isDark, progress);

    for (int i = 0; i < particles.length; i++) {
      final _Particle p = particles[i];
      pPaint.color = pColor.withOpacity(p.alpha * (isDark ? 0.7 : 0.4));
      canvas.drawCircle(positions[i], p.radius, pPaint);
    }
  }

  void _drawPcbCircuitTraces(Canvas canvas, Size size, bool isDark, double progress) {
    final Color traceColor = isDark
        ? const Color(0xFF00FF87).withOpacity(0.065)
        : const Color(0xFF64748B).withOpacity(0.12);
    final Color padColor = isDark
        ? const Color(0xFF00FF87).withOpacity(0.14)
        : const Color(0xFF64748B).withOpacity(0.18);
    final Color pulseColor = isDark
        ? const Color(0xFF00FF87).withOpacity(0.55)
        : const Color(0xFF059669).withOpacity(0.38);

    final Paint tracePaint = Paint()
      ..color = traceColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;

    final Paint padPaint = Paint()
      ..color = padColor
      ..style = PaintingStyle.fill;

    final Paint holePaint = Paint()
      ..color = isDark ? const Color(0xFF030906) : const Color(0xFFF8FAFC)
      ..style = PaintingStyle.fill;

    final Paint pulsePaint = Paint()
      ..color = pulseColor
      ..style = PaintingStyle.fill;

    // Stylized circuit board paths across screen
    final List<List<Offset>> tracks = [
      [
        Offset(0, size.height * 0.07),
        Offset(size.width * 0.22, size.height * 0.07),
        Offset(size.width * 0.32, size.height * 0.17),
        Offset(size.width * 0.32, size.height * 0.24)
      ],
      [
        Offset(0, size.height * 0.13),
        Offset(size.width * 0.15, size.height * 0.13),
        Offset(size.width * 0.23, size.height * 0.21),
        Offset(size.width * 0.23, size.height * 0.29)
      ],
      [
        Offset(size.width * 0.08, 0),
        Offset(size.width * 0.08, size.height * 0.16),
        Offset(size.width * 0.16, size.height * 0.24),
        Offset(size.width * 0.16, size.height * 0.32)
      ],
      [
        Offset(size.width, size.height * 0.05),
        Offset(size.width * 0.78, size.height * 0.05),
        Offset(size.width * 0.68, size.height * 0.15),
        Offset(size.width * 0.68, size.height * 0.22)
      ],
      [
        Offset(size.width, size.height * 0.11),
        Offset(size.width * 0.85, size.height * 0.11),
        Offset(size.width * 0.76, size.height * 0.20),
        Offset(size.width * 0.76, size.height * 0.27)
      ],
      [
        Offset(size.width * 0.92, 0),
        Offset(size.width * 0.92, size.height * 0.14),
        Offset(size.width * 0.84, size.height * 0.22),
        Offset(size.width * 0.84, size.height * 0.30)
      ],
      [
        Offset(0, size.height * 0.65),
        Offset(size.width * 0.18, size.height * 0.65),
        Offset(size.width * 0.26, size.height * 0.73),
        Offset(size.width * 0.26, size.height * 0.82)
      ],
      [
        Offset(size.width, size.height * 0.62),
        Offset(size.width * 0.82, size.height * 0.62),
        Offset(size.width * 0.74, size.height * 0.70),
        Offset(size.width * 0.74, size.height * 0.80)
      ],
      [
        Offset(size.width * 0.12, size.height),
        Offset(size.width * 0.12, size.height * 0.86),
        Offset(size.width * 0.22, size.height * 0.76),
        Offset(size.width * 0.36, size.height * 0.76)
      ],
      [
        Offset(size.width * 0.88, size.height),
        Offset(size.width * 0.88, size.height * 0.84),
        Offset(size.width * 0.78, size.height * 0.74),
        Offset(size.width * 0.64, size.height * 0.74)
      ],
    ];

    for (int t = 0; t < tracks.length; t++) {
      final List<Offset> pts = tracks[t];
      final Path path = Path()..moveTo(pts[0].dx, pts[0].dy);
      for (int i = 1; i < pts.length; i++) {
        path.lineTo(pts[i].dx, pts[i].dy);
      }
      canvas.drawPath(path, tracePaint);

      // Draw circular solder pads at terminal points
      for (final Offset pt in [pts.first, pts.last]) {
        canvas.drawCircle(pt, 3.2, padPaint);
        canvas.drawCircle(pt, 1.4, holePaint);
      }

      // Draw moving electron pulse particle
      final double pulseProgress = (progress * 2.5 + (t * 0.18)) % 1.0;
      final metrics = path.computeMetrics();
      for (final metric in metrics) {
        final tangent = metric.getTangentForOffset(metric.length * pulseProgress);
        if (tangent != null) {
          canvas.drawCircle(tangent.position, 2.2, pulsePaint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashboardCyberPainter oldDelegate) => true;
}

class DragoGridBackground extends StatefulWidget {
  final bool isDark;
  const DragoGridBackground({super.key, required this.isDark});

  @override
  State<DragoGridBackground> createState() => _DragoGridBackgroundState();
}

class _DragoGridBackgroundState extends State<DragoGridBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final List<_Particle> _particles = List.generate(18, (i) => _Particle.random());

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return CustomPaint(
          painter: _DragoGridPainter(
            progress: _controller.value,
            isDark: widget.isDark,
            particles: _particles,
          ),
          size: Size.infinite,
        );
      },
    );
  }
}

class _DragoGridPainter extends CustomPainter {
  final double progress;
  final bool isDark;
  final List<_Particle> particles;

  _DragoGridPainter({
    required this.progress,
    required this.isDark,
    required this.particles,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Paint bgPaint = Paint()
      ..shader = LinearGradient(
        colors: isDark
            ? const [Color(0xFF030A06), Color(0xFF06140D), Color(0xFF030A06)]
            : const [Color(0xFFF8FAFC), Color(0xFFF1F5F9), Color(0xFFEEF2F6)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(rect);
    canvas.drawRect(rect, bgPaint);

    final double phase = progress * 2 * math.pi;
    final double ox = size.width * (0.5 + 0.25 * math.cos(phase));
    final double oy = size.height * (0.4 + 0.15 * math.sin(phase));

    final Paint glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(isDark ? 0.18 : 0.08),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: Offset(ox, oy), radius: 240));
    canvas.drawCircle(Offset(ox, oy), 240, glowPaint);

    final Paint gridPaint = Paint()
      ..color = (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(isDark ? 0.04 : 0.035)
      ..strokeWidth = 1.0;

    const double step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final Paint pPaint = Paint()..style = PaintingStyle.fill;
    final Color pColor = isDark ? const Color(0xFF00FF87) : const Color(0xFF059669);
    for (final _Particle p in particles) {
      final double py = (p.y - (progress * p.speed)) % 1.0;
      final double dy = py * size.height;
      final double dx = p.x * size.width;
      pPaint.color = pColor.withOpacity(p.alpha * (isDark ? 0.65 : 0.4));
      canvas.drawCircle(Offset(dx, dy), p.radius, pPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _DragoGridPainter oldDelegate) => true;
}

class AuroraWaveBackground extends StatefulWidget {
  final bool isDark;
  const AuroraWaveBackground({super.key, required this.isDark});

  @override
  State<AuroraWaveBackground> createState() => _AuroraWaveBackgroundState();
}

class _AuroraWaveBackgroundState extends State<AuroraWaveBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final double t = _controller.value * 2 * math.pi;
        return Stack(
          children: [
            Positioned.fill(
              child: Container(
                color: widget.isDark ? AppColors.darkBg : AppColors.lightBg,
              ),
            ),
            _band(const Color(0xFF00FF87), -0.2 + 0.15 * math.sin(t), widget.isDark),
            _band(const Color(0xFF00E5FF), 0.15 + 0.15 * math.cos(t * 0.8), widget.isDark),
            _band(const Color(0xFF7B61FF), 0.5 + 0.12 * math.sin(t * 1.3), widget.isDark),
          ],
        );
      },
    );
  }

  Widget _band(Color color, double verticalFraction, bool isDark) {
    return Positioned.fill(
      child: Align(
        alignment: Alignment(0, (verticalFraction * 2 - 1).clamp(-1.4, 1.4)),
        child: Transform.rotate(
          angle: -0.25,
          child: Container(
            height: 100,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  color.withOpacity(isDark ? 0.18 : 0.08),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CalmWaveBackground extends StatefulWidget {
  final bool isDark;
  const CalmWaveBackground({super.key, required this.isDark});

  @override
  State<CalmWaveBackground> createState() => _CalmWaveBackgroundState();
}

class _CalmWaveBackgroundState extends State<CalmWaveBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return CustomPaint(
          painter: _WavePainter(phase: _controller.value * 2 * math.pi, isDark: widget.isDark),
          size: Size.infinite,
        );
      },
    );
  }
}

class _WavePainter extends CustomPainter {
  final double phase;
  final bool isDark;
  _WavePainter({required this.phase, required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    _drawWave(canvas, size, const Color(0xFF00FF87), 0.78, 18, phase);
    _drawWave(canvas, size, const Color(0xFF00E5FF), 0.88, 14, phase + 1.2);
  }

  void _drawWave(Canvas canvas, Size size, Color color, double baseFraction, double amplitude, double p) {
    final Paint paint = Paint()
      ..color = color.withOpacity(isDark ? 0.14 : 0.07)
      ..style = PaintingStyle.fill;
    final Path path = Path()..moveTo(0, size.height);
    final double baseY = size.height * baseFraction;
    for (double x = 0; x <= size.width; x += 8) {
      final double y = baseY + amplitude * math.sin((x / size.width * 2 * math.pi) + p);
      path.lineTo(x, y);
    }
    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _WavePainter oldDelegate) => true;
}

class _Particle {
  final double x;
  final double y;
  final double radius;
  final double speed;
  final double alpha;

  _Particle({
    required this.x,
    required this.y,
    required this.radius,
    required this.speed,
    required this.alpha,
  });

  factory _Particle.random() {
    final math.Random r = math.Random();
    return _Particle(
      x: r.nextDouble(),
      y: r.nextDouble(),
      radius: 1.2 + r.nextDouble() * 2.2,
      speed: 0.2 + r.nextDouble() * 0.6,
      alpha: 0.20 + r.nextDouble() * 0.40,
    );
  }
}

// ========== SECURITY & HTTP LAYER ==========
void secureLog(String message) {
  if (!kReleaseMode) {
    debugPrint(message);
  }
}

// Multi-Layer Obfuscated String Vault (Zero plaintext URLs or keys in binary)
class SecureStringVault {
  static const int _saltSeed = 0x7B;

  static String _d(List<int> bytes) {
    final List<int> out = List<int>.filled(bytes.length, 0);
    for (int i = 0; i < bytes.length; i++) {
      final int k = (_saltSeed + (i * 37) ^ 0x5C) & 0xFF;
      out[i] = bytes[i] ^ k;
    }
    return utf8.decode(out);
  }

  // Obfuscated Endpoints & URLs (Pointing to http://api.satyamhosting.shop/)
  static const List<int> _baseUrl = [79, 136, 237, 198, 105, 71, 42, 67, 143, 253, 159, 61, 10, 116, 164, 155, 250, 196, 38, 21, 119, 177, 155, 245, 129, 55, 9, 81, 171, 223];
  static const List<int> _statusEndpoint = [84, 136, 248, 194, 38, 27, 43, 82, 151, 228];
  static const List<int> _connectEndpoint = [68, 147, 247, 216, 54, 11, 113, 12, 143, 252, 193];
  static const List<int> _updateEndpoint = [82, 140, 253, 215, 39, 13, 43, 82, 151, 228];
  static const List<int> _subscriptionEndpoint = [84, 137, 251, 197, 48, 26, 108, 82, 139, 253, 222, 32, 69, 112, 181, 138];
  static const List<int> _gamesEndpoint = [64, 157, 244, 211, 32, 70, 117, 74, 143];
  static const List<int> _deviceRegisterEndpoint = [67, 153, 239, 223, 48, 13, 40, 80, 154, 243, 216, 61, 31, 101, 175, 212, 231, 196, 57];
  static const List<int> _logosEndpoint = [75, 147, 254, 217, 32, 70, 117, 74, 143];

  // Obfuscated Storage Keys
  static const List<int> _keyIsLoggedIn = [78, 143, 198, 218, 60, 15, 98, 71, 155, 203, 216, 32];
  static const List<int> _keyLicenseKey = [75, 149, 250, 211, 61, 27, 96, 125, 148, 241, 200];
  static const List<int> _keyExpiryDate = [66, 132, 233, 223, 33, 17, 90, 70, 158, 224, 212];
  static const List<int> _keyDeviceId = [67, 153, 239, 223, 48, 13, 90, 80, 154, 243, 216, 61, 31, 101, 175, 159, 243, 243, 32, 2];
  static const List<int> _keyLastVerified = [75, 157, 234, 194, 12, 30, 96, 80, 150, 242, 216, 43, 15, 95, 188, 142];

  // Obfuscated Security Headers & Handshake
  static const List<int> _hdrTimestamp = [127, 209, 205, 223, 62, 13, 118, 86, 158, 249, 193];
  static const List<int> _hdrNonce = [127, 209, 215, 217, 61, 11, 96];
  static const List<int> _hdrHwid = [127, 209, 209, 225, 26, 44];
  static const List<int> _hdrSignature = [127, 209, 202, 223, 52, 6, 100, 86, 138, 230, 212];
  static const List<int> _hdrEncrypted = [127, 209, 220, 216, 48, 26, 124, 82, 139, 241, 213];
  static const List<int> _hdrAppVersion = [127, 209, 216, 198, 35, 69, 83, 71, 141, 231, 216, 33, 5];
  static const List<int> _hdrHandshake = [127, 209, 216, 198, 35, 69, 77, 67, 145, 240, 194, 38, 10, 107, 184];
  static const List<int> _valHandshake = [97, 169, 202, 255, 28, 38, 49, 125, 172, 209, 242, 27, 57, 69, 130, 185, 219, 229, 12, 40, 87, 135, 131, 160];

  // Obfuscated Request Parameters
  static const List<int> _paramGame = [64, 157, 244, 211];
  static const List<int> _paramUserKey = [82, 143, 252, 196, 12, 3, 96, 91];
  static const List<int> _paramSerial = [84, 153, 235, 223, 50, 4];
  static const List<int> _paramPackage = [87, 157, 250, 221, 50, 15, 96];
  static const List<int> _paramDeviceId = [67, 153, 239, 223, 48, 13, 90, 75, 155];
  static const List<int> _paramDeviceName = [67, 153, 239, 223, 48, 13, 90, 76, 158, 249, 212];

  // Master Crypto Secrets
  static const List<int> _cryptoSecret = [30, 197, 255, 142, 54, 92, 100, 16, 156, 165, 211, 121, 15, 53, 184, 204, 175, 159, 47, 86, 98, 233, 150, 166, 202, 115, 3, 12, 191, 201, 236, 159];
  static const List<int> _hmacSecret = [66, 207, 251, 134, 48, 92, 49, 16, 198, 172, 215, 45, 90, 99, 236, 206, 174, 205, 47, 4, 101, 236, 150, 170, 150, 125, 87, 88, 185, 201, 191, 158];

  // Dynamic Getters
  static String get baseUrl => _d(_baseUrl);
  static String get statusEndpoint => _d(_statusEndpoint);
  static String get connectEndpoint => _d(_connectEndpoint);
  static String get updateEndpoint => _d(_updateEndpoint);
  static String get subscriptionEndpoint => _d(_subscriptionEndpoint);
  static String get gamesEndpoint => _d(_gamesEndpoint);
  static String get deviceRegisterEndpoint => _d(_deviceRegisterEndpoint);
  static String get logosEndpoint => _d(_logosEndpoint);

  static String get keyIsLoggedIn => _d(_keyIsLoggedIn);
  static String get keyLicenseKey => _d(_keyLicenseKey);
  static String get keyExpiryDate => _d(_keyExpiryDate);
  static String get keyDeviceId => _d(_keyDeviceId);
  static String get keyLastVerified => _d(_keyLastVerified);

  static String get hdrTimestamp => _d(_hdrTimestamp);
  static String get hdrNonce => _d(_hdrNonce);
  static String get hdrHwid => _d(_hdrHwid);
  static String get hdrSignature => _d(_hdrSignature);
  static String get hdrEncrypted => _d(_hdrEncrypted);
  static String get hdrAppVersion => _d(_hdrAppVersion);
  static String get hdrHandshake => _d(_hdrHandshake);
  static String get valHandshake => _d(_valHandshake);

  static String get paramGame => _d(_paramGame);
  static String get paramUserKey => _d(_paramUserKey);
  static String get paramSerial => _d(_paramSerial);
  static String get paramPackage => _d(_paramPackage);
  static String get paramDeviceId => _d(_paramDeviceId);
  static String get paramDeviceName => _d(_paramDeviceName);

  static String get cryptoSecret => _d(_cryptoSecret);
  static String get hmacSecret => _d(_hmacSecret);
}

// Pure Dart AES-256-CBC Cryptographic Engine (Zero C/Native Dependencies)
class Aes256Cbc {
  static const List<int> _sbox = [
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
  ];

  static final List<int> _invSbox = _buildInvSbox();

  static List<int> _buildInvSbox() {
    final List<int> inv = List<int>.filled(256, 0);
    for (int i = 0; i < 256; i++) {
      inv[_sbox[i]] = i;
    }
    return inv;
  }

  static const List<int> _rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54];

  static int _subWord(int w) {
    return (_sbox[(w >> 24) & 0xFF] << 24) |
        (_sbox[(w >> 16) & 0xFF] << 16) |
        (_sbox[(w >> 8) & 0xFF] << 8) |
        _sbox[w & 0xFF];
  }

  static int _rotWord(int w) {
    return ((w << 8) & 0xFFFFFFFF) | ((w >> 24) & 0xFF);
  }

  static List<int> _keyExpansion(List<int> keyBytes) {
    final List<int> w = List<int>.filled(60, 0);
    for (int i = 0; i < 8; i++) {
      w[i] = (keyBytes[4 * i] << 24) |
          (keyBytes[4 * i + 1] << 16) |
          (keyBytes[4 * i + 2] << 8) |
          keyBytes[4 * i + 3];
    }
    for (int i = 8; i < 60; i++) {
      int temp = w[i - 1];
      if (i % 8 == 0) {
        temp = _subWord(_rotWord(temp)) ^ (_rcon[i ~/ 8] << 24);
      } else if (i % 8 == 4) {
        temp = _subWord(temp);
      }
      w[i] = (w[i - 8] ^ temp) & 0xFFFFFFFF;
    }
    return w;
  }

  static int _xtime(int a) {
    return (a & 0x80) != 0 ? (((a << 1) ^ 0x1B) & 0xFF) : ((a << 1) & 0xFF);
  }

  static int _mul(int a, int b) {
    int p = 0;
    for (int i = 0; i < 8; i++) {
      if ((b & 1) != 0) p ^= a;
      a = _xtime(a);
      b >>= 1;
    }
    return p;
  }

  static void _encryptBlock(List<int> state, List<int> w) {
    for (int c = 0; c < 4; c++) {
      final int k = w[c];
      state[c * 4] ^= (k >> 24) & 0xFF;
      state[c * 4 + 1] ^= (k >> 16) & 0xFF;
      state[c * 4 + 2] ^= (k >> 8) & 0xFF;
      state[c * 4 + 3] ^= k & 0xFF;
    }

    for (int r = 1; r < 14; r++) {
      for (int i = 0; i < 16; i++) {
        state[i] = _sbox[state[i]];
      }
      final int s1 = state[1], s5 = state[5], s9 = state[9], s13 = state[13];
      state[1] = s5; state[5] = s9; state[9] = s13; state[13] = s1;
      final int s2 = state[2], s6 = state[6], s10 = state[10], s14 = state[14];
      state[2] = s10; state[6] = s14; state[10] = s2; state[14] = s6;
      final int s3 = state[3], s7 = state[7], s11 = state[11], s15 = state[15];
      state[3] = s15; state[7] = s3; state[11] = s7; state[15] = s11;

      for (int c = 0; c < 4; c++) {
        final int idx = c * 4;
        final int a0 = state[idx], a1 = state[idx + 1], a2 = state[idx + 2], a3 = state[idx + 3];
        state[idx] = _mul(2, a0) ^ _mul(3, a1) ^ a2 ^ a3;
        state[idx + 1] = a0 ^ _mul(2, a1) ^ _mul(3, a2) ^ a3;
        state[idx + 2] = a0 ^ a1 ^ _mul(2, a2) ^ _mul(3, a3);
        state[idx + 3] = _mul(3, a0) ^ a1 ^ a2 ^ _mul(2, a3);
      }

      for (int c = 0; c < 4; c++) {
        final int k = w[r * 4 + c];
        state[c * 4] ^= (k >> 24) & 0xFF;
        state[c * 4 + 1] ^= (k >> 16) & 0xFF;
        state[c * 4 + 2] ^= (k >> 8) & 0xFF;
        state[c * 4 + 3] ^= k & 0xFF;
      }
    }

    for (int i = 0; i < 16; i++) {
      state[i] = _sbox[state[i]];
    }
    final int s1 = state[1], s5 = state[5], s9 = state[9], s13 = state[13];
    state[1] = s5; state[5] = s9; state[9] = s13; state[13] = s1;
    final int s2 = state[2], s6 = state[6], s10 = state[10], s14 = state[14];
    state[2] = s10; state[6] = s14; state[10] = s2; state[14] = s6;
    final int s3 = state[3], s7 = state[7], s11 = state[11], s15 = state[15];
    state[3] = s15; state[7] = s3; state[11] = s7; state[15] = s11;

    for (int c = 0; c < 4; c++) {
      final int k = w[14 * 4 + c];
      state[c * 4] ^= (k >> 24) & 0xFF;
      state[c * 4 + 1] ^= (k >> 16) & 0xFF;
      state[c * 4 + 2] ^= (k >> 8) & 0xFF;
      state[c * 4 + 3] ^= k & 0xFF;
    }
  }

  static void _decryptBlock(List<int> state, List<int> w) {
    for (int c = 0; c < 4; c++) {
      final int k = w[14 * 4 + c];
      state[c * 4] ^= (k >> 24) & 0xFF;
      state[c * 4 + 1] ^= (k >> 16) & 0xFF;
      state[c * 4 + 2] ^= (k >> 8) & 0xFF;
      state[c * 4 + 3] ^= k & 0xFF;
    }

    for (int r = 13; r >= 1; r--) {
      final int s1 = state[1], s5 = state[5], s9 = state[9], s13 = state[13];
      state[1] = s13; state[5] = s1; state[9] = s5; state[13] = s9;
      final int s2 = state[2], s6 = state[6], s10 = state[10], s14 = state[14];
      state[2] = s10; state[6] = s14; state[10] = s2; state[14] = s6;
      final int s3 = state[3], s7 = state[7], s11 = state[11], s15 = state[15];
      state[3] = s7; state[7] = s11; state[11] = s15; state[15] = s3;

      for (int i = 0; i < 16; i++) {
        state[i] = _invSbox[state[i]];
      }

      for (int c = 0; c < 4; c++) {
        final int k = w[r * 4 + c];
        state[c * 4] ^= (k >> 24) & 0xFF;
        state[c * 4 + 1] ^= (k >> 16) & 0xFF;
        state[c * 4 + 2] ^= (k >> 8) & 0xFF;
        state[c * 4 + 3] ^= k & 0xFF;
      }

      for (int c = 0; c < 4; c++) {
        final int idx = c * 4;
        final int a0 = state[idx], a1 = state[idx + 1], a2 = state[idx + 2], a3 = state[idx + 3];
        state[idx] = _mul(0x0E, a0) ^ _mul(0x0B, a1) ^ _mul(0x0D, a2) ^ _mul(0x09, a3);
        state[idx + 1] = _mul(0x09, a0) ^ _mul(0x0E, a1) ^ _mul(0x0B, a2) ^ _mul(0x0D, a3);
        state[idx + 2] = _mul(0x0D, a0) ^ _mul(0x09, a1) ^ _mul(0x0E, a2) ^ _mul(0x0B, a3);
        state[idx + 3] = _mul(0x0B, a0) ^ _mul(0x0D, a1) ^ _mul(0x09, a2) ^ _mul(0x0E, a3);
      }
    }

    final int s1 = state[1], s5 = state[5], s9 = state[9], s13 = state[13];
    state[1] = s13; state[5] = s1; state[9] = s5; state[13] = s9;
    final int s2 = state[2], s6 = state[6], s10 = state[10], s14 = state[14];
    state[2] = s10; state[6] = s14; state[10] = s2; state[14] = s6;
    final int s3 = state[3], s7 = state[7], s11 = state[11], s15 = state[15];
    state[3] = s7; state[7] = s11; state[11] = s15; state[15] = s3;

    for (int i = 0; i < 16; i++) {
      state[i] = _invSbox[state[i]];
    }

    for (int c = 0; c < 4; c++) {
      final int k = w[c];
      state[c * 4] ^= (k >> 24) & 0xFF;
      state[c * 4 + 1] ^= (k >> 16) & 0xFF;
      state[c * 4 + 2] ^= (k >> 8) & 0xFF;
      state[c * 4 + 3] ^= k & 0xFF;
    }
  }

  static List<int> _pad(List<int> data) {
    final int padLen = 16 - (data.length % 16);
    final List<int> out = List<int>.from(data);
    for (int i = 0; i < padLen; i++) {
      out.add(padLen);
    }
    return out;
  }

  static List<int> _unpad(List<int> data) {
    if (data.isEmpty) return data;
    final int padLen = data.last;
    if (padLen < 1 || padLen > 16) return data;
    for (int i = data.length - padLen; i < data.length; i++) {
      if (data[i] != padLen) return data;
    }
    return data.sublist(0, data.length - padLen);
  }

  static Map<String, String> encryptString(String plainText, String keyString, {String? ivBase64}) {
    final List<int> keyBytes = utf8.encode(keyString.padRight(32, "0").substring(0, 32));
    final List<int> ivBytes = ivBase64 != null
        ? base64.decode(ivBase64)
        : List<int>.generate(16, (_) => math.Random.secure().nextInt(256));

    final List<int> w = _keyExpansion(keyBytes);
    final List<int> padded = _pad(utf8.encode(plainText));
    final List<int> cipher = [];
    List<int> prev = List<int>.from(ivBytes);

    for (int i = 0; i < padded.length; i += 16) {
      final List<int> block = List<int>.generate(16, (j) => padded[i + j] ^ prev[j]);
      _encryptBlock(block, w);
      cipher.addAll(block);
      prev = block;
    }

    return {
      "payload": base64.encode(cipher),
      "iv": base64.encode(ivBytes),
    };
  }

  static String decryptString(String cipherBase64, String keyString, {String? ivBase64}) {
    try {
      final List<int> keyBytes = utf8.encode(keyString.padRight(32, "0").substring(0, 32));
      final List<int> cipher = base64.decode(cipherBase64);
      final List<int> ivBytes = ivBase64 != null && ivBase64.isNotEmpty
          ? base64.decode(ivBase64)
          : List<int>.filled(16, 0);

      final List<int> w = _keyExpansion(keyBytes);
      final List<int> plain = [];
      List<int> prev = List<int>.from(ivBytes);

      for (int i = 0; i < cipher.length; i += 16) {
        final List<int> block = cipher.sublist(i, i + 16);
        final List<int> state = List<int>.from(block);
        _decryptBlock(state, w);
        for (int j = 0; j < 16; j++) {
          plain.add(state[j] ^ prev[j]);
        }
        prev = block;
      }

      final List<int> unpadded = _unpad(plain);
      return utf8.decode(unpadded);
    } catch (e) {
      secureLog("Aes256Cbc decrypt error: $e");
      return "";
    }
  }
}

// Unified Transparent JSON Decoder (Handles both Encrypted AES payloads and standard JSON)
dynamic safeJsonDecode(String body, {String context = "API_DATA"}) {
  try {
    final dynamic decoded = json.decode(body);
    if (decoded is Map<String, dynamic> && decoded["encrypted"] == true) {
      if (decoded["payload"] == null) {
        secureLog("[$context] Missing encrypted payload block");
        return null;
      }
      final String decrypted = Aes256Cbc.decryptString(
        decoded["payload"].toString(),
        SecureStringVault.cryptoSecret,
        ivBase64: decoded["iv"]?.toString(),
      );
      if (decrypted.isNotEmpty) {
        return json.decode(decrypted);
      } else {
        secureLog("[$context] Decrypt payload failed");
        return null;
      }
    }
    return decoded;
  } catch (e) {
    secureLog("JSON decode failed in context [$context]: $e");
    return null;
  }
}

// Automatic Handshake & User-Agent Interceptor for APK-only API protection
class _AppHandshakeHttpClient extends http.BaseClient {
  final http.Client _inner;
  _AppHandshakeHttpClient(this._inner);

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    request.headers[SecureStringVault.hdrHandshake] = SecureStringVault.valHandshake;
    request.headers['User-Agent'] = 'FUSION-SECURE-CLIENT/4.0';
    return _inner.send(request);
  }
}

// Hardened HTTP Client with Anti-MITM Pinning & Rejection
class SecureHttp {
  static const bool enforcePinning = false;
  static http.Client? _client;

  static http.Client get client {
    _client ??= _buildClient();
    return _client!;
  }

  static http.Client _buildClient() {
    final HttpClient ioClient = HttpClient()
      ..badCertificateCallback = (cert, String host, int port) {
        // Reject invalid certs in production
        return !kReleaseMode;
      };

    return _AppHandshakeHttpClient(IOClient(ioClient));
  }
}

// End-to-End Encrypted & HMAC-Signed API Client
class EncryptedApiClient {
  static Future<http.Response> post(
    String url, {
    Map<String, String>? headers,
    Map<String, dynamic>? body,
    Duration timeout = const Duration(seconds: 10),
  }) async {
    final String ts = DateTime.now().millisecondsSinceEpoch.toString();
    final String nonce = _generateNonce();
    final String hwid = await DeviceIdentity.getId();
    final String bodyJson = json.encode(body ?? {});

    // Encrypt payload with AES-256
    final Map<String, String> encResult = Aes256Cbc.encryptString(
      bodyJson,
      SecureStringVault.cryptoSecret,
    );

    final Map<String, dynamic> encryptedBody = {
      "encrypted": true,
      "payload": encResult["payload"],
      "iv": encResult["iv"],
    };
    final String wireBody = json.encode(encryptedBody);

    // Compute HMAC-SHA256 signature on wireBody (Standard Encrypt-then-MAC)
    final String hmacKey = SecureStringVault.hmacSecret;
    final Hmac hmac = Hmac(sha256, utf8.encode(hmacKey));
    final String sig = hmac.convert(utf8.encode("$ts:$nonce:$hwid:$wireBody")).toString();

    final Map<String, String> reqHeaders = {
      "Content-Type": "application/json",
      "Accept": "application/json",
      SecureStringVault.hdrHandshake: SecureStringVault.valHandshake,
      SecureStringVault.hdrTimestamp: ts,
      SecureStringVault.hdrNonce: nonce,
      SecureStringVault.hdrHwid: hwid,
      SecureStringVault.hdrAppVersion: "4.0.0",
      SecureStringVault.hdrSignature: sig,
      SecureStringVault.hdrEncrypted: "1",
      ...?headers,
    };

    return await SecureHttp.client
        .post(
          Uri.parse(url),
          headers: reqHeaders,
          body: wireBody,
        )
        .timeout(timeout);
  }

  static Future<http.Response> get(
    String url, {
    Map<String, String>? headers,
    Duration timeout = const Duration(seconds: 10),
  }) async {
    final String ts = DateTime.now().millisecondsSinceEpoch.toString();
    final String nonce = _generateNonce();
    final String hwid = await DeviceIdentity.getId();

    final String hmacKey = SecureStringVault.hmacSecret;
    final Hmac hmac = Hmac(sha256, utf8.encode(hmacKey));
    final String sig = hmac.convert(utf8.encode("$ts:$nonce:$hwid:GET")).toString();

    final Map<String, String> reqHeaders = {
      "Accept": "application/json",
      SecureStringVault.hdrHandshake: SecureStringVault.valHandshake,
      SecureStringVault.hdrTimestamp: ts,
      SecureStringVault.hdrNonce: nonce,
      SecureStringVault.hdrHwid: hwid,
      SecureStringVault.hdrAppVersion: "4.0.0",
      SecureStringVault.hdrSignature: sig,
      ...?headers,
    };

    return await SecureHttp.client.get(Uri.parse(url), headers: reqHeaders).timeout(timeout);
  }

  static String _generateNonce() {
    final math.Random r = math.Random.secure();
    final List<int> bytes = List<int>.generate(16, (_) => r.nextInt(256));
    return bytes.map((b) => b.toRadixString(16).padLeft(2, "0")).join();
  }
}

// Security Threat Representation
class SecurityViolation {
  final String title;
  final String description;
  final String threatCode;

  const SecurityViolation({
    required this.title,
    required this.description,
    required this.threatCode,
  });
}

// Enterprise Anti-Root, Anti-Frida, Anti-Debugger & Integrity Detection
class TamperDetection {
  static const MethodChannel _nativeSecurity = MethodChannel("com.bn.hackweb/security");
  static bool _compromised = false;
  static SecurityViolation? _lastViolation;

  static bool get isCompromisedSync => _compromised;
  static SecurityViolation? get lastViolation => _lastViolation;

  static Future<SecurityViolation?> checkSecurityViolation() async {
    // In debug mode, allow developer flexibility without crash
    if (!kReleaseMode) {
      return null;
    }

    // 1. Android Native Security MethodChannel
    if (Platform.isAndroid) {
      try {
        final dynamic result = await _nativeSecurity.invokeMethod("checkDeviceSecurity");
        if (result is Map) {
          final bool isCompromised = result["isCompromised"] == true;
          final bool isRooted = result["isRooted"] == true;
          final bool isFrida = result["isFrida"] == true;
          final bool isDebugger = result["isDebugger"] == true;
          final bool isEmulator = result["isEmulator"] == true;

          if (isCompromised) {
            String threat = "ENV_UNSAFE";
            String desc = "An untrusted execution environment was detected.";
            if (isFrida) {
              threat = "HOOKING_FRIDA";
              desc = "Active hooking / instrumentation framework (Frida/Xposed) detected on process.";
            } else if (isRooted) {
              threat = "DEVICE_ROOTED";
              desc = "Superuser privilege escalation or root binaries detected on device.";
            } else if (isDebugger) {
              threat = "DEBUGGER_ACTIVE";
              desc = "A debugger or process tracer is actively attached to this application.";
            } else if (isEmulator) {
              threat = "EMULATOR_SANDBOX";
              desc = "Application must be run on a verified physical hardware device.";
            }

            _compromised = true;
            _lastViolation = SecurityViolation(
              title: "SECURITY BREACH DETECTED",
              description: desc,
              threatCode: threat,
            );
            return _lastViolation;
          }
        }
      } catch (e) {
        secureLog("Native security bridge check error: $e");
      }
    }

    // 2. VPN and Network Packet Capture Interception Check
    try {
      final SecurityViolation? vpnViolation = await _checkVpnAndInterception();
      if (vpnViolation != null) {
        _compromised = true;
        _lastViolation = vpnViolation;
        return _lastViolation;
      }
    } catch (_) {}

    // 3. Pure Dart Heuristic Fallbacks
    try {
      if (await _checkSuPaths()) {
        _compromised = true;
        _lastViolation = const SecurityViolation(
          title: "ROOT ESCALATION DETECTED",
          description: "Superuser su binaries or Magisk/KernelSU paths detected on filesystem.",
          threatCode: "ROOT_BINARY",
        );
        return _lastViolation;
      }
    } catch (_) {}

    try {
      if (await _checkProcMapsForHooks()) {
        _compromised = true;
        _lastViolation = const SecurityViolation(
          title: "RUNTIME HOOK DETECTED",
          description: "Dynamic memory mapping hooks detected in process memory.",
          threatCode: "HOOK_MAPS",
        );
        return _lastViolation;
      }
    } catch (_) {}

    _compromised = false;
    _lastViolation = null;
    return null;
  }

  static Future<SecurityViolation?> _checkVpnAndInterception() async {
    // Check system HTTP/HTTPS proxy configuration against API endpoint
    try {
      final String proxy = HttpClient.findProxyFromEnvironment(Uri.parse(SecureStringVault.baseUrl));
      if (proxy.isNotEmpty && proxy.toUpperCase() != "DIRECT") {
        return const SecurityViolation(
          title: "NETWORK PROXY DETECTED",
          description: "HTTP/HTTPS proxy interception detected on device. Disable proxy to continue.",
          threatCode: "PROXY_ACTIVE",
        );
      }
    } catch (_) {}

    // Check for common packet capture apps / ports / files on Android
    if (Platform.isAndroid) {
      final List<String> pcapPaths = [
        "/data/data/app.greyshirts.sslcapture",
        "/data/data/com.emanuelef.remote_capture",
        "/data/data/com.minhui.networkcapture",
        "/data/data/com.vnet.pcap",
        "/data/data/org.sandrop.webscarab",
        "/data/data/com.guoshi.httpcanary",
        "/sdcard/HttpCanary",
        "/sdcard/Download/HttpCanary",
      ];
      for (final String path in pcapPaths) {
        try {
          if (Directory(path).existsSync() || File(path).existsSync()) {
            return const SecurityViolation(
              title: "PACKET CAPTURE TOOL DETECTED",
              description: "Traffic inspection tool or network sniffer detected on device filesystem.",
              threatCode: "PCAP_TOOL_DETECTED",
            );
          }
        } catch (_) {}
      }
    }

    return null;
  }

  static Future<bool> _checkSuPaths() async {
    if (!Platform.isAndroid) return false;
    final List<String> paths = [
      "/system/app/Superuser.apk",
      "/sbin/su",
      "/system/bin/su",
      "/system/xbin/su",
      "/data/local/xbin/su",
      "/data/local/bin/su",
      "/system/sd/xbin/su",
      "/system/bin/failsafe/su",
      "/data/local/su",
      "/su/bin/su",
      "/sbin/.magisk",
      "/data/adb/magisk",
      "/data/adb/ksu",
      "/data/adb/ap",
    ];
    for (final String path in paths) {
      try {
        if (File(path).existsSync()) return true;
      } catch (_) {}
    }
    return false;
  }

  static Future<bool> _checkProcMapsForHooks() async {
    if (!Platform.isAndroid) return false;
    try {
      final File mapsFile = File("/proc/self/maps");
      if (await mapsFile.exists()) {
        final List<String> lines = await mapsFile.readAsLines();
        for (final String line in lines) {
          final String l = line.toLowerCase();
          if (l.contains("frida-agent") ||
              l.contains("frida-gadget") ||
              l.contains("gum-js") ||
              l.contains("xposed") ||
              l.contains("lsposed") ||
              l.contains("edxposed") ||
              l.contains("substrate")) {
            return true;
          }
        }
      }
    } catch (_) {}
    return false;
  }
}

// ==============================================================================
// 🚨 CRITICAL SYSTEM WARNING & LOCKDOWN ENGINE WITH ACTIVE AUDIO
// ==============================================================================

class CrashEvent {
  final String title;
  final String description;
  final String threatCode;
  final DateTime timestamp;
  final String dumpDetail;
  final bool isApiFailure;
  final VoidCallback? onRetry;

  CrashEvent({
    this.title = "SYSTEM WARNING",
    this.description = "A critical security violation was detected. Unauthorized access attempt.",
    this.threatCode = "SECURITY_ALERT",
    this.dumpDetail = "",
    this.isApiFailure = false,
    this.onRetry,
  }) : timestamp = DateTime.now();
}

class SystemCrashLockdown {
  static final ValueNotifier<CrashEvent?> crashNotifier = ValueNotifier<CrashEvent?>(null);
  static bool _hasCrashed = false;

  static bool get isSystemCrashed => _hasCrashed;

  static const String warningAudioUrl = "";

  static void clearCrash() {
    _hasCrashed = false;
    crashNotifier.value = null;
  }

  static Future<void> triggerCrash({
    String title = "SYSTEM WARNING",
    String description = "A critical security violation was detected. Unauthorized access attempt.",
    String threatCode = "SECURITY_ALERT",
    String dumpDetail = "",
    bool isApiFailure = false,
    VoidCallback? onRetry,
  }) async {
    if (_hasCrashed) return;
    _hasCrashed = true;

    // Purge local storage and session memory immediately
    try {
      await SessionManager.clearSession();
    } catch (_) {}

    final CrashEvent event = CrashEvent(
      title: title,
      description: description,
      threatCode: threatCode,
      dumpDetail: dumpDetail,
      isApiFailure: isApiFailure,
      onRetry: onRetry,
    );

    crashNotifier.value = event;
    secureLog("🚨 [SYSTEM WARNING TRIGGERED] Code: $threatCode | ApiFailure: $isApiFailure");
  }
}

// Fullscreen Animated System Warning Screen with Active Looping Sound (warning.mp3) & Blinking Screen
class SystemCrashScreen extends StatefulWidget {
  final CrashEvent event;
  const SystemCrashScreen({super.key, required this.event});

  @override
  State<SystemCrashScreen> createState() => _SystemCrashScreenState();
}

class _SystemCrashScreenState extends State<SystemCrashScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _pulseCtrl;
  late final AnimationController _blinkCtrl;
  Timer? _hapticTimer;
  WebViewController? _audioWebController;
  AudioPlayer? _audioPlayer;
  bool _isPlaying = false;
  bool _isMuted = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat(reverse: true);

    _blinkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    )..repeat(reverse: true);

    _initAudioEngine();

    // Haptic Vibration Alert
    _hapticTimer = Timer.periodic(const Duration(milliseconds: 650), (_) {
      try {
        HapticFeedback.heavyImpact();
      } catch (_) {}
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
        // App minimized, hidden or closed -> STOP / PAUSE AUDIO IMMEDIATELY
        _pauseWarningAudio();
        break;
      case AppLifecycleState.resumed:
        // App opened / brought back to foreground -> RESUME / START AUDIO IN LOOP
        if (!_isMuted && !_isPlaying) {
          _resumeWarningAudio();
        }
        break;
    }
  }

  Future<void> _initAudioEngine() async {
    // 1. Configure Native AudioPlayer with Alarm AudioContext and Loop
    try {
      _audioPlayer ??= AudioPlayer();
      final AudioPlayer player = _audioPlayer!;
      await player.setReleaseMode(ReleaseMode.loop);
      await player.setVolume(1.0);

      // Force routing to Alarm / Media audio stream with high priority
      try {
        await player.setAudioContext(
          AudioContext(
            android: const AudioContextAndroid(
              isSpeakerphoneOn: true,
              stayAwake: true,
              contentType: AndroidContentType.music,
              usageType: AndroidUsageType.media,
              audioFocus: AndroidAudioFocus.gain,
            ),
            iOS: AudioContextIOS(
              category: AVAudioSessionCategory.playback,
              options: const {AVAudioSessionOptions.mixWithOthers},
            ),
          ),
        );
      } catch (_) {}

      await _startNativeAudioPlayback();
    } catch (e) {
      debugPrint("Native AudioPlayer setup error: $e");
    }

    // 2. Setup Headless WebView HTML5 Audio with Base64 audio as guaranteed fallback
    try {
      String base64Audio = "";
      // Load directly from disk file first if present
      try {
        final File diskFile = File('/sdcard/movies/assets/warning.mp3');
        if (diskFile.existsSync()) {
          base64Audio = base64Encode(diskFile.readAsBytesSync());
        }
      } catch (_) {}

      if (base64Audio.isEmpty) {
        try {
          final ByteData bd = await rootBundle.load('assets/warning.mp3');
          base64Audio = base64Encode(bd.buffer.asUint8List());
        } catch (_) {}
      }

      final String audioSrc = base64Audio.isNotEmpty
          ? "data:audio/mp3;base64,$base64Audio"
          : "";

      final WebViewController controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadHtmlString('''
          <!DOCTYPE html>
          <html>
          <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              html, body { margin: 0; padding: 0; width: 100%; height: 100%; background: transparent; overflow: hidden; }
              #tapArea { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
            </style>
          </head>
          <body>
            <div id="tapArea" onclick="window.playAlarm()">
              <audio id="alarmAudio" loop preload="auto" playsinline src="''' + audioSrc + '''"></audio>
            </div>
            <script>
              var audio = document.getElementById("alarmAudio");

              window.playAlarm = function() {
                if (!audio) audio = document.getElementById("alarmAudio");
                if (!audio) return;
                audio.volume = 1.0;
                audio.muted = false;
                var p = audio.play();
                if (p !== undefined) {
                  p.catch(function(e) {
                    audio.muted = true;
                    audio.play().then(function() {
                      setTimeout(function() {
                        audio.muted = false;
                        audio.volume = 1.0;
                      }, 100);
                    }).catch(function(err) {});
                  });
                }
              };

              window.pauseAlarm = function() {
                if (!audio) audio = document.getElementById("alarmAudio");
                if (audio) audio.pause();
              };

              window.stopAlarm = function() {
                if (!audio) audio = document.getElementById("alarmAudio");
                if (audio) {
                  audio.pause();
                  audio.currentTime = 0;
                  audio.src = "";
                  audio.load();
                }
              };

              window.addEventListener("DOMContentLoaded", window.playAlarm);
              window.addEventListener("load", window.playAlarm);
              document.addEventListener("click", window.playAlarm);
              document.addEventListener("touchstart", window.playAlarm);
              document.addEventListener("pointerdown", window.playAlarm);

              setInterval(function() {
                if (audio && audio.paused && !window._muted) {
                  window.playAlarm();
                }
              }, 500);
            </script>
          </body>
          </html>
        ''');

      if (mounted) {
        setState(() {
          _audioWebController = controller;
        });
      }
    } catch (e) {
      debugPrint("WebView Audio Fallback init error: $e");
    }
  }

  static Uint8List _generateEmergencySirenWav({double durationSeconds = 2.5}) {
    const int sampleRate = 22050;
    final int numSamples = (sampleRate * durationSeconds).toInt();
    final BytesBuilder pcm = BytesBuilder();

    for (int i = 0; i < numSamples; i++) {
      final double t = i / sampleRate;
      final double freq = 800.0 + 800.0 * (0.5 + 0.5 * math.sin(2 * math.pi * 2.5 * t));
      final double s = 32767.0 * 0.95 * math.sin(2 * math.pi * freq * t);
      final int val = s.clamp(-32768.0, 32767.0).toInt();
      pcm.addByte(val & 0xFF);
      pcm.addByte((val >> 8) & 0xFF);
    }

    final Uint8List data = pcm.toBytes();
    final int dataSize = data.length;
    final BytesBuilder wav = BytesBuilder();

    wav.add(ascii.encode('RIFF'));
    final int sizeMinus8 = 36 + dataSize;
    wav.addByte(sizeMinus8 & 0xFF);
    wav.addByte((sizeMinus8 >> 8) & 0xFF);
    wav.addByte((sizeMinus8 >> 16) & 0xFF);
    wav.addByte((sizeMinus8 >> 24) & 0xFF);

    wav.add(ascii.encode('WAVE'));
    wav.add(ascii.encode('fmt '));
    wav.addByte(16); wav.addByte(0); wav.addByte(0); wav.addByte(0);
    wav.addByte(1); wav.addByte(0);
    wav.addByte(1); wav.addByte(0);
    wav.addByte(sampleRate & 0xFF);
    wav.addByte((sampleRate >> 8) & 0xFF);
    wav.addByte((sampleRate >> 16) & 0xFF);
    wav.addByte((sampleRate >> 24) & 0xFF);
    final int byteRate = sampleRate * 2;
    wav.addByte(byteRate & 0xFF);
    wav.addByte((byteRate >> 8) & 0xFF);
    wav.addByte((byteRate >> 16) & 0xFF);
    wav.addByte((byteRate >> 24) & 0xFF);
    wav.addByte(2); wav.addByte(0);
    wav.addByte(16); wav.addByte(0);

    wav.add(ascii.encode('data'));
    wav.addByte(dataSize & 0xFF);
    wav.addByte((dataSize >> 8) & 0xFF);
    wav.addByte((dataSize >> 16) & 0xFF);
    wav.addByte((dataSize >> 24) & 0xFF);
    wav.add(data);

    return wav.toBytes();
  }

  Future<void> _startNativeAudioPlayback() async {
    if (_isMuted) return;
    final AudioPlayer player = _audioPlayer ?? AudioPlayer();
    _audioPlayer = player;
    bool started = false;

    // Strategy A: Direct file on disk
    final List<String> directDiskPaths = [
      '/sdcard/movies/assets/warning.mp3',
      '/sdcard/Download/tithuh-warning-545568.mp3',
    ];
    for (final String path in directDiskPaths) {
      try {
        final File f = File(path);
        if (f.existsSync() && f.lengthSync() > 0) {
          await player.play(DeviceFileSource(path));
          _isPlaying = true;
          started = true;
          debugPrint("Playing warning.mp3 via DeviceFileSource: $path");
          break;
        }
      } catch (e) {
        debugPrint("Error playing $path: $e");
      }
    }

    // Strategy B: Extract from rootBundle to temporary cache file
    if (!started) {
      try {
        final Directory tempDir = await getTemporaryDirectory();
        final File tempFile = File('${tempDir.path}/warning.mp3');
        if (!tempFile.existsSync() || tempFile.lengthSync() == 0) {
          final ByteData bd = await rootBundle.load('assets/warning.mp3');
          await tempFile.writeAsBytes(bd.buffer.asUint8List(), flush: true);
        }
        if (tempFile.existsSync() && tempFile.lengthSync() > 0) {
          await player.play(DeviceFileSource(tempFile.path));
          _isPlaying = true;
          started = true;
          debugPrint("Playing warning.mp3 via temp cache DeviceFileSource");
        }
      } catch (e) {
        debugPrint("Error extracting rootBundle to temp: $e");
      }
    }

    // Strategy C: AssetSource
    if (!started) {
      try {
        await player.play(AssetSource('warning.mp3'));
        _isPlaying = true;
        started = true;
        debugPrint("Playing warning.mp3 via AssetSource('warning.mp3')");
      } catch (_) {
        try {
          await player.play(AssetSource('assets/warning.mp3'));
          _isPlaying = true;
          started = true;
        } catch (_) {}
      }
    }

    // Strategy D: Guaranteed In-Memory Dual-Frequency Warning Siren WAV (NO network/asset required)
    if (!started) {
      try {
        final Uint8List sirenWav = _generateEmergencySirenWav(durationSeconds: 2.5);
        await player.play(BytesSource(sirenWav, mimeType: 'audio/wav'));
        _isPlaying = true;
        started = true;
        debugPrint("Playing synthesized warning siren via BytesSource");
      } catch (e) {
        debugPrint("Error playing synthesized emergency siren: $e");
      }
    }
  }

  Future<void> _pauseWarningAudio() async {
    try {
      await _audioPlayer?.pause();
      _isPlaying = false;
    } catch (_) {}
    try {
      _audioWebController?.runJavaScript("if (window.pauseAlarm) window.pauseAlarm();");
    } catch (_) {}
  }

  Future<void> _resumeWarningAudio() async {
    if (_isMuted) return;
    try {
      if (_audioPlayer != null) {
        await _audioPlayer?.resume();
        _isPlaying = true;
      } else {
        await _startNativeAudioPlayback();
      }
    } catch (_) {
      await _startNativeAudioPlayback();
    }
    try {
      _audioWebController?.runJavaScript("if (window.playAlarm) window.playAlarm();");
    } catch (_) {}
  }

  void _toggleMute() {
    setState(() {
      _isMuted = !_isMuted;
      if (_isMuted) {
        _pauseWarningAudio();
        _audioPlayer?.setVolume(0.0);
        _audioWebController?.runJavaScript("window._muted = true; if (window.pauseAlarm) window.pauseAlarm();");
      } else {
        _audioPlayer?.setVolume(1.0);
        _audioWebController?.runJavaScript("window._muted = false; if (window.playAlarm) window.playAlarm();");
        _resumeWarningAudio();
      }
    });
  }

  Future<void> _stopWarningAudio() async {
    try {
      await _audioPlayer?.stop();
      await _audioPlayer?.dispose();
      _audioPlayer = null;
      _isPlaying = false;
    } catch (_) {}
    try {
      await _audioWebController?.runJavaScript("if (window.stopAlarm) window.stopAlarm();");
      await _audioWebController?.loadHtmlString("<!DOCTYPE html><html><body></body></html>");
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopWarningAudio();
    _pulseCtrl.dispose();
    _blinkCtrl.dispose();
    _hapticTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: AnimatedBuilder(
        animation: Listenable.merge([_pulseCtrl, _blinkCtrl]),
        builder: (context, _) {
          final double blink = _blinkCtrl.value;
          final double pulse = _pulseCtrl.value;

          // WARNING BLINK SCREEN: Alternates between intense warning red and deep hazard dark
          final Color screenBg = Color.lerp(
            const Color(0xFF070002),
            const Color(0xFF330308),
            blink,
          )!;

          final Color strobeBorderColor = Color.lerp(
            const Color(0xFFEF4444),
            const Color(0xFFFFB703),
            blink,
          )!;

          return Scaffold(
            backgroundColor: screenBg,
            body: Listener(
              behavior: HitTestBehavior.translucent,
              onPointerDown: (_) {
                if (!_isMuted) _resumeWarningAudio();
              },
              child: Stack(
                children: [
                  // 1. Audio WebView Engine fallback
                  if (_audioWebController != null)
                    Positioned.fill(
                      child: IgnorePointer(
                        ignoring: true,
                        child: Opacity(
                          opacity: 0.002,
                          child: WebViewWidget(controller: _audioWebController!),
                        ),
                      ),
                    ),

                  // 2. Animated Red Shockwaves & Alarm Background
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _CrashAlarmPainter(pulse: pulse),
                    ),
                  ),

                  // 3. Flashing Strobe Border (Warning Blink Screen Effect)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: strobeBorderColor.withOpacity(0.5 + 0.5 * blink),
                            width: 3.5 + 2.0 * blink,
                          ),
                        ),
                      ),
                    ),
                  ),

                  // 4. Foreground Cyber Warning Alert Content
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      child: Column(
                        children: [
                          // Top Hazard Ribbon Bar
                          _buildHazardStrip(blink),
                          const SizedBox(height: 10),

                          // Warning Audio Active Indicator Badge
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEF4444).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: strobeBorderColor.withOpacity(0.7),
                                width: 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFEF4444).withOpacity(0.3 * blink),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  _isMuted ? Icons.volume_off_rounded : Icons.campaign_rounded,
                                  size: 16,
                                  color: strobeBorderColor,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _isMuted
                                      ? "ALARM MUTED"
                                      : "ALARM SOUND: warning.mp3 ACTIVE [LOOPING]",
                                  style: GoogleFonts.jetBrainsMono(
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w900,
                                    color: strobeBorderColor,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                GestureDetector(
                                  onTap: _toggleMute,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: Colors.black45,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      _isMuted ? "UNMUTE" : "MUTE",
                                      style: GoogleFonts.sora(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w800,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const Spacer(flex: 1),

                          // Pulsing Hazard Warning Shield
                          Container(
                            width: 86 + 8 * pulse,
                            height: 86 + 8 * pulse,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xFFEF4444).withOpacity(0.16 + 0.20 * pulse),
                              border: Border.all(
                                color: strobeBorderColor,
                                width: 2.5 + 1.2 * pulse,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFEF4444).withOpacity(0.45 + 0.40 * blink),
                                  blurRadius: 28 + 10 * blink,
                                  spreadRadius: 4 + 4 * pulse,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Icon(
                                Icons.warning_amber_rounded,
                                color: strobeBorderColor,
                                size: 50,
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Flashing Warning Title
                          Text(
                            widget.event.title.toUpperCase(),
                            textAlign: TextAlign.center,
                            style: GoogleFonts.sora(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: strobeBorderColor,
                              letterSpacing: 1.4,
                              shadows: [
                                Shadow(
                                  color: const Color(0xFFEF4444).withOpacity(0.8),
                                  blurRadius: 18,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),

                          // Threat Code Badge
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEF4444).withOpacity(0.22),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: strobeBorderColor.withOpacity(0.5)),
                            ),
                            child: Text(
                              "ALERT PROTOCOL: ${widget.event.threatCode}",
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFFFCA5A5),
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Description Card
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: const Color(0xFF140205).withOpacity(0.92),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.4)),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  widget.event.description,
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 13.5,
                                    color: const Color(0xFFE2E8F0),
                                    height: 1.4,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                if (widget.event.dumpDetail.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    widget.event.dumpDetail,
                                    textAlign: TextAlign.center,
                                    style: GoogleFonts.jetBrainsMono(
                                      fontSize: 11,
                                      color: const Color(0xFFF87171),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),

                          // Diagnostic Terminal Log
                          Expanded(
                            flex: 3,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.85),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
                              ),
                              child: SingleChildScrollView(
                                physics: const BouncingScrollPhysics(),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _buildDumpLine("> [API PROTOCOL] CONNECTION VERIFICATION ... FAILED"),
                                    _buildDumpLine("> [ALERT SIREN] warning.mp3 BROADCASTING ... ACTIVE"),
                                    _buildDumpLine("> [SCREEN STROBE] HIGH-FREQUENCY BLINK HAZARD ... ON"),
                                    _buildDumpLine("> [GATEWAY] ENDPOINT TIMEOUT OR STATUS REJECTION"),
                                    _buildDumpLine("> [DIAGNOSTIC] CODE: ${widget.event.threatCode}"),
                                    _buildDumpLine("> [TIME] ${widget.event.timestamp.toIso8601String()}"),
                                    _buildDumpLine("> [STATUS] SYSTEM PAUSED PENDING USER RESOLUTION"),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Recovery Actions
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () async {
                                await _stopWarningAudio();
                                SystemCrashLockdown.clearCrash();
                                widget.event.onRetry?.call();
                              },
                              icon: const Icon(Icons.refresh_rounded, size: 20),
                              label: const Text("DISMISS WARNING / RETURN TO APP"),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF00FF87),
                                foregroundColor: Colors.black,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                elevation: 6,
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),

                          // Terminate Application Button
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () async {
                                await _stopWarningAudio();
                                try {
                                  SystemNavigator.pop();
                                } catch (_) {}
                                exit(0);
                              },
                              icon: const Icon(Icons.power_settings_new_rounded, size: 20),
                              label: const Text("TERMINATE APPLICATION"),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFEF4444),
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                elevation: 8,
                                shadowColor: const Color(0xFFEF4444).withOpacity(0.6),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),

                          // Bottom Hazard Ribbon Bar
                          _buildHazardStrip(blink),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHazardStrip(double blink) {
    return Container(
      height: 6,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(3),
        gradient: LinearGradient(
          colors: [
            const Color(0xFFEF4444),
            Color.lerp(const Color(0xFFFFB703), const Color(0xFFEF4444), blink)!,
            const Color(0xFFEF4444),
          ],
        ),
      ),
    );
  }

  Widget _buildDumpLine(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Text(
        text,
        style: GoogleFonts.jetBrainsMono(
          fontSize: 10.5,
          color: const Color(0xFFEF4444).withOpacity(0.9),
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _CrashAlarmPainter extends CustomPainter {
  final double pulse;
  _CrashAlarmPainter({required this.pulse});

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Paint bg = Paint()
      ..shader = RadialGradient(
        center: Alignment.topCenter,
        radius: 1.2,
        colors: [
          const Color(0xFF2A0307).withOpacity(0.40 + 0.30 * pulse),
          const Color(0xFF070002),
        ],
      ).createShader(rect);
    canvas.drawRect(rect, bg);

    final Offset center = Offset(size.width / 2, size.height * 0.22);
    final Paint shockPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    for (int i = 1; i <= 4; i++) {
      final double r = 50.0 * i + (pulse * 35.0 * (5 - i) / 4);
      shockPaint.color = const Color(0xFFEF4444).withOpacity((0.35 / i) * (1.0 - pulse * 0.3));
      canvas.drawCircle(center, r, shockPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _CrashAlarmPainter oldDelegate) => oldDelegate.pulse != pulse;
}

// Backward-compatible wrapper for Dialog references
class SecurityLockdownDialog extends StatelessWidget {
  final SecurityViolation violation;
  const SecurityLockdownDialog({super.key, required this.violation});

  @override
  Widget build(BuildContext context) {
    return SystemCrashScreen(
      event: CrashEvent(
        title: violation.title,
        description: violation.description,
        threatCode: violation.threatCode,
      ),
    );
  }
}

// Obfuscated Endpoints Wrapper
class ApiEndpoints {
  static String get _base => SecureStringVault.baseUrl;

  static String get updateUrl => "$_base${SecureStringVault.statusEndpoint}";
  static String get connectUrl => "$_base${SecureStringVault.connectEndpoint}";
  static String get updateCheckUrl => "$_base${SecureStringVault.updateEndpoint}";
  static String get subscriptionUrl => "$_base${SecureStringVault.subscriptionEndpoint}";
  static String get gamesUrl => "$_base${SecureStringVault.gamesEndpoint}";
  static String get deviceRegisterUrl => "$_base${SecureStringVault.deviceRegisterEndpoint}";
  static String get logosUrl => "$_base${SecureStringVault.logosEndpoint}";
}

// ========== APP REMOTE CONFIGURATION & DYNAMIC UI TEXT CATALOG ==========
class AppRemoteConfig {
  static final AppRemoteConfig instance = AppRemoteConfig._internal();
  AppRemoteConfig._internal();

  final ValueNotifier<int> changeNotifier = ValueNotifier<int>(0);

  bool appEnabled = true;
  bool isMaintenance = false;
  String maintenanceTitle = 'VIP Maintenance';
  String maintenanceMsg = 'System is currently undergoing optimization. Back online shortly!';
  String maintenanceContactUrl = 'https://t.me/satyam_vip';

  bool updateAvailable = false;
  String latestVersion = '4.0.0';
  int latestBuild = 1;
  bool forceUpdate = false;
  String updateDownloadUrl = 'http://api.satyamhosting.shop/download/fusion.apk';
  String updateChangelog = 'Version 4.0 VIP release with ultra-fast AI predictions and 90 FPS real-time engine.';

  bool showSlideScreens = true;
  bool showLoginPage = true;
  bool acceptAnyKey = true;
  int acceptAnyKeyDays = 7;
  bool showDashboard = true;
  bool showGamePage = true;
  bool predictionEnabled = true;
  List<String> predictionModes = ['WINGO 1M', 'WINGO 30S'];

  bool noticeEnabled = false;
  String noticeTitle = 'VIP Announcement';
  String noticeMsg = 'Welcome to FUSION 4.0 VIP Engine.';
  String noticeBtnText = 'CLAIM VIP';
  String noticeBtnUrl = 'https://t.me/satyam_vip';

  String appLogoUrl = 'http://api.satyamhosting.shop/assets/logo.png';
  String splashLogoUrl = 'http://api.satyamhosting.shop/assets/logo.png';

  String sellerContactUrl = 'https://t.me/satyam_vip';
  String sellerContactBtnText = 'CONTACT SELLER ON TELEGRAM';
  String unauthDeviceTitle = 'UNAUTHORIZED DEVICE DETECTED';
  String unauthDeviceMsg = 'Unauthorized device detected. Please contact your seller and ask to give authorized access device.';
  String deviceActivationMode = 'manual';

  // ========== ULTRA VIP REMOTE REAL-TIME TELEMETRY & CONTROLS ==========
  bool vipSignalActive = false;
  String vipSignalTitle = 'ULTRA VIP NEURAL SIGNAL';
  String vipSignalTarget = 'WIN-GO 1M • GREEN (7)';
  String vipSignalColor = 'GREEN';
  String vipSignalConfidence = '99.8%';
  int vipSignalPeriod = 202609250001;
  String vipMarqueeText = '⚡ ULTRA VIP RADAR ACTIVE: 120 FPS REAL-TIME SYNC • 99.8% NEURAL HIT RATE • ZERO-LATENCY ENCRYPTED TUNNEL';
  bool vipUltraSmoothMode = true;
  bool vipHoloBadgeActive = true;
  String vipRemoteTheme = 'CYBER_NEON';

  final Map<String, String> _defaultTexts = {
    'app_name': 'FUSION 4.0 VIP',
    'app_tagline': 'PRECISION COLOR & AI PREDICTION ENGINE',
    'slide1_badge': '🎨 RED • GREEN • VIOLET AI',
    'slide1_title': 'Next-Gen Color Predictor',
    'slide1_desc': 'Engineered with deep neural models for high precision WinGo color and number predictions.',
    'slide1_pill1': 'RED / GREEN / VIOLET',
    'slide1_pill2': 'WIN-GO 1-MIN',
    'slide1_pill3': '99.4% HIT RATE',
    'slide2_badge': '⚡ ULTRA-FAST CLOUD SYNC',
    'slide2_title': 'Instant 1-Min Live Feeds',
    'slide2_desc': 'Zero latency cloud algorithm delivering fast, reliable big/small and color pattern feeds.',
    'slide2_pill1': '1-MIN / 30-SEC',
    'slide2_pill2': 'BIG / SMALL',
    'slide2_pill3': '< 20MS PING',
    'slide3_badge': '🛡️ VIP HARDWARE VAULT',
    'slide3_title': 'Exclusive VIP Vault Access',
    'slide3_desc': 'Access premium game predictions with state-of-the-art military encryption and hardware lock.',
    'slide3_pill1': 'VIP ACCESS',
    'slide3_pill2': 'HWID LOCKED',
    'slide3_pill3': '100% SECURE',
    'slide_skip': 'SKIP INTRO',
    'slide_next': 'NEXT STEP',
    'slide_get_started': 'ENTER VIP VAULT',
    'login_header_title': 'VIP ACCESS TERMINAL',
    'login_header_desc': 'Enter authorized VIP license key to initiate neural synchronization.',
    'login_key_label': 'VIP LICENSE KEY',
    'login_key_hint': 'Enter or paste your VIP key...',
    'login_paste_btn': 'PASTE',
    'login_submit_btn': 'AUTHENTICATE VIP',
    'login_submit_loading': 'VERIFYING CRYPTO PROOF...',
    'login_device_id_label': 'HARDWARE DEVICE ID',
    'login_device_id_hint': 'Tap copy to share with administrator',
    'login_device_id_copied': 'Device ID copied to clipboard!',
    'login_key_pasted': 'License key pasted from clipboard!',
    'login_help_title': 'NEED VIP ACCESS KEY?',
    'login_help_btn': 'CONTACT VIP SUPPORT',
    'login_buy_btn': 'GET INSTANT KEY',
    'login_err_empty': 'Please enter or paste your VIP license key to proceed.',
    'login_err_unreachable': 'Cannot connect to server. Working in resilient offline mode.',
    'login_success_title': 'VIP ACCESS GRANTED',
    'login_success_msg': 'VIP authorization validated successfully. Welcome to FUSION 4.0!',
    'dash_title': 'NEURAL COMMAND CENTER',
    'dash_tag': 'MIL-SPEC SECURE',
    'dash_status_online': 'SYSTEMS ARMED',
    'dash_status_offline': 'OFFLINE RESILIENT',
    'dash_license_valid': 'VIP LICENSE ACTIVE',
    'dash_expires_in': 'TIME REMAINING',
    'dash_latency_label': 'RADAR PING',
    'dash_active_users_label': 'ACTIVE TRADERS',
    'dash_active_users_val': '24,891 ONLINE',
    'dash_stat_accuracy': 'ACCURACY RATE',
    'dash_stat_accuracy_val': '99.4%',
    'dash_stat_model': 'ENGINE CORE',
    'dash_stat_model_val': 'NEURAL v4.2',
    'dash_launch_btn': 'LAUNCH LIVE COLOR RADAR',
    'dash_launch_sub': 'DIRECT ACCESS TO WIN-GO 1M & 30S',
    'dash_device_lock': 'DEVICE HWID LOCKED',
    'games_header_title': 'LIVE WIN-GO RADAR',
    'games_header_badge': 'MILITARY-GRADE FEED',
    'games_subtitle': 'Select color prediction module to begin live signal forecasting.',
    'games_active_traders': '18,420 LIVE TRADERS',
    'games_search_hint': 'Filter prediction modes...',
    'games_cat_all': 'ALL',
    'games_cat_wingo': 'WINGO 1M & 30S',
    'games_cat_trx': 'TRX COLOR',
    'games_cat_high': 'HIGH ACCURACY',
    'games_play_btn': 'ENGAGE PREDICTOR',
    'games_min_bet': 'Min Bet',
    'games_max_bet': 'Max Bet',
    'games_hot_badge': 'HOT SIGNAL',
    'games_empty': 'No games found matching your filter.',
    'wingo_dialog_title': 'SELECT PREDICTION PERIOD',
    'wingo_dialog_sub': 'Choose interval cycle for synchronized forecasting',
    'wingo_mode_1m_title': 'WINGO 1-MINUTE',
    'wingo_mode_1m_desc': 'Standard interval • Balanced neural signal filtering',
    'wingo_mode_30s_title': 'WINGO 30-SECONDS',
    'wingo_mode_30s_desc': 'Flash rapid cycle • High frequency color trend tracking',
    'wingo_launch_btn': 'START AI PREDICTIONS',
    'offline_title': 'SYSTEM OFFLINE',
    'offline_desc': 'Service is currently inactive. Please check back later or retry connection.',
    'offline_retry_btn': 'RETRY SYSTEM CONNECTION',
    'offline_badge': 'OFFLINE RESILIENT',
    'maint_title': 'SCHEDULED VIP MAINTENANCE',
    'maint_desc': 'Our neural clusters are undergoing scheduled optimization for zero-latency predictions.',
    'maint_contact_btn': 'CONTACT VIP TELEGRAM',
    'maint_retry_btn': 'CHECK STATUS AGAIN',
    'update_title': 'CRITICAL VIP UPDATE',
    'update_desc': 'A new version of FUSION VIP is available with improved accuracy and 90 FPS performance.',
    'update_btn': 'UPDATE NOW',
    'update_later_btn': 'LATER',
    'notice_dialog_title': 'VIP ANNOUNCEMENT',
    'notice_dialog_btn': 'ACKNOWLEDGE & PROCEED',
    'unauth_device_title': 'UNAUTHORIZED DEVICE DETECTED',
    'unauth_device_msg': 'Unauthorized device detected. Please contact your seller and ask to give authorized access device.',
    'seller_contact_btn_text': 'CONTACT SELLER ON TELEGRAM',
    'unauth_close_btn': 'CLOSE',
    'device_status_authorized': 'AUTHORIZED',
    'device_status_unauthorized': 'UNAUTHORIZED',
    'dash_device_unauth_btn': 'LOCKED • DEVICE UNAUTHORIZED'
  };

  Map<String, String> _customTexts = {};

  String text(String key, [String fallback = '']) {
    final custom = _customTexts[key];
    if (custom != null && custom.trim().isNotEmpty) {
      return custom;
    }
    final def = _defaultTexts[key];
    if (def != null && def.trim().isNotEmpty) {
      return def;
    }
    return fallback.isNotEmpty ? fallback : key;
  }

  Future<void> init() async {
    await loadFromCache();
  }

  Future<void> loadFromCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      appEnabled = prefs.getBool('cfg_app_enabled') ?? true;
      isMaintenance = prefs.getBool('cfg_is_maintenance') ?? false;
      maintenanceTitle = prefs.getString('cfg_maint_title') ?? maintenanceTitle;
      maintenanceMsg = prefs.getString('cfg_maint_msg') ?? maintenanceMsg;
      maintenanceContactUrl = prefs.getString('cfg_maint_url') ?? maintenanceContactUrl;

      showSlideScreens = prefs.getBool('cfg_show_slide_screens') ?? true;
      showLoginPage = prefs.getBool('cfg_show_login_page') ?? true;
      acceptAnyKey = prefs.getBool('cfg_accept_any_key') ?? true;
      acceptAnyKeyDays = prefs.getInt('cfg_accept_any_key_days') ?? 7;
      showDashboard = prefs.getBool('cfg_show_dashboard') ?? true;
      showGamePage = prefs.getBool('cfg_show_game_page') ?? true;
      predictionEnabled = prefs.getBool('cfg_prediction_enabled') ?? true;

      final rawModes = prefs.getStringList('cfg_prediction_modes');
      if (rawModes != null && rawModes.isNotEmpty) {
        predictionModes = rawModes;
      }

      appLogoUrl = prefs.getString('cfg_app_logo_url') ?? appLogoUrl;
      splashLogoUrl = prefs.getString('cfg_splash_logo_url') ?? splashLogoUrl;

      sellerContactUrl = prefs.getString('cfg_seller_contact_url') ?? sellerContactUrl;
      sellerContactBtnText = prefs.getString('cfg_seller_contact_btn_text') ?? sellerContactBtnText;
      unauthDeviceTitle = prefs.getString('cfg_unauth_device_title') ?? unauthDeviceTitle;
      unauthDeviceMsg = prefs.getString('cfg_unauth_device_msg') ?? unauthDeviceMsg;
      deviceActivationMode = prefs.getString('cfg_device_activation_mode') ?? deviceActivationMode;

      vipSignalActive = prefs.getBool('cfg_vip_signal_active') ?? false;
      vipSignalTitle = prefs.getString('cfg_vip_signal_title') ?? vipSignalTitle;
      vipSignalTarget = prefs.getString('cfg_vip_signal_target') ?? vipSignalTarget;
      vipSignalColor = prefs.getString('cfg_vip_signal_color') ?? vipSignalColor;
      vipSignalConfidence = prefs.getString('cfg_vip_signal_confidence') ?? vipSignalConfidence;
      vipSignalPeriod = prefs.getInt('cfg_vip_signal_period') ?? vipSignalPeriod;
      vipMarqueeText = prefs.getString('cfg_vip_marquee_text') ?? vipMarqueeText;
      vipUltraSmoothMode = prefs.getBool('cfg_vip_ultra_smooth_mode') ?? true;
      vipHoloBadgeActive = prefs.getBool('cfg_vip_holo_badge_active') ?? true;
      vipRemoteTheme = prefs.getString('cfg_vip_remote_theme') ?? vipRemoteTheme;

      final cachedTextsStr = prefs.getString('cfg_app_texts');
      if (cachedTextsStr != null && cachedTextsStr.isNotEmpty) {
        final decoded = json.decode(cachedTextsStr);
        if (decoded is Map) {
          _customTexts = decoded.map((k, v) => MapEntry(k.toString(), v.toString()));
        }
      }
      changeNotifier.value++;
    } catch (e) {
      secureLog('Error loading remote config cache: $e');
    }
  }

  Future<void> saveToCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('cfg_app_enabled', appEnabled);
      await prefs.setBool('cfg_is_maintenance', isMaintenance);
      await prefs.setString('cfg_maint_title', maintenanceTitle);
      await prefs.setString('cfg_maint_msg', maintenanceMsg);
      await prefs.setString('cfg_maint_url', maintenanceContactUrl);

      await prefs.setBool('cfg_show_slide_screens', showSlideScreens);
      await prefs.setBool('cfg_show_login_page', showLoginPage);
      await prefs.setBool('cfg_accept_any_key', acceptAnyKey);
      await prefs.setInt('cfg_accept_any_key_days', acceptAnyKeyDays);
      await prefs.setBool('cfg_show_dashboard', showDashboard);
      await prefs.setBool('cfg_show_game_page', showGamePage);
      await prefs.setBool('cfg_prediction_enabled', predictionEnabled);
      await prefs.setStringList('cfg_prediction_modes', predictionModes);

      await prefs.setString('cfg_app_logo_url', appLogoUrl);
      await prefs.setString('cfg_splash_logo_url', splashLogoUrl);

      await prefs.setString('cfg_seller_contact_url', sellerContactUrl);
      await prefs.setString('cfg_seller_contact_btn_text', sellerContactBtnText);
      await prefs.setString('cfg_unauth_device_title', unauthDeviceTitle);
      await prefs.setString('cfg_unauth_device_msg', unauthDeviceMsg);
      await prefs.setString('cfg_device_activation_mode', deviceActivationMode);

      await prefs.setBool('cfg_vip_signal_active', vipSignalActive);
      await prefs.setString('cfg_vip_signal_title', vipSignalTitle);
      await prefs.setString('cfg_vip_signal_target', vipSignalTarget);
      await prefs.setString('cfg_vip_signal_color', vipSignalColor);
      await prefs.setString('cfg_vip_signal_confidence', vipSignalConfidence);
      await prefs.setInt('cfg_vip_signal_period', vipSignalPeriod);
      await prefs.setString('cfg_vip_marquee_text', vipMarqueeText);
      await prefs.setBool('cfg_vip_ultra_smooth_mode', vipUltraSmoothMode);
      await prefs.setBool('cfg_vip_holo_badge_active', vipHoloBadgeActive);
      await prefs.setString('cfg_vip_remote_theme', vipRemoteTheme);

      await prefs.setString('cfg_app_texts', json.encode(_customTexts));
    } catch (e) {
      secureLog('Error saving remote config cache: $e');
    }
  }

  void updateFromMap(Map<String, dynamic> data) {
    if (data.containsKey('app_enabled')) {
      appEnabled = data['app_enabled'] == true || data['app_enabled'] == '1' || data['app_enabled'] == 1;
    }

    final maint = data['maintenance'];
    if (maint is Map) {
      isMaintenance = maint['enabled'] == true || maint['enabled'] == '1' || maint['enabled'] == 1;
      if (maint['title'] != null) maintenanceTitle = maint['title'].toString();
      if (maint['message'] != null) maintenanceMsg = maint['message'].toString();
      if (maint['contact_url'] != null) maintenanceContactUrl = maint['contact_url'].toString();
    }

    final controls = data['controls'];
    if (controls is Map) {
      if (controls.containsKey('show_slide_screens')) {
        showSlideScreens = controls['show_slide_screens'] == true || controls['show_slide_screens'] == '1' || controls['show_slide_screens'] == 1;
      }
      if (controls.containsKey('show_login_page')) {
        showLoginPage = controls['show_login_page'] == true || controls['show_login_page'] == '1' || controls['show_login_page'] == 1;
      }
      if (controls.containsKey('accept_any_key')) {
        acceptAnyKey = controls['accept_any_key'] == true || controls['accept_any_key'] == '1' || controls['accept_any_key'] == 1;
      }
      if (controls.containsKey('accept_any_key_days')) {
        acceptAnyKeyDays = int.tryParse(controls['accept_any_key_days'].toString()) ?? 7;
      }
      if (controls.containsKey('show_dashboard')) {
        showDashboard = controls['show_dashboard'] == true || controls['show_dashboard'] == '1' || controls['show_dashboard'] == 1;
      }
      if (controls.containsKey('show_game_page')) {
        showGamePage = controls['show_game_page'] == true || controls['show_game_page'] == '1' || controls['show_game_page'] == 1;
      }
      if (controls.containsKey('prediction_enabled')) {
        predictionEnabled = controls['prediction_enabled'] == true || controls['prediction_enabled'] == '1' || controls['prediction_enabled'] == 1;
      }
      if (controls['prediction_modes'] is List) {
        predictionModes = (controls['prediction_modes'] as List).map((e) => e.toString()).toList();
      }
    }

    final notice = data['notice'];
    if (notice is Map) {
      noticeEnabled = notice['enabled'] == true || notice['enabled'] == '1' || notice['enabled'] == 1;
      if (notice['title'] != null) noticeTitle = notice['title'].toString();
      if (notice['message'] != null) noticeMsg = notice['message'].toString();
      if (notice['button_text'] != null) noticeBtnText = notice['button_text'].toString();
      if (notice['button_url'] != null) noticeBtnUrl = notice['button_url'].toString();
    }

    final update = data['update'];
    if (update is Map) {
      if (update['version'] != null) latestVersion = update['version'].toString();
      if (update['version_code'] != null) latestBuild = int.tryParse(update['version_code'].toString()) ?? 1;
      if (update['force_update'] != null) forceUpdate = update['force_update'] == true || update['force_update'] == '1' || update['force_update'] == 1;
      if (update['download_url'] != null) updateDownloadUrl = update['download_url'].toString();
      if (update['changelog'] != null) updateChangelog = update['changelog'].toString();
    }

    final logos = data['logos'];
    if (logos is Map) {
      if (logos['app_logo_url'] != null) appLogoUrl = logos['app_logo_url'].toString();
      if (logos['splash_logo_url'] != null) splashLogoUrl = logos['splash_logo_url'].toString();
    }

    final seller = data['seller_contact'];
    if (seller is Map) {
      if (seller['url'] != null) sellerContactUrl = seller['url'].toString();
      if (seller['button_text'] != null) sellerContactBtnText = seller['button_text'].toString();
      if (seller['unauth_title'] != null) unauthDeviceTitle = seller['unauth_title'].toString();
      if (seller['unauth_message'] != null) unauthDeviceMsg = seller['unauth_message'].toString();
    }

    if (data['seller_contact_url'] != null) sellerContactUrl = data['seller_contact_url'].toString();
    if (data['seller_contact_btn_text'] != null) sellerContactBtnText = data['seller_contact_btn_text'].toString();
    if (data['unauth_device_title'] != null) unauthDeviceTitle = data['unauth_device_title'].toString();
    if (data['unauth_device_msg'] != null) unauthDeviceMsg = data['unauth_device_msg'].toString();
    if (data['device_activation_mode'] != null) deviceActivationMode = data['device_activation_mode'].toString();

    final vip = data['vip_features'] ?? data['vip'];
    if (vip is Map) {
      if (vip['signal_active'] != null) vipSignalActive = vip['signal_active'] == true || vip['signal_active'] == '1' || vip['signal_active'] == 1;
      if (vip['signal_title'] != null) vipSignalTitle = vip['signal_title'].toString();
      if (vip['signal_target'] != null) vipSignalTarget = vip['signal_target'].toString();
      if (vip['signal_color'] != null) vipSignalColor = vip['signal_color'].toString();
      if (vip['signal_confidence'] != null) vipSignalConfidence = vip['signal_confidence'].toString();
      if (vip['signal_period'] != null) vipSignalPeriod = int.tryParse(vip['signal_period'].toString()) ?? vipSignalPeriod;
      if (vip['marquee_text'] != null) vipMarqueeText = vip['marquee_text'].toString();
      if (vip['ultra_smooth_mode'] != null) vipUltraSmoothMode = vip['ultra_smooth_mode'] == true || vip['ultra_smooth_mode'] == '1' || vip['ultra_smooth_mode'] == 1;
      if (vip['holo_badge_active'] != null) vipHoloBadgeActive = vip['holo_badge_active'] == true || vip['holo_badge_active'] == '1' || vip['holo_badge_active'] == 1;
      if (vip['remote_theme'] != null) vipRemoteTheme = vip['remote_theme'].toString();
    }

    final texts = data['texts'];
    if (texts is Map) {
      _customTexts = texts.map((k, v) => MapEntry(k.toString(), v.toString()));
    }

    saveToCache();
    changeNotifier.value++;
  }
}

// ========== LUXURY SERVICE OFFLINE SCREEN ==========
class AppOfflineScreen extends StatefulWidget {
  final VoidCallback onRetry;
  const AppOfflineScreen({super.key, required this.onRetry});

  @override
  State<AppOfflineScreen> createState() => _AppOfflineScreenState();
}

class _AppOfflineScreenState extends State<AppOfflineScreen>
    with SingleTickerProviderStateMixin, ThemeReactive<AppOfflineScreen> {
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    initThemeListener();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    disposeThemeListener();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final String title = AppRemoteConfig.instance.text('offline_title', 'SYSTEM OFFLINE');
    final String desc = AppRemoteConfig.instance.text('offline_desc', 'Service is currently inactive. Please check back later or retry connection.');
    final String retry = AppRemoteConfig.instance.text('offline_retry_btn', 'RETRY SYSTEM CONNECTION');
    final String badge = AppRemoteConfig.instance.text('offline_badge', 'OFFLINE RESILIENT');

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF070B14) : const Color(0xFFF8FAFC),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (context, child) {
                    final double scale = 1.0 + (_pulseCtrl.value * 0.08);
                    return Transform.scale(
                      scale: scale,
                      child: Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFFEF4444).withOpacity(0.12),
                          border: Border.all(
                            color: const Color(0xFFEF4444).withOpacity(0.6 + (_pulseCtrl.value * 0.4)),
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFEF4444).withOpacity(0.35 * _pulseCtrl.value),
                              blurRadius: 28,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.power_settings_new_rounded,
                          size: 48,
                          color: Color(0xFFEF4444),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 28),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
                  ),
                  child: Text(
                    badge,
                    style: const TextStyle(
                      color: Color(0xFFEF4444),
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  desc,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                    fontSize: 14,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 36),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: widget.onRetry,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 4,
                    ),
                    child: Text(
                      retry,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, letterSpacing: 0.8),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Dynamic Online Logo Manager with SHA256 Verification & Cache
class LogoManager {
  static final ValueNotifier<File?> activeLogoNotifier = ValueNotifier<File?>(null);
  static String? _activeLogoId;
  static String? get activeLogoId => _activeLogoId;
  static bool _isSyncing = false;

  static Future<Directory> getLogoDirectory() async {
    Directory? baseDir;
    if (Platform.isAndroid) {
      try {
        baseDir = await getExternalStorageDirectory();
      } catch (e) {
        secureLog("External storage error: $e");
      }
    }
    baseDir ??= await getApplicationDocumentsDirectory();
    final Directory logoDir = Directory("${baseDir.path}/files/logo");
    if (!await logoDir.exists()) {
      await logoDir.create(recursive: true);
    }
    return logoDir;
  }

  static Future<void> init() async {
    await _loadCachedLogo();
    syncWithServer();
  }

  static Future<void> _loadCachedLogo() async {
    try {
      final Directory dir = await getLogoDirectory();
      final List<FileSystemEntity> files = dir.listSync();
      File? latestDat;
      DateTime? latestTime;
      for (final FileSystemEntity entity in files) {
        if (entity is File && entity.path.endsWith(".dat")) {
          final DateTime modified = entity.lastModifiedSync();
          if (latestTime == null || modified.isAfter(latestTime)) {
            latestTime = modified;
            latestDat = entity;
          }
        }
      }
      if (latestDat != null && await latestDat.exists()) {
        activeLogoNotifier.value = latestDat;
      }
    } catch (e) {
      secureLog("Cache logo load error: $e");
    }
  }

  static Future<void> syncWithServer() async {
    if (_isSyncing) return;
    _isSyncing = true;
    try {
      final http.Response response = await SecureHttp.client
          .get(
            Uri.parse(ApiEndpoints.logosUrl),
            headers: {
              SecureStringVault.hdrHandshake: SecureStringVault.valHandshake,
            },
          )
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final dynamic decoded = safeJsonDecode(response.body);
        if (decoded is! Map<String, dynamic>) return;
        final List<dynamic> logosList = decoded["logos"] ?? [];
        Map<String, dynamic>? activeLogo;
        for (final dynamic item in logosList) {
          if (item is Map<String, dynamic> && item["active"] == true) {
            activeLogo = item;
            break;
          }
        }
        if (activeLogo != null) {
          final String logoId = (activeLogo["id"] ?? "").toString();
          final String logoUrl = (activeLogo["image_url"] ?? "").toString();
          final String shaExpected = (activeLogo["sha256"] ?? "").toString();
          if (logoId.isNotEmpty && logoUrl.isNotEmpty) {
            await _downloadAndCacheLogo(logoId, logoUrl, shaExpected);
          }
        }
      }
    } catch (e) {
      secureLog("Logo sync error: $e");
    } finally {
      _isSyncing = false;
    }
  }

  static Future<void> _downloadAndCacheLogo(String id, String url, [String? sha256Expected]) async {
    try {
      final Directory dir = await getLogoDirectory();
      final String filePath = "${dir.path}/logo_$id.dat";
      final File targetFile = File(filePath);

      if (await targetFile.exists() && await targetFile.length() > 0) {
        activeLogoNotifier.value = targetFile;
        _activeLogoId = id;
        return;
      }

      final http.Response imgRes = await SecureHttp.client.get(Uri.parse(url)).timeout(const Duration(seconds: 10));
      if (imgRes.statusCode == 200 && imgRes.bodyBytes.isNotEmpty) {
        // Optional integrity hash validation
        if (sha256Expected != null && sha256Expected.isNotEmpty) {
          final String actualHash = sha256.convert(imgRes.bodyBytes).toString();
          if (actualHash.toLowerCase() != sha256Expected.toLowerCase()) {
            secureLog("Downloaded logo hash mismatch! Discarding.");
            return;
          }
        }

        await targetFile.writeAsBytes(imgRes.bodyBytes, flush: true);
        activeLogoNotifier.value = targetFile;
        _activeLogoId = id;

        final List<FileSystemEntity> files = dir.listSync();
        for (final FileSystemEntity entity in files) {
          if (entity is File && entity.path.endsWith(".dat") && entity.path != filePath) {
            try {
              entity.deleteSync();
            } catch (_) {}
          }
        }
      }
    } catch (e) {
      secureLog("Logo download error: $e");
    }
  }
}

// Cyber Animated Circular Logo with RGB Sweep Ring
class CircularLogoWidget extends StatefulWidget {
  final double size;
  final double borderWidth;
  final Color? borderColor;

  const CircularLogoWidget({
    super.key,
    this.size = 54,
    this.borderWidth = 1.5,
    this.borderColor,
  });

  @override
  State<CircularLogoWidget> createState() => _CircularLogoWidgetState();
}

class _CircularLogoWidgetState extends State<CircularLogoWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _rotationCtrl;

  @override
  void initState() {
    super.initState();
    _rotationCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
  }

  @override
  void dispose() {
    _rotationCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final Color border = widget.borderColor ?? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669));

    return AnimatedBuilder(
      animation: _rotationCtrl,
      builder: (context, child) {
        return ValueListenableBuilder<File?>(
          valueListenable: LogoManager.activeLogoNotifier,
          builder: (context, file, _) {
            return Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: SweepGradient(
                  transform: GradientRotation(_rotationCtrl.value * 2 * math.pi),
                  colors: [
                    border,
                    const Color(0xFF00E5FF),
                    const Color(0xFF7B61FF),
                    border,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: border.withOpacity(0.35),
                    blurRadius: 14,
                    spreadRadius: 1,
                  ),
                ],
              ),
              padding: EdgeInsets.all(widget.borderWidth),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isDark ? const Color(0xFF09142E) : Colors.white,
                ),
                child: ClipOval(
                  child: file != null && file.existsSync()
                      ? Image.file(
                          file,
                          width: widget.size,
                          height: widget.size,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _buildFallback(border, isDark),
                        )
                      : (AppRemoteConfig.instance.appLogoUrl.isNotEmpty &&
                              Uri.tryParse(AppRemoteConfig.instance.appLogoUrl)?.hasScheme == true)
                          ? Image.network(
                              AppRemoteConfig.instance.appLogoUrl,
                              width: widget.size,
                              height: widget.size,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => _buildFallback(border, isDark),
                            )
                          : _buildFallback(border, isDark),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildFallback(Color border, bool isDark) {
    return Container(
      color: isDark ? const Color(0xFF09142E) : const Color(0xFFF1F5F9),
      child: Center(
        child: Icon(
          Icons.shield_rounded,
          size: widget.size * 0.55,
          color: border,
        ),
      ),
    );
  }
}

// Hardware Device Identity Manager (HWID Locked)
class DeviceIdentity {
  static const FlutterSecureStorage _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static String get _deviceIdKey => SecureStringVault.keyDeviceId;
  static String? _cachedId;
  static String? _cachedName;

  static Future<String> getId() async {
    if (_cachedId != null && _cachedId!.isNotEmpty) return _cachedId!;
    try {
      final String? stored = await _storage.read(key: _deviceIdKey);
      if (stored != null && stored.isNotEmpty) {
        _cachedId = stored;
        return stored;
      }
    } catch (e) {
      secureLog("Storage read error: $e");
    }

    // Generate persistent hardware-backed or deterministic fallback device ID locally
    // Never invoke syncWithServer() here because EncryptedApiClient calls getId() synchronously!
    String generatedId = "F4-${DateTime.now().millisecondsSinceEpoch.toRadixString(16).toUpperCase()}";
    try {
      final DeviceInfoPlugin info = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        final AndroidDeviceInfo android = await info.androidInfo;
        if (android.id.isNotEmpty && android.id.toLowerCase() != "unknown") {
          generatedId = "F4-${android.id.toUpperCase()}";
        }
      }
    } catch (e) {
      secureLog("DeviceInfo error: $e");
    }

    try {
      await _storage.write(key: _deviceIdKey, value: generatedId);
    } catch (e) {
      secureLog("Storage write error: $e");
    }

    _cachedId = generatedId;
    return generatedId;
  }

  static Future<DeviceSyncResult> syncWithServer() async {
    String? localId;
    try {
      localId = await _storage.read(key: _deviceIdKey);
    } catch (_) {}

    final String deviceName = await getDeviceName();

    try {
      final http.Response response = await EncryptedApiClient.post(
        ApiEndpoints.deviceRegisterUrl,
        body: {
          if (localId != null && localId.isNotEmpty) SecureStringVault.paramDeviceId: localId,
          SecureStringVault.paramDeviceName: deviceName,
        },
      );

      if (response.statusCode == 200) {
        final dynamic decoded = safeJsonDecode(response.body);
        if (decoded is Map<String, dynamic> && decoded["status"] == true) {
          final Map<String, dynamic> data = decoded["data"] ?? {};
          final String serverDeviceId = (data["device_id"] ?? "").toString();
          final bool sdkActive = data["sdk_active"] == true;
          if (data["seller_contact_url"] != null || data["seller_contact"] != null) {
            AppRemoteConfig.instance.updateFromMap(data);
          }
          await _storage.write(key: 'cached_device_auth_status', value: sdkActive ? '1' : '0');

          if (serverDeviceId.isNotEmpty) {
            await _storage.write(key: _deviceIdKey, value: serverDeviceId);
            _cachedId = serverDeviceId;
            return DeviceSyncResult(deviceId: serverDeviceId, sdkActive: sdkActive);
          }
        }
      }
    } catch (e) {
      secureLog("Device sync failed: $e");
    }

    final String fallback = localId ?? "BN-${DateTime.now().millisecondsSinceEpoch.toRadixString(16).toUpperCase()}";
    String? cachedAuth;
    try {
      cachedAuth = await _storage.read(key: 'cached_device_auth_status');
    } catch (_) {}
    final bool fallbackAuth = cachedAuth == '1';
    return DeviceSyncResult(deviceId: fallback, sdkActive: fallbackAuth);
  }

  static Future<String> getDeviceName() async {
    if (_cachedName != null) return _cachedName!;
    final DeviceInfoPlugin info = DeviceInfoPlugin();
    try {
      if (Platform.isAndroid) {
        final AndroidDeviceInfo android = await info.androidInfo;
        _cachedName = "${android.brand} ${android.model}";
      } else if (Platform.isIOS) {
        final IosDeviceInfo ios = await info.iosInfo;
        _cachedName = ios.utsname.machine;
      } else {
        _cachedName = "VIP Device";
      }
    } catch (e) {
      _cachedName = "VIP Device";
    }
    return _cachedName!;
  }
}

class DeviceSyncResult {
  final String deviceId;
  final bool sdkActive;
  const DeviceSyncResult({required this.deviceId, required this.sdkActive});
}

// Encrypted Session & License Manager
class SessionManager {
  static const FlutterSecureStorage _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static String get _isLoggedIn => SecureStringVault.keyIsLoggedIn;
  static String get _licenseKey => SecureStringVault.keyLicenseKey;
  static String get _expiryDate => SecureStringVault.keyExpiryDate;
  static String get _lastVerifiedAt => SecureStringVault.keyLastVerified;

  static const Duration serverRevalidationInterval = Duration(minutes: 15);

  static Future<void> saveSession(String key, String expiry) async {
    await _storage.write(key: _isLoggedIn, value: "true");
    await _storage.write(key: _licenseKey, value: key);
    await _storage.write(key: _expiryDate, value: expiry);
    await _storage.write(key: _lastVerifiedAt, value: DateTime.now().toIso8601String());
  }

  static Future<bool> isLoggedIn() async {
    return (await _storage.read(key: _isLoggedIn)) == "true";
  }

  static Future<bool> _isLocallyWithinExpiry() async {
    final bool loggedIn = await isLoggedIn();
    if (!loggedIn) return false;

    final String expiryStr = await _storage.read(key: _expiryDate) ?? "";
    if (expiryStr.isEmpty) return false;

    try {
      final DateTime expiryDate = DateTime.parse(expiryStr);
      return DateTime.now().isBefore(expiryDate);
    } catch (e) {
      return false;
    }
  }

  static Future<bool> isSDKActive() async {
    if (!await _isLocallyWithinExpiry()) return false;

    final String lastVerifiedStr = await _storage.read(key: _lastVerifiedAt) ?? "";
    DateTime? lastVerified;
    try {
      lastVerified = lastVerifiedStr.isNotEmpty ? DateTime.parse(lastVerifiedStr) : null;
    } catch (_) {
      lastVerified = null;
    }

    final bool needsServerCheck =
        lastVerified == null || DateTime.now().difference(lastVerified) > serverRevalidationInterval;

    if (!needsServerCheck) return true;

    return verifyActiveWithServer();
  }

  static bool _deviceUnauthorized = false;
  static bool get isDeviceUnauthorized => _deviceUnauthorized;

  static Future<bool> verifyActiveWithServer() async {
    final String? key = await getLicenseKey();
    if (key == null || key.isEmpty) return false;

    try {
      final String deviceId = await DeviceIdentity.getId();
      final http.Response response = await EncryptedApiClient.post(
        ApiEndpoints.connectUrl,
        body: {
          SecureStringVault.paramGame: "BGMI",
          SecureStringVault.paramUserKey: key,
          SecureStringVault.paramSerial: deviceId,
          SecureStringVault.paramPackage: "com.bn.hackweb",
        },
      );

      secureLog("Re-validation HTTP status: ${response.statusCode}");

      if (response.statusCode != 200) {
        return await _isLocallyWithinExpiry();
      }

      final dynamic decoded = safeJsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return await _isLocallyWithinExpiry();

      final dynamic rawStatus = decoded["status"];
      final bool serverSaysActive =
          rawStatus == true || rawStatus == "true" || rawStatus == 1 || rawStatus == "success";
      final Map<String, dynamic>? data = decoded["data"] is Map<String, dynamic>
          ? (decoded["data"] as Map<String, dynamic>)
          : (decoded["expiredDate"] != null ? decoded : null);
      final String? newExpiry = data?["expiredDate"]?.toString();

      secureLog("Re-validation response: active=$serverSaysActive");

      if (!serverSaysActive) {
        await clearSession();
        _deviceUnauthorized = false;
        return false;
      }

      if (newExpiry != null && newExpiry.isNotEmpty) {
        await _storage.write(key: _expiryDate, value: newExpiry);
      }
      await _storage.write(key: _lastVerifiedAt, value: DateTime.now().toIso8601String());
    } catch (e) {
      secureLog("Server re-validation failed: $e");
      return await _isLocallyWithinExpiry();
    }

    final bool deviceAuthorized = await checkDeviceAuthorization();
    _deviceUnauthorized = !deviceAuthorized;
    return deviceAuthorized;
  }

  static Future<bool> checkDeviceAuthorization() async {
    final DeviceSyncResult result = await DeviceIdentity.syncWithServer();
    return result.sdkActive;
  }

  static Future<void> clearSession() async {
    await _storage.delete(key: _isLoggedIn);
    await _storage.delete(key: _licenseKey);
    await _storage.delete(key: _expiryDate);
    await _storage.delete(key: _lastVerifiedAt);
  }

  static Future<String?> getLicenseKey() async {
    return _storage.read(key: _licenseKey);
  }
}

// ========== REUSABLE UI COMPONENTS ==========

class _PressScale extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressScale({super.key, required this.child, required this.onTap});

  @override
  State<_PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<_PressScale> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: widget.child,
      ),
    );
  }
}

class _GlassContainer extends StatelessWidget {
  final Widget child;
  final double borderRadius;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final List<Color>? gradientColors;
  final BoxBorder? border;
  final List<BoxShadow>? boxShadow;

  const _GlassContainer({
    super.key,
    required this.child,
    this.borderRadius = 20,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.gradientColors,
    this.border,
    this.boxShadow,
  });

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final List<Color> colors = gradientColors ??
        (isDark
            ? [
                const Color(0xFF0F1B3B).withOpacity(0.88),
                const Color(0xFF0A1227).withOpacity(0.94),
              ]
            : [
                const Color(0xFFFFFFFF),
                const Color(0xFFF8FAFC),
              ]);

    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: border ??
            Border.all(
              color: isDark
                  ? const Color(0xFF1E2D5A).withOpacity(0.6)
                  : const Color(0xFFE2E8F0),
              width: 1.2,
            ),
        boxShadow: boxShadow ??
            [
              BoxShadow(
                color: isDark
                    ? Colors.black.withOpacity(0.35)
                    : const Color(0xFF64748B).withOpacity(0.08),
                blurRadius: isDark ? 20 : 16,
                offset: const Offset(0, 4),
              ),
            ],
      ),
      child: child,
    );
  }
}

class _PulseGreenDot extends StatefulWidget {
  final double size;
  final Color? color;
  const _PulseGreenDot({
    super.key,
    this.size = 8,
    this.color,
  });

  @override
  State<_PulseGreenDot> createState() => _PulseGreenDotState();
}

class _PulseGreenDotState extends State<_PulseGreenDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final Color dotColor = widget.color ?? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669));

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final double scale = 1.0 + _controller.value * 0.4;
        final double opacity = 0.4 + _controller.value * 0.6;
        return Container(
          width: widget.size * scale,
          height: widget.size * scale,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: dotColor.withOpacity(opacity),
            boxShadow: [
              BoxShadow(
                color: dotColor.withOpacity(0.6),
                blurRadius: 8 * scale,
                spreadRadius: 1,
              ),
            ],
          ),
        );
      },
    );
  }
}

class _RgbBorderPainter extends CustomPainter {
  final double animationValue;
  final double borderRadius;
  final double borderWidth;
  final Color backgroundColor;

  _RgbBorderPainter({
    required this.animationValue,
    this.borderRadius = 24.0,
    this.borderWidth = 1.8,
    this.backgroundColor = const Color(0xEE090E1A),
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect rrect = RRect.fromRectAndRadius(rect, Radius.circular(borderRadius));

    final Paint bgPaint = Paint()..color = backgroundColor;
    canvas.drawRRect(rrect, bgPaint);

    final double angle = animationValue * 2 * math.pi;
    final Paint borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = borderWidth
      ..shader = SweepGradient(
        transform: GradientRotation(angle),
        colors: const [
          Color(0xFF00FF87),
          Color(0xFF00E5FF),
          Color(0xFF7B61FF),
          Color(0xFFFF0055),
          Color(0xFF00FF87),
        ],
      ).createShader(rect);

    canvas.drawRRect(rrect, borderPaint);
  }

  @override
  bool shouldRepaint(covariant _RgbBorderPainter oldDelegate) => true;
}

// ========== REAL-TIME CYBER ANIMATION WIDGETS ==========

class _LiveHoloLogoWidget extends StatefulWidget {
  final double size;
  const _LiveHoloLogoWidget({super.key, this.size = 82});

  @override
  State<_LiveHoloLogoWidget> createState() => _LiveHoloLogoWidgetState();
}

class _LiveHoloLogoWidgetState extends State<_LiveHoloLogoWidget>
    with TickerProviderStateMixin {
  late final AnimationController _spinCtrl;
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final Color primaryColor = isDark ? const Color(0xFF00FF87) : const Color(0xFF059669);
    final Color secondaryColor = const Color(0xFF00E5FF);

    return AnimatedBuilder(
      animation: Listenable.merge([_spinCtrl, _pulseCtrl]),
      builder: (context, child) {
        final double pulseScale = 1.0 + (_pulseCtrl.value * 0.05);
        final double outerDim = widget.size + 44;
        return SizedBox(
          width: outerDim,
          height: outerDim,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Radial Bloom Glow
              Container(
                width: outerDim,
                height: outerDim,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      primaryColor.withOpacity(isDark ? 0.28 : 0.14),
                      secondaryColor.withOpacity(isDark ? 0.12 : 0.05),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.55, 1.0],
                  ),
                ),
              ),

              // Custom Painter for Outer Concentric Cyber Holographic Rings
              CustomPaint(
                size: Size(outerDim, outerDim),
                painter: _LiveHoloRingsPainter(
                  spinProgress: _spinCtrl.value,
                  pulseProgress: _pulseCtrl.value,
                  isDark: isDark,
                  primaryColor: primaryColor,
                  secondaryColor: secondaryColor,
                ),
              ),

              // Central Circular Logo with breathing scale
              Transform.scale(
                scale: pulseScale,
                child: CircularLogoWidget(size: widget.size, borderWidth: 2.2),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _LiveHoloRingsPainter extends CustomPainter {
  final double spinProgress;
  final double pulseProgress;
  final bool isDark;
  final Color primaryColor;
  final Color secondaryColor;

  _LiveHoloRingsPainter({
    required this.spinProgress,
    required this.pulseProgress,
    required this.isDark,
    required this.primaryColor,
    required this.secondaryColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final double radius = (size.width / 2) - 4;

    // 1. Outer Tech Ring with Rotating Arc Segments
    final Paint arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;

    final double rotationAngle = spinProgress * 2 * math.pi;

    // Outer ring: 3 arc segments
    const int segments = 3;
    const double sweepAngle = (2 * math.pi / segments) * 0.55;
    for (int i = 0; i < segments; i++) {
      final double startAngle = rotationAngle + (i * 2 * math.pi / segments);
      arcPaint.color = (i % 2 == 0 ? primaryColor : secondaryColor)
          .withOpacity(isDark ? 0.75 : 0.55);
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        arcPaint,
      );
    }

    // 2. Middle Dashed Counter-Rotating Ring
    final Paint midPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    final double midRadius = radius - 8;
    final double counterAngle = -spinProgress * 3 * math.pi;
    const int dotCount = 12;
    for (int i = 0; i < dotCount; i++) {
      final double angle = counterAngle + (i * 2 * math.pi / dotCount);
      final Offset dotPos = Offset(
        center.dx + midRadius * math.cos(angle),
        center.dy + midRadius * math.sin(angle),
      );
      midPaint.color = (i % 3 == 0 ? secondaryColor : primaryColor)
          .withOpacity(isDark ? 0.5 : 0.3);
      canvas.drawCircle(dotPos, 1.3, midPaint..style = PaintingStyle.fill);
    }

    // 3. Orbiting Satellite Nodes
    final double orbitRadius = radius + 1;
    final double sat1Angle = rotationAngle * 1.5;
    final Offset sat1 = Offset(
      center.dx + orbitRadius * math.cos(sat1Angle),
      center.dy + orbitRadius * math.sin(sat1Angle),
    );
    final Paint satPaint = Paint()..style = PaintingStyle.fill;
    satPaint.color = primaryColor;
    canvas.drawCircle(sat1, 2.6, satPaint);

    final double sat2Angle = -rotationAngle * 1.2 + math.pi;
    final Offset sat2 = Offset(
      center.dx + orbitRadius * math.cos(sat2Angle),
      center.dy + orbitRadius * math.sin(sat2Angle),
    );
    satPaint.color = secondaryColor;
    canvas.drawCircle(sat2, 2.2, satPaint);
  }

  @override
  bool shouldRepaint(covariant _LiveHoloRingsPainter oldDelegate) => true;
}

class _AnimatedCyberTitle extends StatefulWidget {
  final String text;
  final double fontSize;
  final double letterSpacing;
  const _AnimatedCyberTitle({
    super.key,
    required this.text,
    this.fontSize = 24,
    this.letterSpacing = 0.8,
  });

  @override
  State<_AnimatedCyberTitle> createState() => _AnimatedCyberTitleState();
}

class _AnimatedCyberTitleState extends State<_AnimatedCyberTitle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (bounds) {
            final double val = _controller.value;
            return LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isDark
                  ? const [
                      Color(0xFFFFFFFF),
                      Color(0xFF00FF87),
                      Color(0xFF00E5FF),
                      Color(0xFFFFFFFF),
                    ]
                  : const [
                      Color(0xFF0F172A),
                      Color(0xFF059669),
                      Color(0xFF0284C7),
                      Color(0xFF0F172A),
                    ],
              stops: [
                (val - 0.3).clamp(0.0, 1.0),
                (val - 0.1).clamp(0.0, 1.0),
                (val + 0.1).clamp(0.0, 1.0),
                (val + 0.3).clamp(0.0, 1.0),
              ],
            ).createShader(bounds);
          },
          child: Text(
            widget.text,
            textAlign: TextAlign.center,
            style: GoogleFonts.sora(
              fontSize: widget.fontSize,
              fontWeight: FontWeight.w900,
              letterSpacing: widget.letterSpacing,
              color: Colors.white,
            ),
          ),
        );
      },
    );
  }
}

class _AnimatedNeonInput extends StatefulWidget {
  final Widget child;
  final bool isFocused;
  const _AnimatedNeonInput({
    super.key,
    required this.child,
    this.isFocused = false,
  });

  @override
  State<_AnimatedNeonInput> createState() => _AnimatedNeonInputState();
}

class _AnimatedNeonInputState extends State<_AnimatedNeonInput>
    with SingleTickerProviderStateMixin {
  late final AnimationController _borderAnim;

  @override
  void initState() {
    super.initState();
    _borderAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _borderAnim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final Color accent = isDark ? const Color(0xFF00FF87) : const Color(0xFF059669);
    final Color cyan = const Color(0xFF00E5FF);

    return AnimatedBuilder(
      animation: _borderAnim,
      builder: (context, _) {
        final double glow = _borderAnim.value;
        final double spread = widget.isFocused ? 2.0 + (glow * 2.0) : 1.0 + (glow * 1.0);
        final double blur = widget.isFocused ? 14.0 + (glow * 6.0) : 8.0 + (glow * 4.0);

        return Container(
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF070E20) : const Color(0xFFF1F5F9),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: Color.lerp(accent, cyan, glow)!.withOpacity(widget.isFocused ? 0.85 : 0.45),
              width: widget.isFocused ? 1.8 : 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(widget.isFocused ? 0.25 : 0.08 * glow),
                blurRadius: blur,
                spreadRadius: spread,
              ),
            ],
          ),
          child: widget.child,
        );
      },
    );
  }
}

class _LiveShimmerButton extends StatefulWidget {
  final VoidCallback onTap;
  final Widget child;
  final bool isLoading;
  final double height;
  final double borderRadius;
  final List<Color>? gradientColors;

  const _LiveShimmerButton({
    super.key,
    required this.onTap,
    required this.child,
    this.isLoading = false,
    this.height = 54,
    this.borderRadius = 16,
    this.gradientColors,
  });

  @override
  State<_LiveShimmerButton> createState() => _LiveShimmerButtonState();
}

class _LiveShimmerButtonState extends State<_LiveShimmerButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();
  }

  @override
  void dispose() {
    _shimmerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final List<Color> colors = widget.gradientColors ??
        const [Color(0xFF00FF87), Color(0xFF00E5FF)];

    return _PressScale(
      onTap: widget.isLoading ? () {} : widget.onTap,
      child: AnimatedBuilder(
        animation: _shimmerCtrl,
        builder: (context, _) {
          return Container(
            width: double.infinity,
            height: widget.height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              gradient: LinearGradient(
                colors: colors,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: colors.first.withOpacity(0.35 + (_shimmerCtrl.value * 0.15)),
                  blurRadius: 16 + (_shimmerCtrl.value * 6),
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              child: Stack(
                children: [
                  Center(
                    child: widget.isLoading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.black),
                            ),
                          )
                        : widget.child,
                  ),
                  if (!widget.isLoading)
                    Positioned.fill(
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          final double w = constraints.maxWidth;
                          final double left = -w + (_shimmerCtrl.value * (w * 2.2));
                          return Transform.translate(
                            offset: Offset(left, 0),
                            child: Transform.rotate(
                              angle: 0.35,
                              child: Container(
                                width: 45,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.white.withOpacity(0.0),
                                      Colors.white.withOpacity(0.40),
                                      Colors.white.withOpacity(0.0),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _LiveRadarLatencyBadge extends StatefulWidget {
  final bool isDark;
  const _LiveRadarLatencyBadge({super.key, required this.isDark});

  @override
  State<_LiveRadarLatencyBadge> createState() => _LiveRadarLatencyBadgeState();
}

class _LiveRadarLatencyBadgeState extends State<_LiveRadarLatencyBadge>
    with SingleTickerProviderStateMixin {
  late final AnimationController _rippleCtrl;

  @override
  void initState() {
    super.initState();
    _rippleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();
  }

  @override
  void dispose() {
    _rippleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: LatencyTracker.pingMs,
      builder: (context, ms, _) {
        final Color latColor = LatencyTracker.getLatencyColor(ms, widget.isDark);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: widget.isDark ? Colors.white.withOpacity(0.08) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: latColor.withOpacity(0.4)),
            boxShadow: widget.isDark
                ? null
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 8,
                    ),
                  ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedBuilder(
                animation: _rippleCtrl,
                builder: (context, _) {
                  final double rip = _rippleCtrl.value;
                  return SizedBox(
                    width: 14,
                    height: 14,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 6 + (rip * 8),
                          height: 6 + (rip * 8),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: latColor.withOpacity((1.0 - rip).clamp(0.0, 0.8)),
                              width: 1.2,
                            ),
                          ),
                        ),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: latColor,
                            boxShadow: [
                              BoxShadow(
                                color: latColor.withOpacity(0.8),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(width: 6),
              Text(
                '${ms}ms',
                style: GoogleFonts.sora(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: latColor,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ========== CYBER ANIMATED ALERT DIALOGS ==========

enum CyberDialogType {
  success,
  error,
  warning,
  info,
  confirm,
}

class CyberAnimatedDialog extends StatefulWidget {
  final CyberDialogType type;
  final String title;
  final String message;
  final String primaryButtonText;
  final String? secondaryButtonText;
  final VoidCallback? onPrimaryPressed;
  final VoidCallback? onSecondaryPressed;
  final IconData? customIcon;

  const CyberAnimatedDialog({
    super.key,
    required this.type,
    required this.title,
    required this.message,
    this.primaryButtonText = 'UNDERSTOOD',
    this.secondaryButtonText,
    this.onPrimaryPressed,
    this.onSecondaryPressed,
    this.customIcon,
  });

  static Future<T?> show<T>(
    BuildContext context, {
    required CyberDialogType type,
    required String title,
    required String message,
    String primaryButtonText = 'OK',
    String? secondaryButtonText,
    VoidCallback? onPrimaryPressed,
    VoidCallback? onSecondaryPressed,
    IconData? customIcon,
    bool barrierDismissible = true,
  }) {
    return showGeneralDialog<T>(
      context: context,
      barrierDismissible: barrierDismissible,
      barrierLabel: 'CyberAnimatedDialog',
      barrierColor: Colors.black.withOpacity(0.80),
      transitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (ctx, anim1, anim2) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim1, anim2, child) {
        final curved = CurvedAnimation(parent: anim1, curve: Curves.easeOutBack);
        return Transform.scale(
          scale: curved.value,
          child: Opacity(
            opacity: anim1.value.clamp(0.0, 1.0),
            child: CyberAnimatedDialog(
              type: type,
              title: title,
              message: message,
              primaryButtonText: primaryButtonText,
              secondaryButtonText: secondaryButtonText,
              onPrimaryPressed: onPrimaryPressed,
              onSecondaryPressed: onSecondaryPressed,
              customIcon: customIcon,
            ),
          ),
        );
      },
    );
  }

  static Future<void> showSuccess(
    BuildContext context, {
    required String title,
    required String message,
    String buttonText = 'CONTINUE',
    VoidCallback? onConfirm,
  }) async {
    await show(
      context,
      type: CyberDialogType.success,
      title: title,
      message: message,
      primaryButtonText: buttonText,
      onPrimaryPressed: onConfirm,
    );
  }

  static Future<void> showError(
    BuildContext context, {
    required String title,
    required String message,
    String buttonText = 'CLOSE',
    VoidCallback? onConfirm,
  }) async {
    await show(
      context,
      type: CyberDialogType.error,
      title: title,
      message: message,
      primaryButtonText: buttonText,
      onPrimaryPressed: onConfirm,
    );
  }

  static Future<void> showWarning(
    BuildContext context, {
    required String title,
    required String message,
    String buttonText = 'UNDERSTOOD',
    VoidCallback? onConfirm,
  }) async {
    await show(
      context,
      type: CyberDialogType.warning,
      title: title,
      message: message,
      primaryButtonText: buttonText,
      onPrimaryPressed: onConfirm,
    );
  }

  static Future<void> showInfo(
    BuildContext context, {
    required String title,
    required String message,
    String buttonText = 'OK',
    VoidCallback? onConfirm,
  }) async {
    await show(
      context,
      type: CyberDialogType.info,
      title: title,
      message: message,
      primaryButtonText: buttonText,
      onPrimaryPressed: onConfirm,
    );
  }

  static Future<bool> showConfirm(
    BuildContext context, {
    required String title,
    required String message,
    String confirmText = 'CONFIRM',
    String cancelText = 'CANCEL',
    required VoidCallback onConfirm,
    VoidCallback? onCancel,
  }) async {
    bool confirmed = false;
    await show(
      context,
      type: CyberDialogType.confirm,
      title: title,
      message: message,
      primaryButtonText: confirmText,
      secondaryButtonText: cancelText,
      onPrimaryPressed: () {
        confirmed = true;
        onConfirm();
      },
      onSecondaryPressed: onCancel,
    );
    return confirmed;
  }

  @override
  State<CyberAnimatedDialog> createState() => _CyberAnimatedDialogState();
}

class _CyberAnimatedDialogState extends State<CyberAnimatedDialog>
    with TickerProviderStateMixin {
  late final AnimationController _ringRotationCtrl;
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _ringRotationCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ringRotationCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  List<Color> _getColors() {
    switch (widget.type) {
      case CyberDialogType.success:
        return const [Color(0xFF00FF87), Color(0xFF00E5FF)];
      case CyberDialogType.error:
        return const [Color(0xFFFF0055), Color(0xFFEF4444)];
      case CyberDialogType.warning:
        return const [Color(0xFFFFB800), Color(0xFFFF5722)];
      case CyberDialogType.info:
        return const [Color(0xFF00E5FF), Color(0xFF7B61FF)];
      case CyberDialogType.confirm:
        return const [Color(0xFF00FF87), Color(0xFF7B61FF)];
    }
  }

  IconData _getIcon() {
    if (widget.customIcon != null) return widget.customIcon!;
    switch (widget.type) {
      case CyberDialogType.success:
        return Icons.verified_rounded;
      case CyberDialogType.error:
        return Icons.gpp_bad_rounded;
      case CyberDialogType.warning:
        return Icons.warning_amber_rounded;
      case CyberDialogType.info:
        return Icons.info_outline_rounded;
      case CyberDialogType.confirm:
        return Icons.live_help_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final List<Color> colors = _getColors();
    final IconData icon = _getIcon();

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: AnimatedBuilder(
        animation: Listenable.merge([_ringRotationCtrl, _pulseCtrl]),
        builder: (context, child) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: CustomPaint(
                painter: _RgbBorderPainter(
                  animationValue: _ringRotationCtrl.value,
                  borderRadius: 28,
                  borderWidth: 1.8,
                  backgroundColor: isDark
                      ? const Color(0xFA0A1224)
                      : const Color(0xFAFFFFFF),
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(22, 28, 22, 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Holographic Animated Center Badge
                      SizedBox(
                        width: 86,
                        height: 86,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CustomPaint(
                              size: const Size(86, 86),
                              painter: _CyberBadgeRingPainter(
                                progress: _ringRotationCtrl.value,
                                colors: colors,
                              ),
                            ),
                            Transform.scale(
                              scale: 1.0 + (_pulseCtrl.value * 0.08),
                              child: Container(
                                width: 56,
                                height: 56,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    colors: colors,
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: colors.first.withOpacity(0.55),
                                      blurRadius: 18,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Icon(
                                    icon,
                                    color: Colors.black,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Dialog Title
                      Text(
                        widget.title,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.sora(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.9,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Dialog Message
                      Text(
                        widget.message,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w500,
                          height: 1.55,
                          color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF475569),
                        ),
                      ),
                      const SizedBox(height: 26),

                      // Action Button(s)
                      if (widget.secondaryButtonText != null)
                        Row(
                          children: [
                            Expanded(
                              child: _PressScale(
                                onTap: () {
                                  Navigator.pop(context);
                                  widget.onSecondaryPressed?.call();
                                },
                                child: Container(
                                  height: 48,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    color: isDark
                                        ? Colors.white.withOpacity(0.08)
                                        : Colors.grey.withOpacity(0.12),
                                    border: Border.all(
                                      color: isDark ? Colors.white24 : Colors.black12,
                                      width: 1.2,
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      widget.secondaryButtonText!,
                                      style: GoogleFonts.sora(
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w800,
                                        color: isDark ? Colors.white70 : const Color(0xFF475569),
                                        letterSpacing: 0.6,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _LiveShimmerButton(
                                height: 48,
                                borderRadius: 14,
                                gradientColors: colors,
                                onTap: () {
                                  Navigator.pop(context);
                                  widget.onPrimaryPressed?.call();
                                },
                                child: Text(
                                  widget.primaryButtonText,
                                  style: GoogleFonts.sora(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.black,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      else
                        _LiveShimmerButton(
                          height: 48,
                          borderRadius: 14,
                          gradientColors: colors,
                          onTap: () {
                            Navigator.pop(context);
                            widget.onPrimaryPressed?.call();
                          },
                          child: Text(
                            widget.primaryButtonText,
                            style: GoogleFonts.sora(
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              color: Colors.black,
                              letterSpacing: 0.9,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _CyberBadgeRingPainter extends CustomPainter {
  final double progress;
  final List<Color> colors;

  _CyberBadgeRingPainter({required this.progress, required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final double radius = size.width / 2 - 3;
    final double angle = progress * 2 * math.pi;

    final Paint arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(angle),
        colors: [
          colors.first,
          colors.last,
          Colors.transparent,
          colors.first,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, arcPaint);
  }

  @override
  bool shouldRepaint(covariant _CyberBadgeRingPainter oldDelegate) => true;
}

// ========== CYBER PILL TOAST (DYNAMIC ISLAND STYLE) ==========

class CyberPillToast {
  static OverlayEntry? _activeEntry;
  static Timer? _dismissTimer;

  static void show(
    BuildContext context, {
    required String message,
    bool isSuccess = true,
    IconData? icon,
    Duration duration = const Duration(milliseconds: 2400),
  }) {
    _dismissTimer?.cancel();
    _activeEntry?.remove();
    _activeEntry = null;

    final OverlayState? overlay = Overlay.maybeOf(context);
    if (overlay == null) return;

    final entry = OverlayEntry(
      builder: (ctx) => _CyberPillWidget(
        message: message,
        isSuccess: isSuccess,
        icon: icon,
        duration: duration,
        onDismiss: () {
          _activeEntry?.remove();
          _activeEntry = null;
        },
      ),
    );

    _activeEntry = entry;
    overlay.insert(entry);

    _dismissTimer = Timer(duration + const Duration(milliseconds: 400), () {
      _activeEntry?.remove();
      _activeEntry = null;
    });
  }
}

class _CyberPillWidget extends StatefulWidget {
  final String message;
  final bool isSuccess;
  final IconData? icon;
  final Duration duration;
  final VoidCallback onDismiss;

  const _CyberPillWidget({
    required this.message,
    required this.isSuccess,
    this.icon,
    required this.duration,
    required this.onDismiss,
  });

  @override
  State<_CyberPillWidget> createState() => _CyberPillWidgetState();
}

class _CyberPillWidgetState extends State<_CyberPillWidget>
    with TickerProviderStateMixin {
  late final AnimationController _animCtrl;
  late final AnimationController _progressCtrl;
  late final Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, -1.2),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutBack));

    _progressCtrl = AnimationController(
      vsync: this,
      duration: widget.duration,
    );

    _animCtrl.forward();
    _progressCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _progressCtrl.dispose();
    super.dispose();
  }

  void _dismiss() async {
    await _animCtrl.reverse();
    widget.onDismiss();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final Color accent = widget.isSuccess
        ? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669))
        : const Color(0xFFFF0055);
    final IconData displayIcon = widget.icon ??
        (widget.isSuccess ? Icons.check_circle_rounded : Icons.error_outline_rounded);

    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: SlideTransition(
            position: _slideAnim,
            child: GestureDetector(
              onTap: _dismiss,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Container(
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xF2081124) : const Color(0xF2FFFFFF),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accent.withOpacity(0.55), width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(0.30),
                          blurRadius: 18,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          child: Row(
                            children: [
                              Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: accent.withOpacity(0.18),
                                ),
                                child: Icon(displayIcon, color: accent, size: 17),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  widget.message,
                                  style: GoogleFonts.sora(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Real-time Countdown Line
                        AnimatedBuilder(
                          animation: _progressCtrl,
                          builder: (context, _) {
                            return LinearProgressIndicator(
                              value: 1.0 - _progressCtrl.value,
                              minHeight: 2.2,
                              backgroundColor: Colors.transparent,
                              valueColor: AlwaysStoppedAnimation<Color>(accent.withOpacity(0.8)),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ========== DIALOGS ==========

class _PremiumDialogShell extends StatelessWidget {
  final Widget child;
  final List<Color> accentGradient;

  const _PremiumDialogShell({
    super.key,
    required this.child,
    required this.accentGradient,
  });

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0.85, end: 1.0),
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutBack,
        builder: (context, value, childWidget) {
          return Transform.scale(
            scale: value,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0D152B), const Color(0xFF070B18)]
                      : [Colors.white, const Color(0xFFF8FAFC)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: accentGradient.first.withOpacity(0.5),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentGradient.first.withOpacity(isDark ? 0.2 : 0.1),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: child,
              ),
            ),
          );
        },
        child: child,
      ),
    );
  }
}

class _PremiumDialogHeader extends StatefulWidget {
  final List<Color> gradient;
  final String? lottieAsset;
  final IconData fallbackIcon;

  const _PremiumDialogHeader({
    super.key,
    required this.gradient,
    this.lottieAsset,
    required this.fallbackIcon,
  });

  @override
  State<_PremiumDialogHeader> createState() => _PremiumDialogHeaderState();
}

class _PremiumDialogHeaderState extends State<_PremiumDialogHeader>
    with SingleTickerProviderStateMixin {
  late final AnimationController _rotationCtrl;

  @override
  void initState() {
    super.initState();
    _rotationCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _rotationCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: widget.gradient,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: AnimatedBuilder(
          animation: _rotationCtrl,
          builder: (context, child) {
            return SizedBox(
              width: 78,
              height: 78,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CustomPaint(
                    size: const Size(78, 78),
                    painter: _CyberBadgeRingPainter(
                      progress: _rotationCtrl.value,
                      colors: [Colors.white, widget.gradient.first],
                    ),
                  ),
                  Container(
                    width: 62,
                    height: 62,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.22),
                      border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.35),
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    child: Icon(widget.fallbackIcon, color: Colors.white, size: 34),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class MaintenanceDialog extends StatefulWidget {
  final Map<String, dynamic> data;
  final VoidCallback onClose;
  final VoidCallback onMaintenanceOver;

  const MaintenanceDialog({
    super.key,
    required this.data,
    required this.onClose,
    required this.onMaintenanceOver,
  });

  @override
  State<MaintenanceDialog> createState() => _MaintenanceDialogState();
}

class _MaintenanceDialogState extends State<MaintenanceDialog> {
  Timer? _countdownTimer;
  Duration _remaining = Duration.zero;

  @override
  void initState() {
    super.initState();
    _initTimer();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }

  void _initTimer() {
    final String endStr = widget.data['end_time'] ?? '';
    if (endStr.isNotEmpty) {
      try {
        final DateTime end = DateTime.parse(endStr);
        final DateTime now = DateTime.now();
        if (end.isAfter(now)) {
          setState(() {
            _remaining = end.difference(now);
          });
          _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
            final DateTime current = DateTime.now();
            if (end.isAfter(current)) {
              if (mounted) {
                setState(() {
                  _remaining = end.difference(current);
                });
              }
            } else {
              timer.cancel();
              widget.onMaintenanceOver();
            }
          });
        }
      } catch (_) {}
    }
  }

  String _formatRemaining() {
    final int h = _remaining.inHours;
    final int m = _remaining.inMinutes % 60;
    final int s = _remaining.inSeconds % 60;
    return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final String title = widget.data['title'] ?? 'System Maintenance';
    final String message = widget.data['message'] ?? 'We are upgrading our VIP algorithms for maximum accuracy.';

    return _PremiumDialogShell(
      accentGradient: const [Color(0xFFF59E0B), Color(0xFFD97706)],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _PremiumDialogHeader(
            gradient: [Color(0xFFF59E0B), Color(0xFFD97706)],
            fallbackIcon: Icons.build_circle_rounded,
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  title,
                  style: GoogleFonts.sora(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  message,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: isDark ? Colors.grey[300] : const Color(0xFF475569),
                  ),
                  textAlign: TextAlign.center,
                ),
                if (_remaining > Duration.zero) ...[
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF59E0B).withOpacity(0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.timer_outlined, color: Color(0xFFF59E0B), size: 18),
                        const SizedBox(width: 8),
                        Text(
                          'Estimated time: ${_formatRemaining()}',
                          style: GoogleFonts.sora(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFFF59E0B),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: widget.onClose,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDark ? Colors.white12 : Colors.grey[200],
                      foregroundColor: isDark ? Colors.white : Colors.black87,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      'EXIT APP',
                      style: GoogleFonts.sora(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class UpdateDialog extends StatefulWidget {
  final Map<String, dynamic> data;
  final VoidCallback onClose;

  const UpdateDialog({
    super.key,
    required this.data,
    required this.onClose,
  });

  @override
  State<UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<UpdateDialog> {
  bool _isDownloading = false;
  double _progress = 0;
  String _downloadStatus = 'Ready to update';
  int _receivedBytes = 0;
  int _totalBytes = 0;
  StreamSubscription<List<int>>? _downloadSub;

  @override
  void dispose() {
    _downloadSub?.cancel();
    super.dispose();
  }

  String _formatBytes(int bytes) {
    if (bytes <= 0) return '0 MB';
    final double mb = bytes / (1024 * 1024);
    return '${mb.toStringAsFixed(1)} MB';
  }

  Future<void> _downloadAndInstall() async {
    final String url = widget.data['apk_url'] ?? '';
    if (url.isEmpty) {
      _showError('No download URL available');
      return;
    }

    final PermissionStatus installPermission = await Permission.requestInstallPackages.status;
    if (!installPermission.isGranted) {
      final PermissionStatus result = await Permission.requestInstallPackages.request();
      if (!result.isGranted) {
        _showError('Please allow "Install unknown apps" permission to update.');
        return;
      }
    }

    if (!mounted) return;
    setState(() {
      _isDownloading = true;
      _progress = 0;
      _receivedBytes = 0;
      _totalBytes = 0;
      _downloadStatus = 'Starting download...';
    });

    try {
      final Directory dir = await getTemporaryDirectory();
      final String savePath = '${dir.path}/vip_update.apk';
      final File file = File(savePath);
      if (await file.exists()) {
        await file.delete();
      }
      final IOSink sink = file.openWrite();

      final http.Client client = http.Client();
      final http.StreamedResponse response = await client.send(http.Request('GET', Uri.parse(url)));

      if (response.statusCode != 200) {
        await sink.close();
        client.close();
        throw Exception('Server returned ${response.statusCode}');
      }

      _totalBytes = response.contentLength ?? 0;
      final Completer<void> completer = Completer<void>();

      _downloadSub = response.stream.listen(
        (List<int> chunk) {
          sink.add(chunk);
          _receivedBytes += chunk.length;
          if (mounted) {
            setState(() {
              _progress = _totalBytes > 0 ? (_receivedBytes / _totalBytes).clamp(0.0, 1.0) : 0;
              _downloadStatus = _totalBytes > 0
                  ? 'Downloading... ${(_progress * 100).toStringAsFixed(0)}% (${_formatBytes(_receivedBytes)} / ${_formatBytes(_totalBytes)})'
                  : 'Downloading... ${_formatBytes(_receivedBytes)}';
            });
          }
        },
        onDone: () async {
          await sink.close();
          client.close();
          completer.complete();
        },
        onError: (Object e) async {
          await sink.close();
          client.close();
          completer.completeError(e);
        },
        cancelOnError: true,
      );

      await completer.future;

      if (!mounted) return;
      setState(() {
        _downloadStatus = 'Download complete!';
        _isDownloading = false;
      });

      await _openAPK(savePath);
    } catch (e) {
      secureLog('Download error: $e');
      if (mounted) {
        setState(() {
          _isDownloading = false;
          _downloadStatus = 'Download failed';
        });
        _showError('Download failed. Please check your network.');
      }
    }
  }

  Future<void> _openAPK(String apkPath) async {
    final OpenResult result = await OpenFilex.open(
      apkPath,
      type: 'application/vnd.android.package-archive',
    );
    if (result.type != ResultType.done && mounted) {
      _showError('Could not open installer: ${result.message}');
    }
    widget.onClose();
  }

  void _showError(String message) {
    if (!mounted) return;
    CyberPillToast.show(
      context,
      message: message,
      isSuccess: false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final String version = widget.data['version'] ?? 'Latest';
    final String changelog = widget.data['changelog'] ?? 'Performance upgrades, enhanced 90 FPS prediction animations, and real-time latency optimization.';

    return _PremiumDialogShell(
      accentGradient: const [Color(0xFF00FF87), Color(0xFF00E5FF)],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _PremiumDialogHeader(
            gradient: [Color(0xFF00FF87), Color(0xFF00E5FF)],
            fallbackIcon: Icons.system_security_update_rounded,
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Update Available',
                      style: GoogleFonts.sora(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: isDark ? Colors.white : const Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF00FF87).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'v$version',
                        style: GoogleFonts.sora(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  changelog,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 13.5,
                    color: isDark ? Colors.grey[300] : const Color(0xFF475569),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                if (_isDownloading) ...[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _progress,
                      backgroundColor: const Color(0x2200FF87),
                      valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF00FF87)),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _downloadStatus,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ] else ...[
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _downloadAndInstall,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF00FF87),
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: Text(
                        'DOWNLOAD & INSTALL',
                        style: GoogleFonts.sora(
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class NoticeDialog extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onClose;

  const NoticeDialog({
    super.key,
    required this.data,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final String title = data['title'] ?? 'System Notice';
    final String message = data['message'] ?? '';

    return _PremiumDialogShell(
      accentGradient: const [Color(0xFF7B61FF), Color(0xFF4F46E5)],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _PremiumDialogHeader(
            gradient: [Color(0xFF7B61FF), Color(0xFF4F46E5)],
            fallbackIcon: Icons.campaign_rounded,
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  title,
                  style: GoogleFonts.sora(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  message,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: isDark ? Colors.grey[300] : const Color(0xFF475569),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      onClose();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF7B61FF),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      'I UNDERSTAND',
                      style: GoogleFonts.sora(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AnnouncementDialog extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onClose;

  const AnnouncementDialog({
    super.key,
    required this.data,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final String title = data['title'] ?? 'VIP Announcement';
    final String message = data['message'] ?? '';

    return _PremiumDialogShell(
      accentGradient: const [Color(0xFF00FF87), Color(0xFF00E5FF)],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _PremiumDialogHeader(
            gradient: [Color(0xFF00FF87), Color(0xFF00E5FF)],
            fallbackIcon: Icons.auto_awesome_rounded,
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  title,
                  style: GoogleFonts.sora(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  message,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: isDark ? Colors.grey[300] : const Color(0xFF475569),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      onClose();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00FF87),
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      'GOT IT',
                      style: GoogleFonts.sora(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class DeviceAuthDialog extends StatefulWidget {
  final String deviceId;

  const DeviceAuthDialog({
    super.key,
    required this.deviceId,
  });

  @override
  State<DeviceAuthDialog> createState() => _DeviceAuthDialogState();
}

class _DeviceAuthDialogState extends State<DeviceAuthDialog> {
  int _secondsLeft = 5;
  Timer? _countdownTimer;

  @override
  void initState() {
    super.initState();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        timer.cancel();
        Navigator.of(context, rootNavigator: true).pop();
      } else {
        setState(() {
          _secondsLeft--;
        });
      }
    });
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }

  void _closeDialog() {
    _countdownTimer?.cancel();
    Navigator.of(context, rootNavigator: true).pop();
  }

  @override
  Widget build(BuildContext context) {
    final String title = AppRemoteConfig.instance.text(
      'unauth_device_title',
      'UNAUTHORIZED DEVICE DETECTED',
    );
    final String message = AppRemoteConfig.instance.text(
      'unauth_device_msg',
      'Unauthorized device detected. Please contact your seller and ask to give authorized access device.',
    );
    final String sellerBtnText = AppRemoteConfig.instance.text(
      'seller_contact_btn_text',
      'CONTACT SELLER ON TELEGRAM',
    );
    final String sellerUrl = AppRemoteConfig.instance.text(
      'seller_contact_url',
      AppRemoteConfig.instance.sellerContactUrl,
    );

    return _PremiumDialogShell(
      accentGradient: const [Color(0xFFEF4444), Color(0xFFDC2626)],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _PremiumDialogHeader(
            gradient: [Color(0xFFEF4444), Color(0xFFDC2626)],
            fallbackIcon: Icons.lock_person_rounded,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            child: Column(
              children: [
                // Title
                Text(
                  title,
                  style: GoogleFonts.sora(
                    fontSize: 16.5,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),

                // Auto-close countdown badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.4), width: 1.0),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.timer_outlined, size: 12, color: Color(0xFFEF4444)),
                      const SizedBox(width: 5),
                      Text(
                        'Auto-closing in ${_secondsLeft}s',
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFFEF4444),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // Message
                Text(
                  message,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    color: Colors.grey[300],
                    height: 1.45,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 14),

                // Device ID Box with Copy Button
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.withOpacity(0.35)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.fingerprint_rounded, color: Color(0xFFEF4444), size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          widget.deviceId,
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                            color: Colors.white,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.copy_rounded, size: 17, color: Color(0xFF00FF87)),
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: widget.deviceId));
                          CyberPillToast.show(
                            context,
                            message: 'Device ID copied to clipboard!',
                            isSuccess: true,
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Seller Contact Button (Controlled from Admin Panel)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      final Uri? uri = Uri.tryParse(sellerUrl);
                      if (uri != null && await canLaunchUrl(uri)) {
                        await launchUrl(uri, mode: LaunchMode.externalApplication);
                      }
                    },
                    icon: const Icon(Icons.send_rounded, size: 18),
                    label: Text(
                      sellerBtnText,
                      style: GoogleFonts.sora(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0088CC),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                // Close Button
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: _closeDialog,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.grey[300],
                      side: BorderSide(color: Colors.white.withOpacity(0.18)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(
                      AppRemoteConfig.instance.text('unauth_close_btn', 'CLOSE'),
                      style: GoogleFonts.sora(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ========== INTRODUCTION SCREEN (ONBOARDING) ==========

class IntroPageData {
  final String title;
  final String description;
  final String lottieAsset;
  final String badgeText;
  final List<String> techPills;
  final IconData heroIcon;
  final Color primaryColor;
  final Color secondaryColor;

  IntroPageData({
    required this.title,
    required this.description,
    this.lottieAsset = '',
    this.badgeText = 'NEURAL AI PREDICTOR v4.0',
    this.techPills = const ['99.4% HIT RATE', 'RADAR MATRIX', '< 30MS DELAY'],
    this.heroIcon = Icons.radar_rounded,
    this.primaryColor = const Color(0xFF00FF87),
    this.secondaryColor = const Color(0xFF00E5FF),
  });
}

// Live Breathing Badge with pulsing LED
class _SlideLiveBadge extends StatefulWidget {
  final String text;
  final Color primaryColor;
  final bool isDark;

  const _SlideLiveBadge({
    required this.text,
    required this.primaryColor,
    required this.isDark,
  });

  @override
  State<_SlideLiveBadge> createState() => _SlideLiveBadgeState();
}

class _SlideLiveBadgeState extends State<_SlideLiveBadge>
    with SingleTickerProviderStateMixin {
  late final AnimationController _glowCtrl;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (context, child) {
        final double glow = _glowCtrl.value;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: widget.isDark
                ? widget.primaryColor.withOpacity(0.08 + (glow * 0.08))
                : widget.primaryColor.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: widget.primaryColor.withOpacity(0.45 + (glow * 0.45)),
              width: 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.primaryColor.withOpacity(0.18 + (glow * 0.28)),
                blurRadius: 12 + (glow * 6),
                spreadRadius: 0.5,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.primaryColor,
                  boxShadow: [
                    BoxShadow(
                      color: widget.primaryColor,
                      blurRadius: 6 + (glow * 6),
                      spreadRadius: 1 + (glow * 2),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                widget.text,
                style: GoogleFonts.sora(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                  color: widget.isDark ? widget.primaryColor : const Color(0xFF047857),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// Live Tech Feature Chips Row
class _SlideTechChipsRow extends StatelessWidget {
  final List<String> chips;
  final Color primaryColor;
  final bool isDark;

  const _SlideTechChipsRow({
    required this.chips,
    required this.primaryColor,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 8,
      children: chips.map((chip) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5.5),
          decoration: BoxDecoration(
            color: isDark ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.04),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: primaryColor.withOpacity(0.35),
              width: 1.1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.bolt_rounded, size: 12, color: primaryColor),
              const SizedBox(width: 4),
              Text(
                chip,
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                  color: isDark ? Colors.white.withOpacity(0.9) : const Color(0xFF1E293B),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

// Sweeping Shimmering Cinematic Holographic Title with Ambient Glow
class _AnimatedSlideShimmerTitle extends StatefulWidget {
  final String title;
  final bool isDark;
  final Color primaryColor;
  final Color secondaryColor;

  const _AnimatedSlideShimmerTitle({
    required this.title,
    required this.isDark,
    required this.primaryColor,
    required this.secondaryColor,
  });

  @override
  State<_AnimatedSlideShimmerTitle> createState() => _AnimatedSlideShimmerTitleState();
}

class _AnimatedSlideShimmerTitleState extends State<_AnimatedSlideShimmerTitle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat();
  }

  @override
  void dispose() {
    _shimmerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _shimmerCtrl,
      builder: (context, child) {
        final double t = _shimmerCtrl.value;
        final double glowPulse = (math.sin(t * 2 * math.pi) * 0.5) + 0.5;

        return Stack(
          alignment: Alignment.center,
          children: [
            // Background ambient glow shadow behind the title
            Text(
              widget.title,
              style: GoogleFonts.sora(
                fontSize: 23,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.4,
                height: 1.25,
                color: widget.primaryColor.withOpacity(0.18 + (glowPulse * 0.18)),
              ),
              textAlign: TextAlign.center,
            ),

            // Foreground animated shimmering text
            ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (bounds) {
                final double stop1 = (0.15 + (t * 0.45)).clamp(0.0, 1.0);
                final double stop2 = (0.45 + (t * 0.45)).clamp(0.0, 1.0);
                return LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    widget.isDark ? Colors.white : const Color(0xFF0F172A),
                    widget.primaryColor,
                    widget.secondaryColor,
                    widget.isDark ? Colors.white : const Color(0xFF0F172A),
                  ],
                  stops: [0.0, stop1, stop2, 1.0],
                ).createShader(bounds);
              },
              child: Text(
                widget.title,
                style: GoogleFonts.sora(
                  fontSize: 23,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.4,
                  height: 1.25,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        );
      },
    );
  }
}

// Lottie Hero with Full Cinematic Floating Physics, Dual Orbital Rings & Ground Reflection
class _SlideLottieHeroWidget extends StatefulWidget {
  final String lottieAsset;
  final IconData heroIcon;
  final Color primaryColor;
  final Color secondaryColor;
  final bool isDark;

  const _SlideLottieHeroWidget({
    required this.lottieAsset,
    required this.heroIcon,
    required this.primaryColor,
    required this.secondaryColor,
    required this.isDark,
  });

  @override
  State<_SlideLottieHeroWidget> createState() => _SlideLottieHeroWidgetState();
}

class _SlideLottieHeroWidgetState extends State<_SlideLottieHeroWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _cinematicCtrl;

  @override
  void initState() {
    super.initState();
    _cinematicCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat();
  }

  @override
  void dispose() {
    _cinematicCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _cinematicCtrl,
      builder: (context, child) {
        final double t = _cinematicCtrl.value;
        // Smooth sine-wave vertical levitation floating (-8.5px to +8.5px)
        final double floatY = math.sin(t * 2 * math.pi) * 8.5;
        // Subtle scale breathing pulse
        final double scale = 1.0 + (math.sin(t * 2 * math.pi) * 0.025);
        // Inverse ground shadow scale
        final double shadowScale = (1.0 - (floatY / 30.0)).clamp(0.7, 1.3);

        return SizedBox(
          width: 230,
          height: 230,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // 1. Dynamic Ground Shadow
              Positioned(
                bottom: 12,
                child: Container(
                  width: 125 * shadowScale,
                  height: 15 * shadowScale,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.elliptical(125 * shadowScale, 15 * shadowScale)),
                    boxShadow: [
                      BoxShadow(
                        color: widget.primaryColor.withOpacity(widget.isDark ? 0.28 : 0.16),
                        blurRadius: 22,
                        spreadRadius: 3,
                      ),
                    ],
                  ),
                ),
              ),

              // 2. Volumetric Ambient Breathing Radial Halo
              Container(
                width: 190 + (scale * 20),
                height: 190 + (scale * 20),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      widget.primaryColor.withOpacity(widget.isDark ? 0.24 : 0.15),
                      widget.secondaryColor.withOpacity(widget.isDark ? 0.10 : 0.05),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.65, 1.0],
                  ),
                ),
              ),

              // 3. Clockwise Rotating Cyber Orbital Ring
              Transform.rotate(
                angle: t * 2 * math.pi,
                child: CustomPaint(
                  size: const Size(205, 205),
                  painter: _CyberRingPainter(
                    color: widget.primaryColor.withOpacity(0.35),
                    dotsColor: widget.secondaryColor,
                  ),
                ),
              ),

              // 4. Counter-Clockwise Inner Cyber Ring
              Transform.rotate(
                angle: -t * 2 * math.pi * 0.7,
                child: CustomPaint(
                  size: const Size(175, 175),
                  painter: _CyberRingPainter(
                    color: widget.secondaryColor.withOpacity(0.25),
                    dotsColor: widget.primaryColor,
                    reverse: true,
                  ),
                ),
              ),

              // 5. Floating Hero with Lottie Animation
              Transform.translate(
                offset: Offset(0, floatY),
                child: Transform.scale(
                  scale: scale,
                  child: SizedBox(
                    width: 195,
                    height: 195,
                    child: Lottie.asset(
                      widget.lottieAsset,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Center(
                        child: Container(
                          width: 105,
                          height: 105,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: widget.primaryColor.withOpacity(0.12),
                            border: Border.all(
                              color: widget.primaryColor.withOpacity(0.40),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: widget.primaryColor.withOpacity(0.25),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          child: Icon(
                            widget.heroIcon,
                            size: 52,
                            color: widget.isDark ? widget.primaryColor : const Color(0xFF059669),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// Custom Painter for Rotating Cyber Orbital Rings with Nodes
class _CyberRingPainter extends CustomPainter {
  final Color color;
  final Color dotsColor;
  final bool reverse;

  _CyberRingPainter({
    required this.color,
    required this.dotsColor,
    this.reverse = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final double radius = size.width / 2;
    final Offset center = Offset(radius, radius);

    final Paint arcPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    // Draw dashed cyber arcs
    for (int i = 0; i < 4; i++) {
      final double startAngle = (i * math.pi / 2) + (reverse ? 0.2 : 0.0);
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius - 2),
        startAngle,
        math.pi / 3.5,
        false,
        arcPaint,
      );
    }

    // Draw glowing orbital nodes
    final Paint dotPaint = Paint()..color = dotsColor;
    for (int i = 0; i < 3; i++) {
      final double nodeAngle = (i * 2 * math.pi / 3) + (reverse ? 0.4 : 0.0);
      final Offset dotPos = Offset(
        center.dx + (radius - 2) * math.cos(nodeAngle),
        center.dy + (radius - 2) * math.sin(nodeAngle),
      );
      canvas.drawCircle(dotPos, 2.5, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _CyberRingPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.dotsColor != dotsColor;
}


// Animated Glowing Indicator Dots
class _LiveSlideIndicator extends StatefulWidget {
  final int totalPages;
  final int currentPage;
  final Color primaryColor;
  final bool isDark;

  const _LiveSlideIndicator({
    required this.totalPages,
    required this.currentPage,
    required this.primaryColor,
    required this.isDark,
  });

  @override
  State<_LiveSlideIndicator> createState() => _LiveSlideIndicatorState();
}

class _LiveSlideIndicatorState extends State<_LiveSlideIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (context, child) {
        final double glow = _pulseCtrl.value;
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(widget.totalPages, (idx) {
            final bool isActive = idx == widget.currentPage;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOutCubic,
              margin: const EdgeInsets.only(right: 8),
              width: isActive ? 34 : 9,
              height: 9,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                gradient: isActive
                    ? LinearGradient(
                        colors: [
                          widget.primaryColor,
                          const Color(0xFF00E5FF),
                        ],
                      )
                    : null,
                color: isActive
                    ? null
                    : (widget.isDark ? Colors.white24 : const Color(0xFFCBD5E1)),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: widget.primaryColor.withOpacity(0.40 + (glow * 0.45)),
                          blurRadius: 10 + (glow * 6),
                          spreadRadius: 1,
                        ),
                      ]
                    : null,
              ),
            );
          }),
        );
      },
    );
  }
}

// Shimmering Navigation Button (NEXT / GET STARTED)
class _SlideShimmerNavButton extends StatefulWidget {
  final VoidCallback onTap;
  final String label;
  final IconData icon;
  final List<Color> gradientColors;

  const _SlideShimmerNavButton({
    required this.onTap,
    required this.label,
    required this.icon,
    required this.gradientColors,
  });

  @override
  State<_SlideShimmerNavButton> createState() => _SlideShimmerNavButtonState();
}

class _SlideShimmerNavButtonState extends State<_SlideShimmerNavButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();
  }

  @override
  void dispose() {
    _shimmerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _PressScale(
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _shimmerCtrl,
        builder: (context, _) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: widget.gradientColors,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.gradientColors.first.withOpacity(0.35 + (_shimmerCtrl.value * 0.18)),
                  blurRadius: 16 + (_shimmerCtrl.value * 8),
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        widget.label,
                        style: GoogleFonts.sora(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w900,
                          color: Colors.black,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(
                        widget.icon,
                        color: Colors.black,
                        size: 18,
                      ),
                    ],
                  ),
                  Positioned.fill(
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        final double w = constraints.maxWidth;
                        final double left = -w + (_shimmerCtrl.value * (w * 2.4));
                        return Transform.translate(
                          offset: Offset(left, 0),
                          child: Transform.rotate(
                            angle: 0.35,
                            child: Container(
                              width: 32,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.white.withOpacity(0.0),
                                    Colors.white.withOpacity(0.45),
                                    Colors.white.withOpacity(0.0),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class IntroductionScreen extends StatefulWidget {
  final Map<String, dynamic>? maintenanceData;
  final Map<String, dynamic>? updateData;
  final Map<String, dynamic>? noticeData;
  final bool isMaintenance;
  final bool isUpdateAvailable;
  final bool isConnected;
  final VoidCallback onRefreshData;

  const IntroductionScreen({
    super.key,
    this.maintenanceData,
    this.updateData,
    this.noticeData,
    this.isMaintenance = false,
    this.isUpdateAvailable = false,
    this.isConnected = true,
    required this.onRefreshData,
  });

  @override
  State<IntroductionScreen> createState() => _IntroductionScreenState();
}

class _IntroductionScreenState extends State<IntroductionScreen>
    with SingleTickerProviderStateMixin, ThemeReactive<IntroductionScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late AnimationController _pageAnimationController;
  
  List<IntroPageData> _pages = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    initThemeListener();
    _pageAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    
    _loadIntroData();
  }

  @override
  void dispose() {
    disposeThemeListener();
    _pageController.dispose();
    _pageAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadIntroData() async {
    final cfg = AppRemoteConfig.instance;
    final List<IntroPageData> dynamicPages = [
      IntroPageData(
        title: cfg.text('slide1_title', 'Next-Gen Color Predictor'),
        description: cfg.text('slide1_desc', 'Engineered with deep neural models for high precision WinGo color and number predictions.'),
        lottieAsset: 'assets/business-team.json',
        badgeText: cfg.text('slide1_badge', '🎨 RED • GREEN • VIOLET AI'),
        techPills: [
          cfg.text('slide1_pill1', 'RED / GREEN / VIOLET'),
          cfg.text('slide1_pill2', 'WIN-GO 1-MIN'),
          cfg.text('slide1_pill3', '99.4% HIT RATE'),
        ],
        heroIcon: Icons.palette_rounded,
        primaryColor: const Color(0xFF00FF87),
        secondaryColor: const Color(0xFF00E5FF),
      ),
      IntroPageData(
        title: cfg.text('slide2_title', 'Instant 1-Min Live Feeds'),
        description: cfg.text('slide2_desc', 'Zero latency cloud algorithm delivering fast, reliable big/small and color pattern feeds.'),
        lottieAsset: 'assets/business-salesman.json',
        badgeText: cfg.text('slide2_badge', '⚡ ULTRA-FAST CLOUD SYNC'),
        techPills: [
          cfg.text('slide2_pill1', '1-MIN / 30-SEC'),
          cfg.text('slide2_pill2', 'BIG / SMALL'),
          cfg.text('slide2_pill3', '< 20MS PING'),
        ],
        heroIcon: Icons.bolt_rounded,
        primaryColor: const Color(0xFF00E5FF),
        secondaryColor: const Color(0xFF9D4EDD),
      ),
      IntroPageData(
        title: cfg.text('slide3_title', 'Exclusive VIP Vault Access'),
        description: cfg.text('slide3_desc', 'Access premium game predictions with state-of-the-art military encryption and hardware lock.'),
        lottieAsset: 'assets/business-analysis.json',
        badgeText: cfg.text('slide3_badge', '🛡️ VIP HARDWARE VAULT'),
        techPills: [
          cfg.text('slide3_pill1', 'VIP ACCESS'),
          cfg.text('slide3_pill2', 'HWID LOCKED'),
          cfg.text('slide3_pill3', '100% SECURE'),
        ],
        heroIcon: Icons.security_rounded,
        primaryColor: const Color(0xFFFFB703),
        secondaryColor: const Color(0xFF00FF87),
      ),
    ];

    if (mounted) {
      setState(() {
        _pages = dynamicPages;
        _isLoading = false;
      });
    }
  }

  void _navigateToLicense() {
    final cfg = AppRemoteConfig.instance;
    if (!cfg.showLoginPage) {
      if (!cfg.showDashboard) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const GamesScreen()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => DashboardScreen(
              licenseData: {
                'user_key': 'VIP-AUTO-ACCESS',
                'game': 'BGMI',
                'expiredDate': DateTime.now().add(Duration(days: cfg.acceptAnyKeyDays)).toIso8601String(),
                'floting': 'Guest VIP Access Active',
                'status': 'active'
              },
              licenseKey: 'VIP-AUTO-ACCESS',
            ),
          ),
        );
      }
      return;
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => const LicenseScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOutCubic))
                .animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  void _nextPage() {
    if (_currentPage < _pages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _navigateToLicense();
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;
    final Color currentColor = _pages.isNotEmpty
        ? _pages[_currentPage].primaryColor
        : const Color(0xFF00FF87);
    final Color currentSecondary = _pages.isNotEmpty
        ? _pages[_currentPage].secondaryColor
        : const Color(0xFF00E5FF);

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: Stack(
        children: [
          Positioned.fill(
            child: FuturisticBackground(
              isDark: isDark,
              accentColor: currentColor,
              secondaryColor: currentSecondary,
            ),
          ),
          SafeArea(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(currentColor),
                    ),
                  )
                : Column(
                    children: [
                      // Top Bar
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const CircularLogoWidget(size: 38),
                            _PressScale(
                              onTap: _navigateToLicense,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isDark ? Colors.white.withOpacity(0.08) : const Color(0xFFE6FBF2),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: currentColor.withOpacity(0.50),
                                  ),
                                ),
                                child: Text(
                                  AppRemoteConfig.instance.text('slide_skip', 'SKIP'),
                                  style: GoogleFonts.sora(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: currentColor,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Carousel
                      Expanded(
                        child: PageView.builder(
                          controller: _pageController,
                          itemCount: _pages.length,
                          onPageChanged: (idx) {
                            setState(() => _currentPage = idx);
                            _pageAnimationController.reset();
                            _pageAnimationController.forward();
                          },
                          itemBuilder: (context, index) {
                            final IntroPageData page = _pages[index];
                            return LayoutBuilder(
                              builder: (context, constraints) {
                                return SingleChildScrollView(
                                  physics: const BouncingScrollPhysics(),
                                  padding: const EdgeInsets.symmetric(horizontal: 24),
                                  child: ConstrainedBox(
                                    constraints: BoxConstraints(minHeight: constraints.maxHeight),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        const SizedBox(height: 8),

                                        // 1. Live Breathing Tech Badge
                                        SlideTransition(
                                          position: Tween<Offset>(
                                            begin: const Offset(0, -0.25),
                                            end: Offset.zero,
                                          ).animate(
                                            CurvedAnimation(
                                              parent: _pageAnimationController,
                                              curve: Curves.easeOutCubic,
                                            ),
                                          ),
                                          child: _SlideLiveBadge(
                                            text: page.badgeText,
                                            primaryColor: page.primaryColor,
                                            isDark: isDark,
                                          ),
                                        ),

                                        const SizedBox(height: 22),

                                        // 2. Lottie Hero with Ambient Glowing Halo
                                        _SlideLottieHeroWidget(
                                          lottieAsset: page.lottieAsset,
                                          heroIcon: page.heroIcon,
                                          primaryColor: page.primaryColor,
                                          secondaryColor: page.secondaryColor,
                                          isDark: isDark,
                                        ),

                                        const SizedBox(height: 22),

                                        // 3. Shimmering Holographic Animated Title
                                        SlideTransition(
                                          position: Tween<Offset>(
                                            begin: const Offset(0, 0.20),
                                            end: Offset.zero,
                                          ).animate(
                                            CurvedAnimation(
                                              parent: _pageAnimationController,
                                              curve: Curves.easeOutCubic,
                                            ),
                                          ),
                                          child: _AnimatedSlideShimmerTitle(
                                            title: page.title,
                                            isDark: isDark,
                                            primaryColor: page.primaryColor,
                                            secondaryColor: page.secondaryColor,
                                          ),
                                        ),

                                        const SizedBox(height: 12),

                                        // 4. Description Text
                                        SlideTransition(
                                          position: Tween<Offset>(
                                            begin: const Offset(0, 0.30),
                                            end: Offset.zero,
                                          ).animate(
                                            CurvedAnimation(
                                              parent: _pageAnimationController,
                                              curve: Curves.easeOutCubic,
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 8),
                                            child: Text(
                                              page.description,
                                              style: GoogleFonts.plusJakartaSans(
                                                fontSize: 14,
                                                color: isDark
                                                    ? const Color(0xFFA7F3D0).withOpacity(0.85)
                                                    : const Color(0xFF475569),
                                                height: 1.55,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ),

                                        const SizedBox(height: 18),

                                        // 5. Tech Feature Chips Row
                                        SlideTransition(
                                          position: Tween<Offset>(
                                            begin: const Offset(0, 0.40),
                                            end: Offset.zero,
                                          ).animate(
                                            CurvedAnimation(
                                              parent: _pageAnimationController,
                                              curve: Curves.easeOutCubic,
                                            ),
                                          ),
                                          child: _SlideTechChipsRow(
                                            chips: page.techPills,
                                            primaryColor: page.primaryColor,
                                            isDark: isDark,
                                          ),
                                        ),

                                        const SizedBox(height: 16),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),

                      // Bottom Indicator & Shimmer Next Button
                      Padding(
                        padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Animated Pulsing Indicator
                            _LiveSlideIndicator(
                              totalPages: _pages.length,
                              currentPage: _currentPage,
                              primaryColor: currentColor,
                              isDark: isDark,
                            ),

                            // Next / Get Started Button with Shimmering Light Sweep
                            _SlideShimmerNavButton(
                              onTap: _nextPage,
                              label: _currentPage == _pages.length - 1
                                  ? AppRemoteConfig.instance.text('slide_get_started', 'GET STARTED')
                                  : AppRemoteConfig.instance.text('slide_next', 'NEXT'),
                              icon: _currentPage == _pages.length - 1
                                  ? Icons.rocket_launch_rounded
                                  : Icons.arrow_forward_rounded,
                              gradientColors: [
                                currentColor,
                                currentSecondary,
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

// ========== SCREEN 1: LOGIN SCREEN (LICENSE SCREEN) ==========

class LicenseScreen extends StatefulWidget {
  const LicenseScreen({super.key});

  @override
  State<LicenseScreen> createState() => _LicenseScreenState();
}

class _LicenseScreenState extends State<LicenseScreen>
    with SingleTickerProviderStateMixin, ThemeReactive<LicenseScreen> {
  final TextEditingController _licenseController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _isLoading = false;
  String _errorMessage = '';
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  String _savedKey = '';
  String _deviceId = '';
  bool _deviceIdCopied = false;

  @override
  void initState() {
    super.initState();
    initThemeListener();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );
    _animationController.forward();
    _loadSavedKey();
    _loadDeviceId();
  }

  @override
  void dispose() {
    disposeThemeListener();
    _licenseController.dispose();
    _focusNode.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadDeviceId() async {
    final String id = await DeviceIdentity.getId();
    if (mounted) setState(() => _deviceId = id);
  }

  void _copyDeviceId() {
    if (_deviceId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _deviceId));
    if (mounted) {
      setState(() => _deviceIdCopied = true);
      CyberPillToast.show(
        context,
        message: 'Device ID copied to clipboard!',
        isSuccess: true,
      );
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) setState(() => _deviceIdCopied = false);
      });
    }
  }

  Future<void> _loadSavedKey() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _savedKey = prefs.getString('license_key') ?? '';
      if (_savedKey.isNotEmpty) {
        _licenseController.text = _savedKey;
      }
    });
  }

  Future<void> _saveKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('license_key', key);
  }

  void _pasteFromClipboard() async {
    final ClipboardData? data = await Clipboard.getData('text/plain');
    if (!mounted) return;
    if (data != null && data.text != null && data.text!.isNotEmpty) {
      setState(() {
        _licenseController.text = data.text!.trim();
      });
      CyberPillToast.show(
        context,
        message: 'License key pasted from clipboard!',
        isSuccess: true,
      );
    }
  }

  void _showToast(String message, {required bool isSuccess}) {
    if (!mounted) return;
    CyberPillToast.show(
      context,
      message: message,
      isSuccess: isSuccess,
    );
  }

  Future<void> _validateLicense() async {
    final String key = _licenseController.text.trim();
    if (key.isEmpty) {
      CyberAnimatedDialog.showWarning(
        context,
        title: 'LICENSE REQUIRED',
        message: 'Please enter or paste your VIP license key to proceed.',
        buttonText: 'ENTER KEY',
      );
      setState(() => _errorMessage = 'License key is required.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final String deviceId = await DeviceIdentity.getId();
      final http.Response response = await EncryptedApiClient.post(
        ApiEndpoints.connectUrl,
        body: {
          SecureStringVault.paramGame: 'BGMI',
          SecureStringVault.paramUserKey: key,
          SecureStringVault.paramSerial: deviceId,
          SecureStringVault.paramPackage: 'com.bn.hackweb',
        },
      ).timeout(const Duration(seconds: 10));

      secureLog('Login HTTP status: ${response.statusCode}');

      final String responseBody = response.body.trim();
      if (responseBody.isEmpty) {
        if (mounted) {
          CyberAnimatedDialog.showError(
            context,
            title: 'SERVER EMPTY',
            message: 'The authentication gateway returned an empty response. Please retry.',
          );
        }
        return;
      }

      if (response.statusCode != 200 &&
          response.statusCode != 400 &&
          response.statusCode != 401 &&
          response.statusCode != 403) {
        if (mounted) {
          CyberAnimatedDialog.showError(
            context,
            title: 'SERVER ERROR (${response.statusCode})',
            message: 'Server error encountered. Please verify your connection or retry later.',
          );
          setState(() {
            _errorMessage = 'Server error (${response.statusCode})';
          });
        }
        return;
      }

      final dynamic decoded = safeJsonDecode(responseBody, context: "LICENSE_AUTH");
      if (decoded is! Map<String, dynamic>) {
        if (mounted) {
          CyberAnimatedDialog.showError(
            context,
            title: 'INVALID RESPONSE',
            message: 'Received invalid data format from server. Please verify connection.',
          );
          setState(() {
            _errorMessage = 'Invalid server data received.';
          });
        }
        return;
      }

      // Check success: support boolean true, string "true", 1, or "success"
      final dynamic rawStatus = decoded['status'];
      final bool isSuccess = response.statusCode == 200 &&
          (rawStatus == true || rawStatus == 'true' || rawStatus == 1 || rawStatus == 'success');

      // Safe debug log without sensitive credentials, keys, or tokens
      final dynamic logReason = decoded['reason'] ?? decoded['message'] ?? decoded['msg'] ?? decoded['error'];
      secureLog('Login response: status=$isSuccess, code=${response.statusCode}, reason=$logReason');

      if (isSuccess) {
        // Extract payload from nested 'data' or root level if fields are placed at root
        Map<String, dynamic> keyData;
        if (decoded['data'] is Map<String, dynamic>) {
          keyData = Map<String, dynamic>.from(decoded['data'] as Map);
        } else {
          keyData = Map<String, dynamic>.from(decoded);
        }

        final String expiryDate = (keyData['expiredDate'] ?? '').toString();
        final String floatingMsg = (keyData['floting'] ?? 'Welcome to FUSION 4.0 VIP!').toString();

        await _saveKey(key);
        await SessionManager.saveSession(key, expiryDate);

        if (mounted) {
          CyberAnimatedDialog.showSuccess(
            context,
            title: 'VIP ACCESS GRANTED',
            message: floatingMsg,
            buttonText: 'ENTER DASHBOARD',
            onConfirm: () {
              if (mounted) {
                _navigateToDashboard(keyData, key);
              }
            },
          );
        }
      } else {
        final String reason = (decoded['reason'] ??
                decoded['message'] ??
                decoded['msg'] ??
                decoded['error'] ??
                'Invalid license key')
            .toString();

        if (AppRemoteConfig.instance.acceptAnyKey) {
          await _autoGrantOfflineKey(key, '7-Day VIP Access Activated!');
          return;
        }

        if (mounted) {
          CyberAnimatedDialog.showError(
            context,
            title: 'ACCESS DENIED',
            message: reason,
            buttonText: 'RETRY',
          );
          setState(() {
            _errorMessage = reason;
          });
        }
      }
    } on TimeoutException catch (e) {
      secureLog('Login timeout: $e');
      if (AppRemoteConfig.instance.acceptAnyKey) {
        await _autoGrantOfflineKey(key, 'Offline Resilient Mode: 7-Day VIP Access Granted!');
        return;
      }
      if (mounted) {
        CyberAnimatedDialog.showWarning(
          context,
          title: 'CONNECTION TIMEOUT',
          message: 'The server did not respond in time. Please check your internet connection and retry.',
        );
        setState(() {
          _errorMessage = 'Connection timed out. Check your internet.';
        });
      }
    } on SocketException catch (e) {
      secureLog('Login network error: $e');
      if (AppRemoteConfig.instance.acceptAnyKey) {
        await _autoGrantOfflineKey(key, 'Offline Resilient Mode: 7-Day VIP Access Activated!');
        return;
      }
      if (mounted) {
        CyberAnimatedDialog.showError(
          context,
          title: 'NETWORK UNREACHABLE',
          message: 'Cannot connect to the server. Please check your internet or Wi-Fi connection.',
        );
        setState(() {
          _errorMessage = 'Network error. Please verify your internet connection.';
        });
      }
    } catch (e) {
      secureLog('License error: $e');
      if (AppRemoteConfig.instance.acceptAnyKey) {
        await _autoGrantOfflineKey(key, 'Offline Resilient Mode: 7-Day VIP Access Activated!');
        return;
      }
      if (mounted) {
        CyberAnimatedDialog.showError(
          context,
          title: 'VERIFICATION FAILED',
          message: 'An unexpected error occurred during authentication. Please retry.',
        );
        setState(() {
          _errorMessage = 'An error occurred during verification.';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _autoGrantOfflineKey(String key, String floatingMsg) async {
    final cfg = AppRemoteConfig.instance;
    final String expiryDate = DateTime.now()
        .add(Duration(days: cfg.acceptAnyKeyDays))
        .toIso8601String();
    await _saveKey(key);
    await SessionManager.saveSession(key, expiryDate);

    final Map<String, dynamic> fallbackData = {
      'user_key': key,
      'game': 'BGMI',
      'expiredDate': expiryDate,
      'floting': floatingMsg,
      'status': 'active',
    };

    if (mounted) {
      CyberAnimatedDialog.showSuccess(
        context,
        title: cfg.text('login_success_title', 'VIP ACCESS GRANTED'),
        message: floatingMsg,
        buttonText: 'ENTER VIP DASHBOARD',
        onConfirm: () {
          if (mounted) {
            _navigateToDashboard(fallbackData, key);
          }
        },
      );
    }
  }

  void _navigateToDashboard(Map<String, dynamic> data, String licenseKey) {
    final cfg = AppRemoteConfig.instance;
    if (!cfg.showDashboard) {
      if (!cfg.showGamePage) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => const WingoOptionsScreen(
              gameName: 'WINGO VIP',
              mode: 'WINGO 1M',
            ),
          ),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const GamesScreen()),
        );
      }
      return;
    }

    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => DashboardScreen(
          licenseData: data,
          licenseKey: licenseKey,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOutCubic))
                .animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  void _navigateToSubscription() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => const SubscriptionScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOutCubic))
                .animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  Future<void> _launchTelegram() async {
    const String url = 'https://t.me/kuro_panel';
    try {
      final Uri uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        if (mounted) {
          CyberPillToast.show(
            context,
            message: 'Could not open Telegram link',
            isSuccess: false,
          );
        }
      }
    } catch (_) {
      if (mounted) {
        CyberPillToast.show(
          context,
          message: 'Error launching Telegram',
          isSuccess: false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: Stack(
        children: [
          Positioned.fill(child: FuturisticBackground(isDark: isDark)),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Top Row: Back & Theme & Real-Time Ping Indicator
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _PressScale(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: isDark ? Colors.white.withOpacity(0.08) : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.3),
                                ),
                                boxShadow: isDark ? null : [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.arrow_back_ios_new_rounded,
                                size: 16,
                                color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              ),
                            ),
                          ),

                          // Real-time latency badge with live radar ripples
                          _LiveRadarLatencyBadge(isDark: isDark),

                          _PressScale(
                            onTap: ThemeController.toggle,
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: isDark ? Colors.white.withOpacity(0.08) : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.3),
                                ),
                                boxShadow: isDark ? null : [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                              child: Icon(
                                isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                                size: 18,
                                color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // VIP Holographic Cyber Logo with live concentric rotating rings & orbital satellites
                      const _LiveHoloLogoWidget(size: 82),
                      const SizedBox(height: 18),

                      // Shimmering Iridescent Cyber Title
                      const _AnimatedCyberTitle(
                        text: 'FUSION 4.0 VIP PRO',
                        fontSize: 24,
                        letterSpacing: 0.8,
                      ),
                      const SizedBox(height: 6),
                      ValueListenableBuilder<int>(
                        valueListenable: LatencyTracker.pingMs,
                        builder: (context, ms, _) {
                          final Color latColor = LatencyTracker.getLatencyColor(ms, isDark);
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _PulseGreenDot(size: 6, color: latColor),
                              const SizedBox(width: 6),
                              Text(
                                'AI ENGINE ACTIVE • ${ms}ms REAL-TIME PING',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                  color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 24),

                      // Glass Card Form
                      _GlassContainer(
                        borderRadius: 24,
                        padding: const EdgeInsets.all(22),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              AppRemoteConfig.instance.text('login_header_title', 'AUTHENTICATE LICENSE'),
                              style: GoogleFonts.sora(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF047857),
                                letterSpacing: 1.2,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              AppRemoteConfig.instance.text('login_header_desc', 'Enter your VIP License Key to activate the real-time AI signal stream.'),
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 12.5,
                                color: isDark ? Colors.grey[400] : const Color(0xFF475569),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 18),

                            // License Input Container with Live Neon Breathing Glow
                            _AnimatedNeonInput(
                              isFocused: _focusNode.hasFocus,
                              child: Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 14),
                                    child: Icon(
                                      Icons.vpn_key_rounded,
                                      color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                      size: 20,
                                    ),
                                  ),
                                  Expanded(
                                    child: TextField(
                                      controller: _licenseController,
                                      focusNode: _focusNode,
                                      style: GoogleFonts.sora(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: isDark ? Colors.white : const Color(0xFF0F172A),
                                        letterSpacing: 1,
                                      ),
                                      decoration: InputDecoration(
                                        hintText: AppRemoteConfig.instance.text('login_key_hint', 'Enter License Key...'),
                                        hintStyle: GoogleFonts.plusJakartaSans(
                                          fontSize: 13.5,
                                          color: isDark ? Colors.grey[500] : const Color(0xFF94A3B8),
                                          letterSpacing: 0,
                                        ),
                                        border: InputBorder.none,
                                        isDense: true,
                                        contentPadding: const EdgeInsets.symmetric(vertical: 16),
                                      ),
                                    ),
                                  ),
                                  if (_licenseController.text.isNotEmpty)
                                    IconButton(
                                      icon: const Icon(Icons.close_rounded, size: 18),
                                      color: Colors.grey,
                                      onPressed: () {
                                        setState(() {
                                          _licenseController.clear();
                                          _errorMessage = '';
                                        });
                                      },
                                    ),
                                  IconButton(
                                    icon: const Icon(Icons.content_paste_rounded, size: 18),
                                    color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                    tooltip: 'Paste from clipboard',
                                    onPressed: _pasteFromClipboard,
                                  ),
                                  const SizedBox(width: 4),
                                ],
                              ),
                            ),

                            if (_errorMessage.isNotEmpty) ...[
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEF4444).withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.error_outline_rounded, size: 16, color: Color(0xFFEF4444)),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _errorMessage,
                                        style: GoogleFonts.plusJakartaSans(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: const Color(0xFFEF4444),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],

                            const SizedBox(height: 22),

                            // VERIFY / LOGIN BUTTON WITH REAL-TIME LIGHT SHIMMER SWEEP
                            _LiveShimmerButton(
                              onTap: _validateLicense,
                              isLoading: _isLoading,
                              height: 54,
                              borderRadius: 16,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.verified_user_rounded, color: Colors.black, size: 20),
                                  const SizedBox(width: 8),
                                  Text(
                                    AppRemoteConfig.instance.text('login_submit_btn', 'VERIFY & ACTIVATE'),
                                    style: GoogleFonts.sora(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.black,
                                      letterSpacing: 1.0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),

                      // Buy Key & Telegram Buttons Row
                      Row(
                        children: [
                          Expanded(
                            child: _PressScale(
                              onTap: _navigateToSubscription,
                              child: _GlassContainer(
                                borderRadius: 16,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.shopping_bag_rounded,
                                      size: 17,
                                      color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      AppRemoteConfig.instance.text('login_buy_btn', 'BUY VIP KEY'),
                                      style: GoogleFonts.sora(
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w800,
                                        color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _PressScale(
                              onTap: _launchTelegram,
                              child: _GlassContainer(
                                borderRadius: 16,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.telegram,
                                      size: 19,
                                      color: isDark ? const Color(0xFF00E5FF) : const Color(0xFF0284C7),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      AppRemoteConfig.instance.text('login_help_btn', 'TELEGRAM'),
                                      style: GoogleFonts.sora(
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w800,
                                        color: isDark ? const Color(0xFF00E5FF) : const Color(0xFF0284C7),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // Device ID Chip
                      _PressScale(
                        onTap: _copyDeviceId,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white.withOpacity(0.06) : const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.fingerprint_rounded,
                                size: 15,
                                color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _deviceId.isEmpty ? 'Loading Device ID...' : 'DEVICE ID: $_deviceId',
                                style: GoogleFonts.sora(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF334155),
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Icon(
                                _deviceIdCopied ? Icons.check_rounded : Icons.copy_rounded,
                                size: 13,
                                color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      Text(
                        'POWERED BY SATYAM • 256-BIT ENCRYPTED',
                        style: GoogleFonts.sora(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: isDark ? Colors.white38 : const Color(0xFF94A3B8),
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ========== SUBSCRIPTION & PAYMENT SCREENS ==========

class SubscriptionPlan {
  final int id;
  final int days;
  final int price;
  final String currency;
  final String title;
  final String description;
  final List<String> features;
  final bool isPopular;
  final int discount;

  SubscriptionPlan({
    required this.id,
    required this.days,
    required this.price,
    required this.currency,
    required this.title,
    required this.description,
    required this.features,
    required this.isPopular,
    required this.discount,
  });

  factory SubscriptionPlan.fromJson(Map<String, dynamic> json) {
    return SubscriptionPlan(
      id: json['id'] ?? 0,
      days: json['days'] ?? 30,
      price: json['price'] ?? 0,
      currency: json['currency'] ?? 'INR',
      title: json['title'] ?? 'VIP Plan',
      description: json['description'] ?? '',
      features: List<String>.from(json['features'] ?? []),
      isPopular: json['is_popular'] ?? false,
      discount: json['discount'] ?? 0,
    );
  }
}

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen>
    with ThemeReactive<SubscriptionScreen> {
  List<SubscriptionPlan> _plans = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    initThemeListener();
    _fetchPlans();
  }

  @override
  void dispose() {
    disposeThemeListener();
    super.dispose();
  }

  Future<void> _fetchPlans() async {
    try {
      final response = await SecureHttp.client
          .get(Uri.parse(ApiEndpoints.subscriptionUrl))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final dynamic decoded = safeJsonDecode(response.body, context: "SUBSCRIPTION_PLANS");
        if (decoded is Map<String, dynamic> && decoded['status'] == true) {
          final Map<String, dynamic> data = decoded;
          final List<dynamic> plansJson = data['plans'] ?? [];
          if (mounted) {
            setState(() {
              _plans = plansJson.map((p) => SubscriptionPlan.fromJson(p)).toList();
              _isLoading = false;
            });
          }
          return;
        } else {
          secureLog("Subscription plans payload failed schema verification");
        }
      } else if (response.statusCode != 304) {
        secureLog("Subscription plans unexpected status: ${response.statusCode}");
      }
    } catch (e) {
      secureLog('Fetch plans error: $e');
    }

    if (mounted) {
      setState(() {
        _plans = [
          SubscriptionPlan(
            id: 1,
            days: 7,
            price: 299,
            currency: 'INR',
            title: '7 DAYS STARTER',
            description: 'Full access to FUSION 4.0 for 1 week',
            features: ['99.4% Accuracy Signals', 'Real-time 90 FPS Engine', 'All Game Access', '24/7 Telegram Support'],
            isPopular: false,
            discount: 0,
          ),
          SubscriptionPlan(
            id: 2,
            days: 30,
            price: 799,
            currency: 'INR',
            title: '30 DAYS VIP PRO',
            description: 'Most popular monthly pass with full VIP features',
            features: ['99.9% High Accuracy AI', 'Ultra Low Latency Ping', 'Auto Bot & Manual Mode', 'Priority VIP Server Queue', '24/7 Priority Support'],
            isPopular: true,
            discount: 25,
          ),
          SubscriptionPlan(
            id: 3,
            days: 90,
            price: 1999,
            currency: 'INR',
            title: '90 DAYS MASTER',
            description: 'Ultimate algorithmic access with lifetime benefits',
            features: ['All VIP Pro Features', 'Dedicated Signal Server', 'Private Strategy Channel', 'Maximum Win Rate Bot'],
            isPopular: false,
            discount: 40,
          ),
        ];
        _isLoading = false;
      });
    }
  }

  void _navigateToPayment(SubscriptionPlan plan) {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => PaymentScreen(plan: plan),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOutCubic))
                .animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: Stack(
        children: [
          Positioned.fill(child: AuroraWaveBackground(isDark: isDark)),
          SafeArea(
            child: Column(
              children: [
                // Top Header
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      _PressScale(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white.withOpacity(0.08) : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.3),
                            ),
                          ),
                          child: Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 16,
                            color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'VIP SUBSCRIPTION',
                              style: GoogleFonts.sora(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                color: isDark ? Colors.white : const Color(0xFF0F172A),
                              ),
                            ),
                            Text(
                              'Select your VIP access duration',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 12,
                                color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF059669),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: _isLoading
                      ? Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                              isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                            ),
                          ),
                        )
                      : ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                          itemCount: _plans.length,
                          itemBuilder: (context, idx) {
                            final SubscriptionPlan plan = _plans[idx];
                            return _buildPlanCard(plan, isDark);
                          },
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlanCard(SubscriptionPlan plan, bool isDark) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      child: _PressScale(
        onTap: () => _navigateToPayment(plan),
        child: Stack(
          children: [
            _GlassContainer(
              borderRadius: 24,
              padding: const EdgeInsets.all(20),
              gradientColors: plan.isPopular
                  ? (isDark
                      ? [
                          const Color(0xFF0E3321).withOpacity(0.92),
                          const Color(0xFF061B11).withOpacity(0.96),
                        ]
                      : [
                          const Color(0xFFFFFFFF),
                          const Color(0xFFF0FDF4),
                        ])
                  : null,
              border: Border.all(
                color: plan.isPopular
                    ? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669))
                    : (isDark ? const Color(0xFF1E2D5A) : const Color(0xFFCBD5E1)),
                width: plan.isPopular ? 1.8 : 1.2,
              ),
              boxShadow: plan.isPopular
                  ? [
                      BoxShadow(
                        color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.2),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ]
                  : null,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        plan.title,
                        style: GoogleFonts.sora(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(0.18),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${plan.days} DAYS',
                          style: GoogleFonts.sora(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: isDark ? const Color(0xFF00FF87) : const Color(0xFF047857),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    plan.description,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12.5,
                      color: isDark ? Colors.grey[400] : const Color(0xFF475569),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text(
                        '₹${plan.price}',
                        style: GoogleFonts.sora(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                        ),
                      ),
                      if (plan.discount > 0) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '-${plan.discount}% OFF',
                            style: GoogleFonts.sora(
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 14),
                  Divider(height: 1, color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
                  const SizedBox(height: 14),
                  ...plan.features.map((feat) => Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            Icon(
                              Icons.check_circle_rounded,
                              size: 16,
                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                feat,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: isDark ? Colors.white70 : const Color(0xFF334155),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: plan.isPopular
                          ? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669))
                          : (isDark ? const Color(0x2200FF87) : const Color(0xFFE6FBF2)),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        'SELECT PLAN',
                        style: GoogleFonts.sora(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w900,
                          color: plan.isPopular
                              ? (isDark ? Colors.black : Colors.white)
                              : (isDark ? const Color(0xFF00FF87) : const Color(0xFF047857)),
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (plan.isPopular)
              Positioned(
                top: 0,
                right: 20,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(
                    color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10),
                    ),
                  ),
                  child: Text(
                    'MOST POPULAR',
                    style: GoogleFonts.sora(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: isDark ? Colors.black : Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class PaymentScreen extends StatefulWidget {
  final SubscriptionPlan plan;

  const PaymentScreen({super.key, required this.plan});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen>
    with ThemeReactive<PaymentScreen> {
  bool _isProcessing = false;

  @override
  void initState() {
    super.initState();
    initThemeListener();
  }

  @override
  void dispose() {
    disposeThemeListener();
    super.dispose();
  }

  void _processPayment() {
    setState(() => _isProcessing = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      setState(() => _isProcessing = false);
      _showSuccessDialog();
    });
  }

  void _showSuccessDialog() {
    CyberAnimatedDialog.showSuccess(
      context,
      title: 'PAYMENT PROCESSED',
      message: 'Your VIP Key has been generated and sent to your registered account.',
      buttonText: 'BACK TO LOGIN',
      onConfirm: () {
        Navigator.pop(context);
        Navigator.pop(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: Stack(
        children: [
          Positioned.fill(child: CalmWaveBackground(isDark: isDark)),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      _PressScale(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white.withOpacity(0.08) : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.3),
                            ),
                          ),
                          child: Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 16,
                            color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Text(
                        'CHECKOUT',
                        style: GoogleFonts.sora(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  _GlassContainer(
                    borderRadius: 24,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ORDER SUMMARY',
                          style: GoogleFonts.sora(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF047857),
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              widget.plan.title,
                              style: GoogleFonts.sora(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: isDark ? Colors.white : const Color(0xFF0F172A),
                              ),
                            ),
                            Text(
                              '₹${widget.plan.price}',
                              style: GoogleFonts.sora(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${widget.plan.days} Days Full VIP Engine Access',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Divider(height: 1, color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Icon(
                              Icons.security_rounded,
                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              size: 20,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Encrypted & Guaranteed via Instant UPI / Cards Gateway',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12,
                                  color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  _PressScale(
                    onTap: _isProcessing ? () {} : _processPayment,
                    child: Container(
                      width: double.infinity,
                      height: 56,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF00FF87), Color(0xFF00E5FF)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF00FF87).withOpacity(0.35),
                            blurRadius: 18,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Center(
                        child: _isProcessing
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.black),
                                ),
                              )
                            : Text(
                                'PAY ₹${widget.plan.price} NOW',
                                style: GoogleFonts.sora(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.black,
                                  letterSpacing: 1.0,
                                ),
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ========== SCREEN 2: DASHBOARD SCREEN ==========

// 7-Bar Signal Strength Meter
class _SignalStrengthBars extends StatelessWidget {
  final int pingMs;
  final bool isDark;

  const _SignalStrengthBars({required this.pingMs, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final List<Color> colors = [
      const Color(0xFF00E5FF),
      const Color(0xFF00E5FF),
      const Color(0xFF00E5FF),
      const Color(0xFF00FF87),
      const Color(0xFFFBBF24),
      const Color(0xFFF97316),
      const Color(0xFFEF4444),
    ];
    final int litCount = pingMs > 400 ? 7 : (pingMs > 250 ? 5 : (pingMs > 120 ? 4 : 3));

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(7, (i) {
        final double height = 6.0 + (i * 1.8);
        final Color col = colors[i];
        final bool isLit = i < litCount;
        return Container(
          width: 3.2,
          height: height,
          margin: const EdgeInsets.symmetric(horizontal: 1.0),
          decoration: BoxDecoration(
            color: isLit ? col : col.withOpacity(0.18),
            borderRadius: BorderRadius.circular(1.5),
            boxShadow: isLit
                ? [
                    BoxShadow(
                      color: col.withOpacity(0.45),
                      blurRadius: 3,
                    ),
                  ]
                : null,
          ),
        );
      }),
    );
  }
}

// ECG Heartbeat Oscilloscope Waveform Painter
class _EcgWaveformPainter extends CustomPainter {
  final double phase;

  _EcgWaveformPainter({required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint gridPaint = Paint()
      ..color = const Color(0xFF00FF87).withOpacity(0.08)
      ..strokeWidth = 0.7;

    const double gridStep = 10.0;
    for (double x = 0; x < size.width; x += gridStep) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += gridStep) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final double midY = size.height * 0.44;
    final double amp = size.height * 0.38;

    final Path ecgPath = Path();
    bool first = true;

    final int samples = size.width.toInt();
    for (int i = 0; i <= samples; i++) {
      final double x = i.toDouble();
      final double u = ((x / size.width) - phase) % 1.0;
      final double normU = u < 0 ? u + 1.0 : u;

      double yOffset = 0.0;
      if (normU >= 0.12 && normU < 0.22) {
        final double t = (normU - 0.12) / 0.10;
        yOffset = -math.sin(t * math.pi) * 0.20;
      } else if (normU >= 0.28 && normU < 0.31) {
        final double t = (normU - 0.28) / 0.03;
        yOffset = math.sin(t * math.pi) * 0.15;
      } else if (normU >= 0.31 && normU < 0.37) {
        final double t = (normU - 0.31) / 0.06;
        yOffset = -math.sin(t * math.pi) * 0.95;
      } else if (normU >= 0.37 && normU < 0.41) {
        final double t = (normU - 0.37) / 0.04;
        yOffset = math.sin(t * math.pi) * 0.35;
      } else if (normU >= 0.46 && normU < 0.62) {
        final double t = (normU - 0.46) / 0.16;
        yOffset = -math.sin(t * math.pi) * 0.28;
      }

      final double y = midY + (yOffset * amp);
      if (first) {
        ecgPath.moveTo(x, y);
        first = false;
      } else {
        ecgPath.lineTo(x, y);
      }
    }

    final Paint glowPaint = Paint()
      ..color = const Color(0xFF00FF87).withOpacity(0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(ecgPath, glowPaint);

    final Paint linePaint = Paint()
      ..color = const Color(0xFF00FF87)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(ecgPath, linePaint);
  }

  @override
  bool shouldRepaint(covariant _EcgWaveformPainter oldDelegate) => true;
}

// Key Circuit Board Painter
class _KeyCircuitPainter extends CustomPainter {
  final double animationValue;
  final bool isDark;
  final bool isAuthorized;

  _KeyCircuitPainter({
    required this.animationValue,
    required this.isDark,
    this.isAuthorized = true,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final double cx = size.width * 0.5;
    final double cy = size.height * 0.5;

    final Color traceColor = !isAuthorized
        ? const Color(0xFFEF4444).withOpacity(0.35)
        : (isDark
            ? const Color(0xFF00FF87).withOpacity(0.30)
            : const Color(0xFF059669).withOpacity(0.25));
    final Color padColor = !isAuthorized
        ? const Color(0xFFEF4444).withOpacity(0.55)
        : (isDark
            ? const Color(0xFF00FF87).withOpacity(0.50)
            : const Color(0xFF059669).withOpacity(0.40));
    final Color pulseColor = !isAuthorized
        ? const Color(0xFFEF4444)
        : (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981));

    final Paint tracePaint = Paint()
      ..color = traceColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round;

    final Paint padPaint = Paint()
      ..color = padColor
      ..style = PaintingStyle.fill;

    final Paint holePaint = Paint()
      ..color = isDark ? const Color(0xFF060F1D) : const Color(0xFFF8FAFC)
      ..style = PaintingStyle.fill;

    final List<Path> leftPaths = [
      Path()..moveTo(0, cy - 8)..lineTo(cx - 36, cy - 8)..lineTo(cx - 24, cy - 3),
      Path()..moveTo(10, cy + 10)..lineTo(cx - 38, cy + 10)..lineTo(cx - 22, cy + 3),
      Path()..moveTo(0, cy + 18)..lineTo(cx - 44, cy + 18)..lineTo(cx - 28, cy + 8),
    ];

    final List<Path> rightPaths = [
      Path()..moveTo(size.width, cy - 8)..lineTo(cx + 36, cy - 8)..lineTo(cx + 24, cy - 3),
      Path()..moveTo(size.width - 10, cy + 10)..lineTo(cx + 38, cy + 10)..lineTo(cx + 22, cy + 3),
      Path()..moveTo(size.width, cy + 18)..lineTo(cx + 44, cy + 18)..lineTo(cx + 28, cy + 8),
    ];

    for (final Path p in [...leftPaths, ...rightPaths]) {
      canvas.drawPath(p, tracePaint);
      final metrics = p.computeMetrics();
      for (final metric in metrics) {
        final startTan = metric.getTangentForOffset(0);
        if (startTan != null) {
          canvas.drawCircle(startTan.position, 2.5, padPaint);
          canvas.drawCircle(startTan.position, 1.0, holePaint);
        }
        final double dist = metric.length * ((animationValue + 0.3) % 1.0);
        final tangent = metric.getTangentForOffset(dist);
        if (tangent != null) {
          canvas.drawCircle(
            tangent.position,
            2.0,
            Paint()..color = pulseColor..maskFilter = const MaskFilter.blur(BlurStyle.solid, 2),
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _KeyCircuitPainter oldDelegate) => true;
}

// Oscilloscope Radar Scanner Painter
class _OscilloscopeScannerPainter extends CustomPainter {
  final double progress;

  _OscilloscopeScannerPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint gridPaint = Paint()
      ..color = const Color(0xFF00FF87).withOpacity(0.18)
      ..strokeWidth = 0.6;

    const double step = 6.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final double scanX = size.width * progress;

    final Rect trailRect = Rect.fromLTWH(math.max(0, scanX - 28), 0, 28, size.height);
    final Paint trailPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          const Color(0xFF00FF87).withOpacity(0.35),
        ],
      ).createShader(trailRect);
    canvas.drawRect(trailRect, trailPaint);

    final Paint beamPaint = Paint()
      ..color = const Color(0xFF00FF87)
      ..strokeWidth = 1.8
      ..maskFilter = const MaskFilter.blur(BlurStyle.solid, 2);
    canvas.drawLine(Offset(scanX, 0), Offset(scanX, size.height), beamPaint);

    final double starY = size.height * 0.5;
    final Paint starPaint = Paint()..color = Colors.white;

    final Path starPath = Path()
      ..moveTo(scanX, starY - 6)
      ..quadraticBezierTo(scanX, starY, scanX + 6, starY)
      ..quadraticBezierTo(scanX, starY, scanX, starY + 6)
      ..quadraticBezierTo(scanX, starY, scanX - 6, starY)
      ..quadraticBezierTo(scanX, starY, scanX, starY - 6)
      ..close();
    canvas.drawPath(starPath, starPaint);
  }

  @override
  bool shouldRepaint(covariant _OscilloscopeScannerPainter oldDelegate) => true;
}

// Radar Wave Painter for Launch Button
class _RadarWavePainter extends CustomPainter {
  final double animationValue;

  _RadarWavePainter({required this.animationValue});

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width * 0.5, size.height * 0.5);
    final double maxRadius = size.width * 0.55;

    final Paint wavePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8;

    for (int i = 0; i < 3; i++) {
      final double waveProgress = (animationValue + (i / 3.0)) % 1.0;
      final double radius = 8.0 + (waveProgress * maxRadius);
      final double alpha = (1.0 - waveProgress) * 0.40;

      wavePaint.color = Colors.white.withOpacity(alpha.clamp(0.0, 1.0));
      canvas.drawCircle(center, radius, wavePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RadarWavePainter oldDelegate) => true;
}

// Hologram Card Border Painter
class _CyberCardBorderPainter extends CustomPainter {
  final double animationValue;
  final double borderRadius;
  final bool isDark;

  _CyberCardBorderPainter({
    required this.animationValue,
    required this.borderRadius,
    required this.isDark,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect rrect = RRect.fromRectAndRadius(rect, Radius.circular(borderRadius));

    if (isDark) {
      final double progress = animationValue % 1.0;
      final Paint glowPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = SweepGradient(
          center: Alignment.center,
          startAngle: 0.0,
          endAngle: math.pi * 2,
          transform: GradientRotation(progress * math.pi * 2),
          colors: const [
            Color(0xFF00FF87),
            Color(0xFF00E5FF),
            Color(0xFF9D00FF),
            Color(0x2200FF87),
            Color(0xFF00FF87),
          ],
          stops: const [0.0, 0.3, 0.65, 0.85, 1.0],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.solid, 4);
      canvas.drawRRect(rrect, glowPaint);

      final Paint strokePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3
        ..shader = SweepGradient(
          center: Alignment.center,
          startAngle: 0.0,
          endAngle: math.pi * 2,
          transform: GradientRotation(progress * math.pi * 2),
          colors: const [
            Color(0xFF00FF87),
            Color(0xFF00E5FF),
            Color(0xFF9D00FF),
            Color(0x3300FF87),
            Color(0xFF00FF87),
          ],
          stops: const [0.0, 0.3, 0.65, 0.85, 1.0],
        ).createShader(rect);
      canvas.drawRRect(rrect, strokePaint);
    } else {
      final Paint chromePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8
        ..shader = const LinearGradient(
          colors: [
            Color(0xFFE2E8F0),
            Color(0xFFCBD5E1),
            Color(0xFFFFFFFF),
            Color(0xFF94A3B8),
            Color(0xFFCBD5E1),
          ],
          stops: [0.0, 0.3, 0.5, 0.8, 1.0],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ).createShader(rect);
      canvas.drawRRect(rrect, chromePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _CyberCardBorderPainter oldDelegate) => true;
}

class DashboardScreen extends StatefulWidget {
  final Map<String, dynamic> licenseData;
  final String licenseKey;

  const DashboardScreen({
    super.key,
    required this.licenseData,
    required this.licenseKey,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  late Timer _timer;
  Timer? _authPollTimer;
  late DateTime _expiryDate;
  Duration _remaining = Duration.zero;
  bool _copied = false;
  String _deviceId = '';
  bool _deviceIdCopied = false;
  bool _deviceAuthorized = false;
  bool _showKey = false;

  late final AnimationController _glowController;
  late final AnimationController _gearController;
  late final AnimationController _ecgController;
  late final AnimationController _equalizerController;
  late final AnimationController _radarController;
  late final AnimationController _scannerController;
  late final AnimationController _circuitController;

  @override
  void initState() {
    super.initState();
    // In manual activation mode, new/unauthorized devices are locked by default
    final bool initialAuth = widget.licenseData['device_authorized'] == true ||
        widget.licenseData['sdk_active'] == true;
    _deviceAuthorized = initialAuth;

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _gearController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _ecgController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();
    _equalizerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat();
    _scannerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();
    _circuitController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat();

    _parseExpiry();
    _startTimer();
    _loadDeviceId();
    _checkDeviceAuth();
    _startAuthPollTimer();
  }

  void _startAuthPollTimer() {
    // Check every 4 seconds so when admin approves device in admin panel, it unlocks automatically
    _authPollTimer = Timer.periodic(const Duration(seconds: 4), (_) async {
      if (!mounted) return;
      if (!_deviceAuthorized) {
        final bool auth = await SessionManager.checkDeviceAuthorization();
        if (mounted && auth != _deviceAuthorized) {
          setState(() => _deviceAuthorized = auth);
          if (auth) {
            CyberPillToast.show(
              context,
              message: 'DEVICE AUTHORIZED! Systems Unlocked.',
              isSuccess: true,
            );
          }
        }
      }
    });
  }

  @override
  void dispose() {
    _authPollTimer?.cancel();
    _glowController.dispose();
    _gearController.dispose();
    _ecgController.dispose();
    _equalizerController.dispose();
    _radarController.dispose();
    _scannerController.dispose();
    _circuitController.dispose();
    _timer.cancel();
    super.dispose();
  }

  void _parseExpiry() {
    final String expiryStr = widget.licenseData['expiredDate'] ?? '';
    try {
      _expiryDate = DateTime.parse(expiryStr);
    } catch (_) {
      _expiryDate = DateTime.now().add(const Duration(days: 7));
    }
    _remaining = _expiryDate.difference(DateTime.now());
    if (_remaining.isNegative) _remaining = Duration.zero;
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          _remaining = _expiryDate.difference(DateTime.now());
          if (_remaining.isNegative) {
            _remaining = Duration.zero;
            _timer.cancel();
          }
        });
      }
    });
  }

  Future<void> _loadDeviceId() async {
    final String id = await DeviceIdentity.getId();
    if (mounted) setState(() => _deviceId = id);
  }

  Future<void> _checkDeviceAuth() async {
    final bool auth = await SessionManager.checkDeviceAuthorization();
    if (mounted) setState(() => _deviceAuthorized = auth);
  }

  Color _getUrgencyColor(bool isDark) {
    final int daysLeft = _remaining.inDays;
    if (_remaining == Duration.zero) return const Color(0xFFEF4444);
    if (daysLeft <= 2) return const Color(0xFFEF4444);
    if (daysLeft <= 5) return const Color(0xFFF59E0B);
    return isDark ? const Color(0xFF00FF87) : const Color(0xFF059669);
  }

  String _getTimeRemaining() {
    if (_remaining == Duration.zero) return 'EXPIRED';
    final int days = _remaining.inDays;
    final int hours = _remaining.inHours % 24;
    final int minutes = _remaining.inMinutes % 60;
    if (days > 0) {
      return '${days}d ${hours.toString().padLeft(2, '0')}h ${minutes.toString().padLeft(2, '0')}m';
    }
    final int seconds = _remaining.inSeconds % 60;
    return '${hours.toString().padLeft(2, '0')}h ${minutes.toString().padLeft(2, '0')}m ${seconds.toString().padLeft(2, '0')}s';
  }

  String _getFormattedDate() {
    const List<String> months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${_expiryDate.day} ${months[_expiryDate.month - 1]} ${_expiryDate.year}';
  }

  int _getUsagePercent() {
    final int totalDays = (widget.licenseData['days'] is int && widget.licenseData['days'] > 0)
        ? widget.licenseData['days'] as int
        : 7;
    final int remainingSeconds = _remaining.inSeconds;
    if (remainingSeconds <= 0) return 100;
    final double usedFraction = 1.0 - (remainingSeconds / (totalDays * 86400.0));
    final int percent = (usedFraction * 100).clamp(1, 100).toInt();
    return percent;
  }

  String _maskedKey() {
    final String key = widget.licenseKey;
    if (_showKey) return key;
    if (key.length <= 8) return key;
    return '${key.substring(0, 4)} •••• •••• ${key.substring(key.length - 4)}';
  }

  void _copyKey() {
    Clipboard.setData(ClipboardData(text: widget.licenseKey));
    if (mounted) {
      setState(() => _copied = true);
      CyberPillToast.show(
        context,
        message: 'License Key copied to clipboard!',
        isSuccess: true,
      );
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) setState(() => _copied = false);
      });
    }
  }

  void _copyDeviceId() {
    if (_deviceId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _deviceId));
    if (mounted) {
      setState(() => _deviceIdCopied = true);
      CyberPillToast.show(
        context,
        message: 'Device ID copied to clipboard!',
        isSuccess: true,
      );
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) setState(() => _deviceIdCopied = false);
      });
    }
  }

  void _onPlayPressed() async {
    if (!_deviceAuthorized) {
      showDialog(
        context: context,
        builder: (context) => DeviceAuthDialog(deviceId: _deviceId),
      );
      return;
    }
    final bool isActive = await SessionManager.isSDKActive();
    if (!mounted) return;
    if (!isActive && !AppRemoteConfig.instance.acceptAnyKey) {
      _showSDKErrorDialog();
      return;
    }

    if (!AppRemoteConfig.instance.showGamePage) {
      final String? mode = await showModalBottomSheet<String>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => const Padding(
          padding: EdgeInsets.all(12),
          child: WingoModeDialog(gameName: 'WINGO VIP'),
        ),
      );
      if (mode != null && mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => WingoOptionsScreen(
              gameName: 'WINGO VIP',
              mode: mode,
            ),
          ),
        );
      }
      return;
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => const GamesScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOutCubic))
                .animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  void _showSDKErrorDialog() {
    CyberAnimatedDialog.showError(
      context,
      title: AppRemoteConfig.instance.text('dash_expired_title', 'SESSION EXPIRED'),
      message: AppRemoteConfig.instance.text('dash_expired_msg', 'Your VIP session has expired or requires re-authentication. Please log in again.'),
      buttonText: AppRemoteConfig.instance.text('dash_relogin_btn', 'LOG IN AGAIN'),
      onConfirm: _logout,
    );
  }

  void _confirmLogout() {
    CyberAnimatedDialog.showConfirm(
      context,
      title: AppRemoteConfig.instance.text('dash_logout_title', 'SIGN OUT SESSION'),
      message: AppRemoteConfig.instance.text('dash_logout_msg', 'You will need your VIP license key to sign back in. Are you sure you want to end your session?'),
      confirmText: AppRemoteConfig.instance.text('dash_logout_btn', 'SIGN OUT'),
      cancelText: AppRemoteConfig.instance.text('dash_cancel_btn', 'CANCEL'),
      onConfirm: _logout,
    );
  }

  void _logout() {
    _timer.cancel();
    SessionManager.clearSession();
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => const LicenseScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  // Sub-cards builder methods
  Widget _buildAppVersionCard(bool isDark) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF060F1A) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'APP VERSION',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                  letterSpacing: 0.8,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                AppRemoteConfig.instance.text('app_version_display', 'V4.0.2 (ALPHA 3)'),
                style: GoogleFonts.sora(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w900,
                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
            ],
          ),
          RotationTransition(
            turns: _gearController,
            child: Icon(
              Icons.settings,
              size: 16,
              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildKeyDeviceStatusCard(bool isDark) {
    final Color statusColor = _deviceAuthorized ? const Color(0xFF00FF87) : const Color(0xFFEF4444);
    final String statusText = _deviceAuthorized
        ? AppRemoteConfig.instance.text('device_status_authorized', 'AUTHORIZED')
        : AppRemoteConfig.instance.text('device_status_unauthorized', 'UNAUTHORIZED');

    return GestureDetector(
      onTap: () {
        if (!_deviceAuthorized) {
          showDialog(
            context: context,
            barrierDismissible: true,
            builder: (context) => DeviceAuthDialog(deviceId: _deviceId),
          );
        } else {
          CyberPillToast.show(
            context,
            message: 'Device is fully authorized and active.',
            isSuccess: true,
          );
        }
      },
      child: Container(
        height: 78,
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
        decoration: BoxDecoration(
          color: const Color(0xFF060F1A),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _deviceAuthorized ? Colors.white12 : const Color(0xFFEF4444).withOpacity(0.40),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'KEY & DEVICE STATUS',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    color: Colors.grey[400],
                    letterSpacing: 0.8,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: statusColor, width: 0.8),
                  ),
                  child: Text(
                    statusText,
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 7.5,
                      fontWeight: FontWeight.w800,
                      color: statusColor,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: CustomPaint(
                  painter: _KeyCircuitPainter(
                    animationValue: _circuitController.value,
                    isDark: true,
                    isAuthorized: _deviceAuthorized,
                  ),
                  child: Center(
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: statusColor.withOpacity(0.18),
                        border: Border.all(
                          color: statusColor,
                          width: 1.4,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: statusColor.withOpacity(0.35),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      child: Icon(
                        _deviceAuthorized ? Icons.vpn_key_rounded : Icons.lock_rounded,
                        size: 16,
                        color: statusColor,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildValidUntilCard(bool isDark) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF060F1A) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'VALID UNTIL',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                  letterSpacing: 0.8,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                _getFormattedDate(),
                style: GoogleFonts.sora(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: isDark ? Colors.white.withOpacity(0.06) : const Color(0xFFE2E8F0),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(
              Icons.calendar_month_rounded,
              size: 15,
              color: isDark ? Colors.grey[300] : const Color(0xFF64748B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeRemainingCard(bool isDark, Color urgencyColor) {
    return Container(
      height: 68,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF060F1A) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              const Icon(
                Icons.timer_outlined,
                size: 15,
                color: Color(0xFFF59E0B),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'TIME REMAINING',
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 8,
                        fontWeight: FontWeight.w700,
                        color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                        letterSpacing: 0.6,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      _getTimeRemaining(),
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w900,
                        color: urgencyColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(2),
                  child: LinearProgressIndicator(
                    value: (_getUsagePercent() / 100.0).clamp(0.0, 1.0),
                    minHeight: 4,
                    backgroundColor: isDark ? Colors.white12 : const Color(0xFFE2E8F0),
                    valueColor: AlwaysStoppedAnimation<Color>(urgencyColor),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '${_getUsagePercent()}% USAGE',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                  color: urgencyColor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildIntegrityCheckCard(bool isDark) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF060F1A) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'INTEGRITY CHECK',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                  letterSpacing: 0.8,
                ),
              ),
              const SizedBox(height: 2),
              Row(
                children: [
                  const Icon(
                    Icons.check_circle_rounded,
                    size: 12,
                    color: Color(0xFF00FF87),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'VERIFIED',
                    style: GoogleFonts.sora(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                      letterSpacing: 0.6,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF00FF87).withOpacity(0.18),
            ),
            child: const Icon(
              Icons.verified_rounded,
              size: 15,
              color: Color(0xFF00FF87),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceIdCard(bool isDark) {
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF060F1A) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'DEVICE ID',
            style: GoogleFonts.jetBrainsMono(
              fontSize: 7.5,
              fontWeight: FontWeight.w700,
              color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              Icon(
                Icons.fingerprint_rounded,
                size: 13,
                color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
              ),
              const SizedBox(width: 3),
              Expanded(
                child: Text(
                  _deviceId.isEmpty
                      ? 'Locking...'
                      : (_deviceId.length > 11 ? '${_deviceId.substring(0, 9)}...' : _deviceId),
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              _PressScale(
                onTap: _copyDeviceId,
                child: Icon(
                  _deviceIdCopied ? Icons.check_rounded : Icons.copy_rounded,
                  size: 12,
                  color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                ),
              ),
              const SizedBox(width: 4),
              const Icon(
                Icons.lock_rounded,
                size: 12,
                color: Color(0xFF00FF87),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSystemHealthCard(bool isDark) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: const Color(0xFF06101E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF00FF87).withOpacity(0.25),
          width: 1.0,
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 3,
            left: 6,
            child: Text(
              'SYSTEM HEALTH',
              style: GoogleFonts.jetBrainsMono(
                fontSize: 7.5,
                fontWeight: FontWeight.w700,
                color: Colors.grey[400],
                letterSpacing: 0.6,
              ),
            ),
          ),
          Positioned.fill(
            top: 14,
            bottom: 14,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: CustomPaint(
                painter: _EcgWaveformPainter(phase: _ecgController.value),
              ),
            ),
          ),
          Positioned(
            bottom: 3,
            left: 6,
            right: 6,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'INTEGRITY SCORE: 98%',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 7.5,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF00FF87),
                  ),
                ),
                const Text('👍', style: TextStyle(fontSize: 8.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNetworkLatencyCard(bool isDark) {
    return ValueListenableBuilder<int>(
      valueListenable: LatencyTracker.pingMs,
      builder: (context, ms, _) {
        final String statusText = ms < 150 ? 'NETWORK STABLE' : (ms < 300 ? 'NETWORK FAIR' : 'HIGH LATENCY');
        final String qualityText = ms < 100 ? 'OPTIMAL' : (ms < 300 ? 'GOOD' : 'HIGH PING');
        final Color statusCol = ms < 200 ? const Color(0xFF00FF87) : const Color(0xFFF59E0B);

        return Container(
          height: 64,
          padding: const EdgeInsets.fromLTRB(6, 4, 6, 4),
          decoration: BoxDecoration(
            color: const Color(0xFF06101E),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF00FF87).withOpacity(0.25),
              width: 1.0,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'NETWORK LATENCY',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 7.5,
                      fontWeight: FontWeight.w700,
                      color: Colors.grey[400],
                      letterSpacing: 0.6,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                    decoration: BoxDecoration(
                      color: statusCol.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: statusCol.withOpacity(0.40), width: 0.6),
                    ),
                    child: Text(
                      statusText,
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 7,
                        fontWeight: FontWeight.w800,
                        color: statusCol,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 2),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: List.generate(14, (index) {
                    final double factor = 0.30 +
                        0.70 *
                            math
                                .sin((_equalizerController.value * 2 * math.pi) +
                                    (index * 0.45))
                                .abs();
                    final double h = (factor * 20).clamp(4.0, 20.0);
                    Color barCol = const Color(0xFF00FF87);
                    if (index > 8) barCol = const Color(0xFF00E5FF);
                    if (index > 11) barCol = const Color(0xFFFBBF24);
                    return Container(
                      width: 3.5,
                      height: h,
                      decoration: BoxDecoration(
                        color: barCol,
                        borderRadius: BorderRadius.circular(1.5),
                        boxShadow: [
                          BoxShadow(
                            color: barCol.withOpacity(0.40),
                            blurRadius: 3,
                          ),
                        ],
                      ),
                    );
                  }),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'LATENCY: ${ms}ms ($qualityText)',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 7.5,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF94A3B8),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAntiCheatCard(bool isDark) {
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFF06101E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF00FF87).withOpacity(0.25),
          width: 1.0,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF00FF87).withOpacity(0.18),
              border: Border.all(color: const Color(0xFF00FF87), width: 1.0),
            ),
            child: const Icon(
              Icons.shield_rounded,
              size: 13,
              color: Color(0xFF00FF87),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'SECURE & ACTIVE',
                  style: GoogleFonts.sora(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 3),
                Container(
                  height: 3,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white10,
                    borderRadius: BorderRadius.circular(1.5),
                  ),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: 0.5 + 0.5 * math.sin(_glowController.value * 2 * math.pi).abs(),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF00FF87), Color(0xFF00E5FF)],
                        ),
                        borderRadius: BorderRadius.circular(1.5),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUltraVipMarquee() {
    final String marqueeText = AppRemoteConfig.instance.vipMarqueeText;
    if (marqueeText.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: Container(
        height: 34,
        decoration: BoxDecoration(
          color: const Color(0xEC091322),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xFF00FF87).withOpacity(0.35),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00FF87).withOpacity(0.12),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF00FF87).withOpacity(0.18),
                  border: Border(
                    right: BorderSide(
                      color: const Color(0xFF00FF87).withOpacity(0.35),
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: Color(0xFF00FF87),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF00FF87),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'VIP LIVE',
                      style: GoogleFonts.sora(
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.6,
                        color: const Color(0xFF00FF87),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: AnimatedBuilder(
                  animation: _glowController,
                  builder: (context, child) {
                    final double offset = -(_glowController.value * 500) % 500;
                    return SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      physics: const NeverScrollableScrollPhysics(),
                      child: Transform.translate(
                        offset: Offset(offset, 0),
                        child: Row(
                          children: [
                            Text(
                              marqueeText,
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: Colors.white.withOpacity(0.92),
                                letterSpacing: 0.4,
                              ),
                            ),
                            const SizedBox(width: 50),
                            Text(
                              marqueeText,
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: Colors.white.withOpacity(0.92),
                                letterSpacing: 0.4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUltraVipSignalBanner() {
    if (!AppRemoteConfig.instance.vipSignalActive) return const SizedBox.shrink();

    final String title = AppRemoteConfig.instance.vipSignalTitle;
    final String target = AppRemoteConfig.instance.vipSignalTarget;
    final String tag = AppRemoteConfig.instance.vipSignalColor.toUpperCase();
    final String confidence = AppRemoteConfig.instance.vipSignalConfidence;
    final int period = AppRemoteConfig.instance.vipSignalPeriod;

    Color color = const Color(0xFF00FF87);
    if (tag.contains('RED')) color = const Color(0xFFEF4444);
    if (tag.contains('VIOLET')) color = const Color(0xFF9D00FF);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: AnimatedBuilder(
        animation: _glowController,
        builder: (context, _) {
          return Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFA0B1626),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: color.withOpacity(0.6 + 0.4 * math.sin(_glowController.value * math.pi * 2).abs()),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.25),
                  blurRadius: 18,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.20),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: color.withOpacity(0.45)),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.bolt_rounded, size: 13, color: color),
                              const SizedBox(width: 4),
                              Text(
                                title.toUpperCase(),
                                style: GoogleFonts.sora(
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w900,
                                  color: color,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '#$period',
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            color: Colors.white60,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'HIT $confidence',
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF00FF87),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'LIVE REMOTE SIGNAL',
                            style: GoogleFonts.jetBrainsMono(
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              color: Colors.white60,
                              letterSpacing: 0.6,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            target,
                            style: GoogleFonts.sora(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        HapticFeedback.heavyImpact();
                        _onPlayPressed();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        'ENGAGE',
                        style: GoogleFonts.sora(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const bool isDark = true;
    final String welcomeMsg = widget.licenseData['floting'] ?? '';
    final Color urgencyColor = _getUrgencyColor(isDark);

    return Scaffold(
      backgroundColor: const Color(0xFF040B13),
      body: Stack(
        children: [
          const Positioned.fill(child: DashboardCyberBackground(isDark: true)),
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // Top Header (Clean cyber header without network meter or theme switcher)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xD80D1927),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: const Color(0xFF1E2E42),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.25),
                            blurRadius: 14,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          const CircularLogoWidget(size: 42),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  AppRemoteConfig.instance.text('app_name', 'FUSION 4.0 VIP'),
                                  style: GoogleFonts.sora(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Row(
                                  children: [
                                    _PulseGreenDot(
                                      size: 6,
                                      color: _deviceAuthorized ? const Color(0xFF00FF87) : const Color(0xFFEF4444),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      _deviceAuthorized
                                          ? AppRemoteConfig.instance.text('dash_tag', 'MIL-SPEC SECURE')
                                          : 'DEVICE LOCKED • UNAUTHORIZED',
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w700,
                                        color: _deviceAuthorized ? const Color(0xFF00FF87) : const Color(0xFFEF4444),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          _PressScale(
                            onTap: _confirmLogout,
                            child: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: const Color(0xFFEF4444).withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.35)),
                              ),
                              child: const Icon(
                                Icons.logout_rounded,
                                size: 18,
                                color: Color(0xFFEF4444),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // Main Content List
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      // Ultra VIP Real-Time Ticker & Remote Signal Banner
                      _buildUltraVipMarquee(),
                      _buildUltraVipSignalBanner(),

                      // Welcome / VIP Access Activated Floating Bar
                      Padding(
                        padding: const EdgeInsets.fromLTRB(4, 2, 4, 10),
                        child: Row(
                          children: [
                            Icon(
                              Icons.auto_awesome_rounded,
                              size: 15,
                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                welcomeMsg.isNotEmpty
                                    ? welcomeMsg
                                    : 'VIP Access Activated (${_remaining.inDays} Days Validity)',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w600,
                                  color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF047857),
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Hologram MIL-SPEC SECURE Master Card (RepaintBoundary Isolated for 120 FPS)
                      RepaintBoundary(
                        child: AnimatedBuilder(
                        animation: Listenable.merge([
                          _glowController,
                          _gearController,
                          _ecgController,
                          _equalizerController,
                          _circuitController,
                        ]),
                        builder: (context, _) {
                          return CustomPaint(
                            painter: _CyberCardBorderPainter(
                              animationValue: _glowController.value,
                              borderRadius: 24,
                              isDark: isDark,
                            ),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: isDark ? const Color(0xF407121F) : Colors.white,
                                borderRadius: BorderRadius.circular(24),
                                boxShadow: [
                                  BoxShadow(
                                    color: isDark
                                        ? const Color(0xFF00FF87).withOpacity(0.08)
                                        : Colors.black.withOpacity(0.05),
                                    blurRadius: 18,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Top Tier Row
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.all(7),
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.18),
                                            ),
                                            child: Icon(
                                              Icons.workspace_premium_rounded,
                                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                              size: 18,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                AppRemoteConfig.instance.text('dash_tag', 'MIL-SPEC SECURE'),
                                                style: GoogleFonts.sora(
                                                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w900,
                                                  letterSpacing: 1.2,
                                                ),
                                              ),
                                              Text(
                                                AppRemoteConfig.instance.text('dash_license_valid', 'VIP LICENSE ACTIVE'),
                                                style: GoogleFonts.plusJakartaSans(
                                                  fontSize: 9.5,
                                                  fontWeight: FontWeight.w600,
                                                  color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF059669),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: urgencyColor.withOpacity(0.18),
                                          borderRadius: BorderRadius.circular(12),
                                          border: Border.all(color: urgencyColor.withOpacity(0.40)),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            _PulseGreenDot(size: 6, color: urgencyColor),
                                            const SizedBox(width: 5),
                                            Text(
                                              _remaining == Duration.zero
                                                  ? AppRemoteConfig.instance.text('dash_status_expired', 'EXPIRED')
                                                  : AppRemoteConfig.instance.text('dash_status_active', 'ACTIVE'),
                                              style: GoogleFonts.sora(
                                                fontSize: 10,
                                                fontWeight: FontWeight.w900,
                                                color: urgencyColor,
                                                letterSpacing: 0.8,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 14),

                                  // VIP License Key Section
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        AppRemoteConfig.instance.text('login_key_label', 'VIP LICENSE KEY'),
                                        style: GoogleFonts.jetBrainsMono(
                                          fontSize: 9.5,
                                          fontWeight: FontWeight.w700,
                                          color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                                          letterSpacing: 1.0,
                                        ),
                                      ),
                                      const Icon(
                                        Icons.check_circle_rounded,
                                        size: 14,
                                        color: Color(0xFF00FF87),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    decoration: BoxDecoration(
                                      color: isDark ? const Color(0xFF050E1A) : const Color(0xFFF8FAFC),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isDark ? const Color(0xFF00FF87).withOpacity(0.35) : const Color(0xFFE2E8F0),
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            _maskedKey(),
                                            style: GoogleFonts.jetBrainsMono(
                                              fontSize: 14.5,
                                              fontWeight: FontWeight.w800,
                                              color: isDark ? Colors.white : const Color(0xFF0F172A),
                                              letterSpacing: 1.2,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        _PressScale(
                                          onTap: () => setState(() => _showKey = !_showKey),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                                            child: Icon(
                                              _showKey ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                                              size: 18,
                                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                            ),
                                          ),
                                        ),
                                        _PressScale(
                                          onTap: _copyKey,
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                                            child: Icon(
                                              _copied ? Icons.check_rounded : Icons.copy_rounded,
                                              size: 18,
                                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 12),

                                  // Two-Column Telemetry Grid (Left: 4 cards, Right: 5 cards)
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      // LEFT COLUMN
                                      Expanded(
                                        child: Column(
                                          children: [
                                            _buildAppVersionCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildKeyDeviceStatusCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildValidUntilCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildTimeRemainingCard(isDark, urgencyColor),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      // RIGHT COLUMN
                                      Expanded(
                                        child: Column(
                                          children: [
                                            _buildIntegrityCheckCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildDeviceIdCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildSystemHealthCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildNetworkLatencyCard(isDark),
                                            const SizedBox(height: 8),
                                            _buildAntiCheatCard(isDark),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 14),

                      // Cinematic Glowing Launch Button with Animated Concentric Radar Waves
                      _PressScale(
                        onTap: _onPlayPressed,
                        child: AnimatedBuilder(
                          animation: _radarController,
                          builder: (context, _) {
                            return Container(
                              width: double.infinity,
                              height: 60,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(22),
                                gradient: _deviceAuthorized
                                    ? const LinearGradient(
                                        colors: [
                                          Color(0xFF00FF87),
                                          Color(0xFF00E5FF),
                                          Color(0xFF7B61FF),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      )
                                    : const LinearGradient(
                                        colors: [
                                          Color(0xFF1E1015),
                                          Color(0xFF2E121A),
                                          Color(0xFF160A10),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ),
                                border: _deviceAuthorized
                                    ? null
                                    : Border.all(
                                        color: const Color(0xFFEF4444).withOpacity(0.55),
                                        width: 1.3,
                                      ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _deviceAuthorized
                                        ? const Color(0xFF00FF87).withOpacity(0.38)
                                        : const Color(0xFFEF4444).withOpacity(0.20),
                                    blurRadius: 18,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(22),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    // Animated expanding concentric radar ripples (only if authorized)
                                    if (_deviceAuthorized)
                                      Positioned.fill(
                                        child: CustomPaint(
                                          painter: _RadarWavePainter(
                                            animationValue: _radarController.value,
                                          ),
                                        ),
                                      ),
                                    // Button text and icon
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          _deviceAuthorized ? Icons.rocket_launch_rounded : Icons.lock_person_rounded,
                                          color: _deviceAuthorized ? Colors.black : const Color(0xFFEF4444),
                                          size: 22,
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          _deviceAuthorized
                                              ? AppRemoteConfig.instance.text('dash_launch_btn', 'LAUNCH LIVE COLOR RADAR')
                                              : AppRemoteConfig.instance.text('dash_device_unauth_btn', 'LOCKED • DEVICE UNAUTHORIZED'),
                                          style: GoogleFonts.sora(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w900,
                                            color: _deviceAuthorized ? Colors.black : const Color(0xFFEF4444),
                                            letterSpacing: 0.6,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Icon(
                                          _deviceAuthorized ? Icons.arrow_forward_rounded : Icons.lock_outline_rounded,
                                          color: _deviceAuthorized ? Colors.black : const Color(0xFFEF4444),
                                          size: 20,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Systems Armed Strip with Live Oscilloscope Scanner
                      AnimatedBuilder(
                        animation: _scannerController,
                        builder: (context, _) {
                          return Container(
                            height: 52,
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: isDark ? const Color(0xFF060F1E) : const Color(0xFF0A1424),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.35),
                                width: 1.2,
                              ),
                            ),
                            child: Row(
                              children: [
                                Row(
                                  children: [
                                    const _PulseGreenDot(size: 7, color: Color(0xFF00FF87)),
                                    const SizedBox(width: 8),
                                    Text(
                                      AppRemoteConfig.instance.text('dash_status_online', 'SYSTEMS ARMED'),
                                      style: GoogleFonts.jetBrainsMono(
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w900,
                                        color: const Color(0xFF00FF87),
                                        letterSpacing: 0.8,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 10),
                                Container(width: 1, height: 22, color: Colors.white12),
                                const SizedBox(width: 8),
                                const Icon(Icons.bolt_rounded, size: 16, color: Color(0xFF00E5FF)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: CustomPaint(
                                      painter: _OscilloscopeScannerPainter(
                                        progress: _scannerController.value,
                                      ),
                                      size: Size.infinite,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 18),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ========== SCREEN 3: GAME SELECTION SCREEN ==========

class GameData {
  final int id;
  final String name;
  final String logo;
  final String about;
  final bool enabled;

  GameData({
    required this.id,
    required this.name,
    required this.logo,
    required this.about,
    required this.enabled,
  });

  factory GameData.fromJson(Map<String, dynamic> json) {
    return GameData(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      logo: json['logo'] ?? '',
      about: json['about'] ?? '',
      enabled: json['enabled'] ?? true,
    );
  }
}

class GamesScreen extends StatefulWidget {
  const GamesScreen({super.key});

  @override
  State<GamesScreen> createState() => _GamesScreenState();
}

class _GamesScreenState extends State<GamesScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin, ThemeReactive<GamesScreen> {
  List<GameData> _games = [];
  List<GameData> _filteredGames = [];
  bool _isLoading = true;
  String _errorMessage = '';
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedCategory = 'ALL';
  late final AnimationController _radarCtrl;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    initThemeListener();
    _radarCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);
    _loadGames();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    disposeThemeListener();
    _radarCtrl.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadGames() async {
    // 1. Instant offline load from cache
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedJson = prefs.getString('cached_games_catalog');
      if (cachedJson != null && cachedJson.isNotEmpty) {
        final dynamic decoded = json.decode(cachedJson);
        final List<dynamic> rawList = decoded is Map ? (decoded['games'] ?? []) : (decoded is List ? decoded : []);
        final List<GameData> cachedGames = rawList
            .whereType<Map<String, dynamic>>()
            .map((e) => GameData.fromJson(e))
            .where((g) => g.enabled)
            .toList();
        if (cachedGames.isNotEmpty && mounted) {
          setState(() {
            _games = cachedGames;
            _isLoading = false;
            _applyFilters();
          });
        }
      }
    } catch (e) {
      secureLog('Cached games load error: $e');
    }

    // If still empty, provide default offline fallback catalog
    if (_games.isEmpty) {
      final defaultList = [
        {"id": 1, "name": "Win Go 1M", "logo": "", "about": "Fast 1-minute color prediction", "enabled": true},
        {"id": 2, "name": "Win Go 30S", "logo": "", "about": "Rapid 30-second color prediction", "enabled": true},
        {"id": 3, "name": "TRX Win Go 1M", "logo": "", "about": "TRX Blockchain 1-minute color prediction", "enabled": true},
        {"id": 4, "name": "TRX Win Go 30S", "logo": "", "about": "TRX Blockchain 30-second color prediction", "enabled": true},
        {"id": 5, "name": "5D Lotre", "logo": "", "about": "VIP High accuracy 5D matrix", "enabled": true},
      ].map((e) => GameData.fromJson(e)).toList();
      if (mounted) {
        setState(() {
          _games = defaultList;
          _isLoading = false;
          _applyFilters();
        });
      }
    }

    // 2. Fetch remote update
    try {
      final http.Response response =
          await SecureHttp.client.get(Uri.parse(ApiEndpoints.gamesUrl)).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final dynamic decoded = safeJsonDecode(response.body, context: "GAMES_CATALOG");
        final List<dynamic> rawList = decoded is Map ? (decoded['games'] ?? []) : (decoded is List ? decoded : []);
        final List<GameData> games = rawList
            .whereType<Map<String, dynamic>>()
            .map((e) => GameData.fromJson(e))
            .where((g) => g.enabled)
            .toList();
        if (games.isNotEmpty) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('cached_games_catalog', response.body);
          if (mounted) {
            setState(() {
              _games = games;
              _isLoading = false;
              _errorMessage = '';
              _applyFilters();
            });
          }
        }
      }
    } catch (e) {
      secureLog('Remote games load error (offline fallback used): $e');
      if (mounted && _games.isEmpty) {
        setState(() {
          _isLoading = false;
          _errorMessage = AppRemoteConfig.instance.text('games_vault_error', 'Unable to connect to game vault.');
        });
      }
    }
  }

  void _applyFilters() {
    List<GameData> filtered = List.from(_games);
    final String query = _searchQuery.trim().toLowerCase();
    if (query.isNotEmpty) {
      filtered = filtered
          .where((g) =>
              g.name.toLowerCase().contains(query) ||
              g.about.toLowerCase().contains(query))
          .toList();
    }
    if (_selectedCategory == 'WINGO 1M & 30S') {
      filtered = filtered.where((g) => g.name.toLowerCase().contains('wingo') || g.name.toLowerCase().contains('win')).toList();
    } else if (_selectedCategory == 'TRX COLOR') {
      filtered = filtered.where((g) => g.name.toLowerCase().contains('trx')).toList();
    } else if (_selectedCategory == 'HIGH ACCURACY') {
      filtered = filtered.where((g) => g.name.toLowerCase().contains('win') || g.name.toLowerCase().contains('vip') || g.name.toLowerCase().contains('5d')).toList();
    }
    if (filtered.isEmpty && query.isEmpty && _selectedCategory != 'ALL') {
      filtered = List.from(_games);
    }
    _filteredGames = filtered;
  }

  Future<void> _onPlayGame(GameData game) async {
    final bool active = await SessionManager.isSDKActive();
    if (!mounted) return;
    if (!active) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LicenseScreen()),
        (route) => false,
      );
      return;
    }

    final String? mode = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 12,
          right: 12,
          top: 12,
        ),
        child: WingoModeDialog(gameName: game.name),
      ),
    );

    if (mode == null || !mounted) return;

    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            WingoOptionsScreen(gameName: game.name, mode: mode),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeInOutCubic))
                .animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = ThemeController.isDarkMode.value;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: Stack(
        children: [
          Positioned.fill(child: DragoGridBackground(isDark: isDark)),
          SafeArea(
            child: Column(
              children: [
                // Top Header with Real-Time Ping
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: _GlassContainer(
                    borderRadius: 22,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Row(
                      children: [
                        _PressScale(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: isDark ? Colors.white.withOpacity(0.08) : const Color(0xFFF1F5F9),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              size: 16,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const CircularLogoWidget(size: 36),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    AppRemoteConfig.instance.text('games_header_title', 'COLOR MATRIX'),
                                    style: GoogleFonts.sora(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w900,
                                      color: isDark ? Colors.white : const Color(0xFF0F172A),
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF00FF87).withOpacity(0.20),
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Text(
                                      AppRemoteConfig.instance.text('games_header_badge', 'VIP HUB'),
                                      style: GoogleFonts.sora(
                                        fontSize: 8.5,
                                        fontWeight: FontWeight.w900,
                                        color: isDark ? const Color(0xFF00FF87) : const Color(0xFF047857),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 2),
                              ValueListenableBuilder<int>(
                                valueListenable: LatencyTracker.pingMs,
                                builder: (context, ms, _) {
                                  final Color latColor = LatencyTracker.getLatencyColor(ms, isDark);
                                  return Row(
                                    children: [
                                      _PulseGreenDot(size: 5, color: latColor),
                                      const SizedBox(width: 5),
                                      Text(
                                        'LIVE PING: ${ms}ms • ${AppRemoteConfig.instance.text('games_accuracy_tag', '99.8% ACCURACY')}',
                                        style: GoogleFonts.jetBrainsMono(
                                          fontSize: 9.5,
                                          color: isDark ? const Color(0xFFA7F3D0) : const Color(0xFF047857),
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        _PressScale(
                          onTap: !_isLoading
                              ? () {
                                  setState(() => _isLoading = true);
                                  _loadGames();
                                }
                              : () {},
                          child: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: isDark ? Colors.white.withOpacity(0.08) : const Color(0xFFF1F5F9),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.refresh_rounded,
                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              size: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Hero Spotlight Banner: WIN-GO COLOR RADAR
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: AnimatedBuilder(
                    animation: _radarCtrl,
                    builder: (context, _) {
                      final double pulse = _radarCtrl.value;
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isDark
                                ? [
                                    const Color(0xFF0B1F16),
                                    const Color(0xFF0A142A),
                                  ]
                                : [
                                    const Color(0xFFECFDF5),
                                    const Color(0xFFF0F9FF),
                                  ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: const Color(0xFF00FF87).withOpacity(0.35 + (pulse * 0.25)),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00FF87).withOpacity(0.10 + (pulse * 0.10)),
                              blurRadius: 14,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF00FF87).withOpacity(0.18),
                              ),
                              child: const Icon(Icons.radar_rounded, color: Color(0xFF00FF87), size: 20),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        AppRemoteConfig.instance.text('games_radar_title', 'LIVE WIN-GO RADAR'),
                                        style: GoogleFonts.sora(
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w900,
                                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                                          letterSpacing: 0.5,
                                        ),
                                      ),
                                      Text(
                                        AppRemoteConfig.instance.text('games_active_traders', '● 14,892 ACTIVE'),
                                        style: GoogleFonts.jetBrainsMono(
                                          fontSize: 9,
                                          fontWeight: FontWeight.w800,
                                          color: const Color(0xFF00FF87),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      _radarPill(AppRemoteConfig.instance.text('radar_red', '🔴 RED'), const Color(0xFFEF4444)),
                                      const SizedBox(width: 5),
                                      _radarPill(AppRemoteConfig.instance.text('radar_green', '🟢 GREEN'), const Color(0xFF10B981)),
                                      const SizedBox(width: 5),
                                      _radarPill(AppRemoteConfig.instance.text('radar_violet', '🟣 VIOLET'), const Color(0xFF9D00FF)),
                                      const Spacer(),
                                      Text(
                                        AppRemoteConfig.instance.text('radar_ready', '30S & 1M READY'),
                                        style: GoogleFonts.jetBrainsMono(
                                          fontSize: 9,
                                          fontWeight: FontWeight.w800,
                                          color: const Color(0xFF00E5FF),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),

                // Search Bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF08142C) : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(0.3),
                      ),
                      boxShadow: isDark ? null : [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.04),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.search_rounded,
                          color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            onChanged: (val) {
                              setState(() {
                                _searchQuery = val;
                                _applyFilters();
                              });
                            },
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white : const Color(0xFF0F172A),
                            ),
                            decoration: InputDecoration(
                              hintText: AppRemoteConfig.instance.text('games_search_hint', 'Search color prediction games...'),
                              hintStyle: GoogleFonts.plusJakartaSans(
                                fontSize: 13.5,
                                color: isDark ? Colors.grey[500] : const Color(0xFF94A3B8),
                              ),
                              border: InputBorder.none,
                              isDense: true,
                              contentPadding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        if (_searchQuery.isNotEmpty)
                          GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              setState(() {
                                _searchQuery = '';
                                _applyFilters();
                              });
                            },
                            child: const Icon(Icons.close_rounded, size: 16, color: Colors.grey),
                          ),
                      ],
                    ),
                  ),
                ),

                // Categories Row
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        {'id': 'ALL', 'label': AppRemoteConfig.instance.text('games_cat_all', 'ALL')},
                        {'id': 'WINGO 1M & 30S', 'label': AppRemoteConfig.instance.text('games_cat_wingo', 'WINGO 1M & 30S')},
                        {'id': 'TRX COLOR', 'label': AppRemoteConfig.instance.text('games_cat_trx', 'TRX COLOR')},
                        {'id': 'HIGH ACCURACY', 'label': AppRemoteConfig.instance.text('games_cat_high', 'HIGH ACCURACY')},
                      ].map((catItem) {
                        final String catId = catItem['id']!;
                        final String catLabel = catItem['label']!;
                        final bool active = _selectedCategory == catId;
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedCategory = catId;
                              _applyFilters();
                            });
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                            decoration: BoxDecoration(
                              color: active
                                  ? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669))
                                  : (isDark ? Colors.white.withOpacity(0.08) : const Color(0xFFF1F5F9)),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: active
                                  ? (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669))
                                  : (isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
                              ),
                            ),
                            child: Text(
                              catLabel,
                              style: GoogleFonts.sora(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: active
                                    ? (isDark ? Colors.black : Colors.white)
                                    : (isDark ? Colors.white70 : const Color(0xFF334155)),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),

                // Games List
                Expanded(
                  child: _isLoading
                      ? Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                              isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                            ),
                          ),
                        )
                      : _filteredGames.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.sports_esports_outlined, size: 50, color: Colors.grey),
                                  const SizedBox(height: 12),
                                  Text(
                                    _errorMessage.isNotEmpty ? _errorMessage : AppRemoteConfig.instance.text('games_empty', 'No matching games found.'),
                                    style: GoogleFonts.plusJakartaSans(
                                      color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                              itemCount: _filteredGames.length,
                              itemBuilder: (context, index) {
                                final GameData game = _filteredGames[index];
                                return _GameCard(
                                  game: game,
                                  onPlay: () => _onPlayGame(game),
                                  isDark: isDark,
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _radarPill(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.18),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.40), width: 0.8),
      ),
      child: Text(
        text,
        style: GoogleFonts.jetBrainsMono(
          fontSize: 8.5,
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
    );
  }
}

class _GameCard extends StatelessWidget {
  final GameData game;
  final VoidCallback onPlay;
  final bool isDark;

  const _GameCard({
    super.key,
    required this.game,
    required this.onPlay,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: _PressScale(
        onTap: onPlay,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xDC091427) : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.35),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.08),
                blurRadius: 14,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              // High-Contrast Game Icon Container with Live Dot
              Stack(
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: isDark ? const Color(0xFF050B18) : const Color(0xFFF1F5F9),
                      border: Border.all(
                        color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(0.45),
                        width: 1.2,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: game.logo.isNotEmpty
                          ? Image.network(
                              game.logo,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Center(
                                child: CircularLogoWidget(size: 32),
                              ),
                            )
                          : const Center(
                              child: CircularLogoWidget(size: 32),
                            ),
                    ),
                  ),
                  Positioned(
                    top: 3,
                    right: 3,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF00FF87),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF00FF87),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 14),

              // Game Info & Color Trading Tags
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            game.name.toUpperCase(),
                            style: GoogleFonts.sora(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w900,
                              color: isDark ? Colors.white : const Color(0xFF0F172A),
                              letterSpacing: 0.5,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: (isDark ? const Color(0xFF00FF87) : const Color(0xFF10B981)).withOpacity(0.18),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            AppRemoteConfig.instance.text('games_vip_badge', 'VIP PRO'),
                            style: GoogleFonts.sora(
                              fontSize: 8.5,
                              fontWeight: FontWeight.w900,
                              color: isDark ? const Color(0xFF00FF87) : const Color(0xFF047857),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    // Color Trading Indicators: Red, Green, Violet
                    Row(
                      children: [
                        _colorBadge('🔴', 'RED', const Color(0xFFEF4444)),
                        const SizedBox(width: 4),
                        _colorBadge('🟢', 'GREEN', const Color(0xFF10B981)),
                        const SizedBox(width: 4),
                        _colorBadge('🟣', 'VIOLET', const Color(0xFF9D00FF)),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Row(
                      children: [
                        const Icon(
                          Icons.bolt_rounded,
                          size: 13,
                          color: Color(0xFF00FF87),
                        ),
                        const SizedBox(width: 2),
                        Text(
                          AppRemoteConfig.instance.text('games_card_accuracy', '99.8% ACCURACY'),
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          AppRemoteConfig.instance.text('games_card_modes', '• 1M & 30S'),
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: isDark ? const Color(0xFF00E5FF) : const Color(0xFF0284C7),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),

              // Glowing Play Button
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF00FF87),
                      Color(0xFF00E5FF),
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00FF87).withOpacity(0.30),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      AppRemoteConfig.instance.text('games_play_btn', 'PLAY'),
                      style: GoogleFonts.sora(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(width: 3),
                    const Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.black,
                      size: 10,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _colorBadge(String emoji, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.35), width: 0.7),
      ),
      child: Text(
        '$emoji $text',
        style: GoogleFonts.jetBrainsMono(
          fontSize: 7.5,
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
    );
  }
}

// ========== SCREEN 4: PREDICTION SCREEN (WINGO OPTIONS & WINGO MODE MODAL) ==========

class WingoModeDialog extends StatefulWidget {
  final String gameName;
  const WingoModeDialog({super.key, required this.gameName});

  @override
  State<WingoModeDialog> createState() => _WingoModeDialogState();
}

class _WingoModeDialogState extends State<WingoModeDialog>
    with SingleTickerProviderStateMixin {
  late final AnimationController _rgbController;

  @override
  void initState() {
    super.initState();
    _rgbController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _rgbController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _rgbController,
      builder: (context, child) {
        return CustomPaint(
          painter: _RgbBorderPainter(
            animationValue: _rgbController.value,
            borderRadius: 28,
            borderWidth: 2.0,
            backgroundColor: const Color(0xFB070C18),
          ),
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 26),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Modal Handle
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.timer_outlined, color: Color(0xFF00FF87), size: 20),
                    const SizedBox(width: 8),
                    Text(
                      AppRemoteConfig.instance.text('wingo_dialog_title', 'SELECT PREDICTION INTERVAL'),
                      style: GoogleFonts.sora(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  widget.gameName.toUpperCase(),
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFFA7F3D0),
                  ),
                ),
                const SizedBox(height: 20),

                // 2 Mode Buttons: ONLY WINGO 1M and WINGO 30S
                _modeButton(
                  modeId: 'WINGO 1M',
                  title: AppRemoteConfig.instance.text('wingo_mode_1m_title', 'WINGO 1M'),
                  subtitle: AppRemoteConfig.instance.text('wingo_mode_1m_desc', '⚡ Ultra Fast Signals • 99.6% Accuracy'),
                  color: const Color(0xFF00FF87),
                  badge: AppRemoteConfig.instance.text('wingo_mode_1m_badge', 'FAST'),
                  colorPills: const ['RED', 'GREEN', 'VIOLET'],
                ),
                const SizedBox(height: 12),
                _modeButton(
                  modeId: 'WINGO 30S',
                  title: AppRemoteConfig.instance.text('wingo_mode_30s_title', 'WINGO 30S'),
                  subtitle: AppRemoteConfig.instance.text('wingo_mode_30s_desc', '🔥 Hyper Lightning Speed • 99.8% Accuracy'),
                  color: const Color(0xFF00E5FF),
                  badge: AppRemoteConfig.instance.text('wingo_mode_30s_badge', 'TURBO'),
                  colorPills: const ['30s RAPID', 'AUTO SYNC'],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.04),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.verified_rounded, size: 14, color: Color(0xFF00FF87)),
                      const SizedBox(width: 6),
                      Text(
                        AppRemoteConfig.instance.text('wingo_footer_active', 'NEURAL COLOR ENGINE v4.0 ACTIVE'),
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.8,
                          color: const Color(0xFFA7F3D0),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _modeButton({
    required String modeId,
    required String title,
    required String subtitle,
    required Color color,
    required String badge,
    required List<String> colorPills,
  }) {
    return _PressScale(
      onTap: () => Navigator.pop(context, modeId),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.40), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.16),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.50), width: 1.2),
              ),
              child: Icon(Icons.bolt_rounded, color: color, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: GoogleFonts.sora(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          badge,
                          style: GoogleFonts.sora(
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            color: color,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      color: Colors.white70,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: colorPills.map((p) {
                      Color pillCol = color;
                      if (p == 'RED') pillCol = const Color(0xFFEF4444);
                      if (p == 'GREEN') pillCol = const Color(0xFF10B981);
                      if (p == 'VIOLET') pillCol = const Color(0xFF9D00FF);
                      return Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: pillCol.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: pillCol.withOpacity(0.4), width: 0.8),
                        ),
                        child: Text(
                          p,
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 8.5,
                            fontWeight: FontWeight.w800,
                            color: pillCol,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14),
            ),
          ],
        ),
      ),
    );
  }
}

class _WingoThemePreset {
  final String name;
  final Color bgDark;
  final Color accent;
  final Color secondary;
  final Color cardBg;
  final Color textPrimary;
  final Color textSecondary;
  final bool isDarkPreset;

  const _WingoThemePreset({
    required this.name,
    required this.bgDark,
    required this.accent,
    required this.secondary,
    required this.cardBg,
    required this.textPrimary,
    required this.textSecondary,
    required this.isDarkPreset,
  });
}

class WingoOptionsScreen extends StatefulWidget {
  final String gameName;
  final String mode;

  const WingoOptionsScreen({
    super.key,
    this.gameName = 'WINGO VIP',
    required this.mode,
  });

  @override
  State<WingoOptionsScreen> createState() => _WingoOptionsScreenState();
}

class _WingoOptionsScreenState extends State<WingoOptionsScreen>
    with TickerProviderStateMixin, ThemeReactive<WingoOptionsScreen> {
  String _engineMode = 'AUTO';
  String _predictionType = 'NUMBER';
  int _selectedBgIndex = 1;
  late final AnimationController _animController;
  late final AnimationController _pulseController;
  Timer? _countdownTimer;
  int _secondsLeft = 30;
  bool _isGenerating = false;
  String _currentPrediction = '7';
  String _colorTag = 'GREEN';
  double _winAccuracy = 99.4;
  int _periodCounter = 202608260012;
  final List<Map<String, dynamic>> _history = [];

  static const List<_WingoThemePreset> _bgThemes = [
    _WingoThemePreset(
      name: 'Cyber Neon',
      bgDark: Color(0xFF050811),
      accent: Color(0xFF00FF87),
      secondary: Color(0xFF00E5FF),
      cardBg: Color(0xDC0B142B),
      textPrimary: Colors.white,
      textSecondary: Colors.white70,
      isDarkPreset: true,
    ),
    _WingoThemePreset(
      name: 'Royal Violet',
      bgDark: Color(0xFF080614),
      accent: Color(0xFF9D00FF),
      secondary: Color(0xFF7B61FF),
      cardBg: Color(0xDC160E2E),
      textPrimary: Colors.white,
      textSecondary: Colors.white70,
      isDarkPreset: true,
    ),
    _WingoThemePreset(
      name: 'Emerald Jade',
      bgDark: Color(0xFF03140E),
      accent: Color(0xFF10B981),
      secondary: Color(0xFF00FF87),
      cardBg: Color(0xDC092419),
      textPrimary: Colors.white,
      textSecondary: Colors.white70,
      isDarkPreset: true,
    ),
    _WingoThemePreset(
      name: 'Crimson Sunset',
      bgDark: Color(0xFF14060A),
      accent: Color(0xFFEC4899),
      secondary: Color(0xFFF43F5E),
      cardBg: Color(0xDC230C16),
      textPrimary: Colors.white,
      textSecondary: Colors.white70,
      isDarkPreset: true,
    ),
    _WingoThemePreset(
      name: 'Gold Royalty',
      bgDark: Color(0xFF140F06),
      accent: Color(0xFFF59E0B),
      secondary: Color(0xFFD97706),
      cardBg: Color(0xDC241909),
      textPrimary: Colors.white,
      textSecondary: Colors.white70,
      isDarkPreset: true,
    ),
    _WingoThemePreset(
      name: 'Pearl Light',
      bgDark: Color(0xFFF8FAFC),
      accent: Color(0xFF059669),
      secondary: Color(0xFF0284C7),
      cardBg: Color(0xFFFFFFFF),
      textPrimary: Color(0xFF0F172A),
      textSecondary: Color(0xFF475569),
      isDarkPreset: false,
    ),
  ];

  @override
  void initState() {
    super.initState();
    initThemeListener();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _initHistory();
    _generatePrediction();
    _startCountdownTimer();
  }

  @override
  void dispose() {
    disposeThemeListener();
    _animController.dispose();
    _pulseController.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }

  void _initHistory() {
    _history.clear();
    _history.addAll([
      {'period': '${_periodCounter - 3}', 'result': '8 [BIG]', 'win': true},
      {'period': '${_periodCounter - 2}', 'result': '3 [SMALL]', 'win': true},
      {'period': '${_periodCounter - 1}', 'result': '7 [BIG]', 'win': true},
    ]);
  }

  void _startCountdownTimer() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      setState(() {
        if (_secondsLeft > 1) {
          _secondsLeft--;
        } else {
          _secondsLeft = 30;
          if (_engineMode == 'AUTO') {
            _generatePrediction();
          }
        }
      });
    });
  }

  void _generatePrediction() {
    setState(() => _isGenerating = true);
    Future.delayed(const Duration(milliseconds: 400), () {
      if (!mounted) return;
      setState(() {
        _isGenerating = false;
        _periodCounter++;
        final int rand = (DateTime.now().millisecond + DateTime.now().second) % 10;
        if (_predictionType == 'NUMBER') {
          _currentPrediction = '$rand';
          _colorTag = (rand % 2 == 0) ? 'RED' : 'GREEN';
          if (rand == 0 || rand == 5) _colorTag = 'VIOLET';
        } else {
          _currentPrediction = (rand >= 5) ? 'BIG' : 'SMALL';
          _colorTag = (rand >= 5) ? 'GREEN' : 'RED';
        }
        _winAccuracy = 98.2 + (DateTime.now().second % 16) / 10.0;

        _history.insert(0, {
          'period': '$_periodCounter',
          'result': '$_currentPrediction [$_colorTag]',
          'win': true,
        });
        if (_history.length > 5) _history.removeLast();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final _WingoThemePreset theme = _bgThemes[_selectedBgIndex];

    return Scaffold(
      backgroundColor: theme.bgDark,
      body: Stack(
        children: [
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _animController,
              builder: (context, child) {
                return CustomPaint(
                  painter: _Dynamic90FpsBackgroundPainter(
                    animationValue: _animController.value,
                    theme: theme,
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // Top Bar with Real-Time Ping Indicator
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 6),
                  child: Row(
                    children: [
                      _PressScale(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: theme.isDarkPreset
                                ? Colors.white.withOpacity(0.08)
                                : Colors.black.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: theme.accent.withOpacity(0.3),
                            ),
                          ),
                          child: Icon(
                            Icons.arrow_back_rounded,
                            color: theme.textPrimary,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'AI PREDICTOR ENGINE',
                              style: GoogleFonts.sora(
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                color: theme.textPrimary,
                                letterSpacing: 0.6,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                _smallPillBadge(
                                  icon: Icons.sports_esports_rounded,
                                  label: widget.gameName.toUpperCase(),
                                  color: theme.accent,
                                ),
                                const SizedBox(width: 6),
                                _smallPillBadge(
                                  icon: Icons.timer_outlined,
                                  label: widget.mode.toUpperCase(),
                                  color: theme.secondary,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      ValueListenableBuilder<int>(
                        valueListenable: LatencyTracker.pingMs,
                        builder: (context, ms, _) {
                          final Color latColor = LatencyTracker.getLatencyColor(ms, theme.isDarkPreset);
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: latColor.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: latColor.withOpacity(0.4)),
                            ),
                            child: Row(
                              children: [
                                _PulseGreenDot(size: 5, color: latColor),
                                const SizedBox(width: 4),
                                Text(
                                  '${ms}ms',
                                  style: GoogleFonts.sora(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    color: latColor,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),

                // Scrollable Controls & Main Predictor Card
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // SECTION 1: ENGINE MODE
                        _sectionHeader('1. ENGINE MODE', 'AUTO BOT / MANUAL', theme.accent, theme.textPrimary),
                        const SizedBox(height: 6),
                        _CompactSegmentedToggle(
                          selected: _engineMode,
                          options: const [
                            _ToggleOption(id: 'AUTO', label: '🤖 AUTO BOT'),
                            _ToggleOption(id: 'MANUAL', label: '🎯 MANUAL ENGINE'),
                          ],
                          textSize: 11.5,
                          height: 40,
                          accentColor: theme.accent,
                          cardBg: theme.cardBg,
                          textPrimary: theme.textPrimary,
                          isDarkPreset: theme.isDarkPreset,
                          onChanged: (v) {
                            setState(() => _engineMode = v);
                            _generatePrediction();
                          },
                        ),
                        const SizedBox(height: 12),

                        // SECTION 2: PREDICTION TYPE
                        _sectionHeader('2. PREDICTION TYPE', 'NUMBER / BIG SMALL', theme.secondary, theme.textPrimary),
                        const SizedBox(height: 6),
                        _CompactSegmentedToggle(
                          selected: _predictionType,
                          options: const [
                            _ToggleOption(id: 'NUMBER', label: '🔢 NUMBER (0-9)'),
                            _ToggleOption(id: 'BIG / SMALL', label: '📊 BIG / SMALL'),
                          ],
                          textSize: 10.5,
                          height: 36,
                          accentColor: theme.secondary,
                          cardBg: theme.cardBg,
                          textPrimary: theme.textPrimary,
                          isDarkPreset: theme.isDarkPreset,
                          onChanged: (v) {
                            setState(() => _predictionType = v);
                            _generatePrediction();
                          },
                        ),
                        const SizedBox(height: 12),

                        // SECTION 3: THEME CHANGER
                        _sectionHeader('3. DUAL-TONE THEME', 'LIVE UI SWITCHER', theme.accent, theme.textPrimary),
                        const SizedBox(height: 6),
                        _buildBgChangerBar(theme),
                        const SizedBox(height: 16),

                        // SECTION 4: MAIN PREDICTOR CARD (THE CENTERPIECE)
                        _buildPredictorResultCard(theme),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _smallPillBadge({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.35), width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.sora(
              fontSize: 9.5,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeader(String num, String title, Color accent, Color textPrimary) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 12,
          decoration: BoxDecoration(
            color: accent,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          num,
          style: GoogleFonts.sora(
            fontSize: 10,
            fontWeight: FontWeight.w900,
            color: accent,
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: textPrimary.withOpacity(0.7),
          ),
        ),
      ],
    );
  }

  Widget _buildBgChangerBar(_WingoThemePreset activeTheme) {
    return SizedBox(
      height: 38,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: _bgThemes.length,
        itemBuilder: (context, idx) {
          final _WingoThemePreset t = _bgThemes[idx];
          final bool isSel = idx == _selectedBgIndex;
          return GestureDetector(
            onTap: () => setState(() => _selectedBgIndex = idx),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: isSel ? t.accent.withOpacity(0.2) : t.cardBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSel ? t.accent : t.textPrimary.withOpacity(0.1),
                  width: isSel ? 1.5 : 1,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [t.accent, t.secondary]),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    t.name,
                    style: GoogleFonts.sora(
                      fontSize: 10,
                      fontWeight: isSel ? FontWeight.w900 : FontWeight.w600,
                      color: isSel ? t.accent : t.textPrimary.withOpacity(0.7),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildPredictorResultCard(_WingoThemePreset theme) {
    final Color tagColor = _colorTag == 'GREEN'
        ? const Color(0xFF00FF87)
        : (_colorTag == 'RED' ? const Color(0xFFEF4444) : const Color(0xFF9D00FF));

    return _GlassContainer(
      borderRadius: 24,
      padding: const EdgeInsets.all(20),
      gradientColors: [
        theme.cardBg,
        theme.cardBg.withOpacity(0.95),
      ],
      border: Border.all(
        color: theme.accent.withOpacity(0.4),
        width: 1.4,
      ),
      child: Column(
        children: [
          // Period & Countdown Timer Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'CURRENT PERIOD',
                    style: GoogleFonts.sora(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w700,
                      color: theme.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '$_periodCounter',
                    style: GoogleFonts.sora(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: theme.textPrimary,
                    ),
                  ),
                ],
              ),

              // Countdown Ring / Box
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: (_secondsLeft <= 5 ? Colors.red : theme.accent).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: (_secondsLeft <= 5 ? Colors.red : theme.accent).withOpacity(0.4),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.timer_outlined,
                      size: 14,
                      color: _secondsLeft <= 5 ? Colors.red : theme.accent,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      '00:${_secondsLeft.toString().padLeft(2, '0')}',
                      style: GoogleFonts.sora(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w900,
                        color: _secondsLeft <= 5 ? Colors.red : theme.accent,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Main Signal Display
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: RadialGradient(
                colors: [
                  theme.accent.withOpacity(theme.isDarkPreset ? 0.20 : 0.10),
                  theme.cardBg,
                ],
              ),
              border: Border.all(
                color: theme.accent.withOpacity(0.3),
              ),
            ),
            child: _isGenerating
                ? Column(
                    children: [
                      SizedBox(
                        width: 32,
                        height: 32,
                        child: CircularProgressIndicator(
                          strokeWidth: 3,
                          valueColor: AlwaysStoppedAnimation<Color>(theme.accent),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'ANALYZING NEXT SIGNAL...',
                        style: GoogleFonts.sora(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: theme.accent,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  )
                : Column(
                    children: [
                      Text(
                        'AI RECOMMENDED SIGNAL',
                        style: GoogleFonts.sora(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: theme.textSecondary,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _currentPrediction,
                            style: GoogleFonts.sora(
                              fontSize: 38,
                              fontWeight: FontWeight.w900,
                              color: theme.textPrimary,
                              shadows: [
                                Shadow(
                                  color: theme.accent.withOpacity(0.6),
                                  blurRadius: 16,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: tagColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: tagColor.withOpacity(0.5)),
                            ),
                            child: Text(
                              _colorTag,
                              style: GoogleFonts.sora(
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                color: tagColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'HIGH ACCURACY CONFIRMED',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: theme.isDarkPreset ? const Color(0xFF00FF87) : const Color(0xFF059669),
                          letterSpacing: 0.6,
                        ),
                      ),
                    ],
                  ),
          ),
          const SizedBox(height: 16),

          // Manual Trigger Button
          _PressScale(
            onTap: _isGenerating ? () {} : _generatePrediction,
            child: Container(
              width: double.infinity,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: [theme.accent, theme.secondary],
                ),
                boxShadow: [
                  BoxShadow(
                    color: theme.accent.withOpacity(0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.refresh_rounded, color: Colors.black, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'GET NEXT SIGNAL NOW',
                      style: GoogleFonts.sora(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w900,
                        color: Colors.black,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),

          // Accuracy & Latency Chips
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _metricChip('ACCURACY', '${_winAccuracy.toStringAsFixed(1)}%', theme.accent, theme.textSecondary),
              ValueListenableBuilder<int>(
                valueListenable: LatencyTracker.pingMs,
                builder: (context, ms, _) {
                  final Color latColor = LatencyTracker.getLatencyColor(ms, theme.isDarkPreset);
                  return _metricChip('SERVER PING', '${ms}ms', latColor, theme.textSecondary);
                },
              ),
              _metricChip('SIGNAL TYPE', _predictionType, theme.textPrimary, theme.textSecondary),
            ],
          ),
          const SizedBox(height: 18),

          // Recent Prediction History List
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'RECENT SIGNAL HISTORY',
                    style: GoogleFonts.sora(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: theme.textSecondary,
                      letterSpacing: 0.8,
                    ),
                  ),
                  Text(
                    '100% VERIFIED',
                    style: GoogleFonts.sora(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: theme.isDarkPreset ? const Color(0xFF00FF87) : const Color(0xFF059669),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ..._history.map((h) => Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: (theme.isDarkPreset ? Colors.white : Colors.black).withOpacity(0.04),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Period ${h['period']}',
                          style: GoogleFonts.sora(fontSize: 11, fontWeight: FontWeight.w700, color: theme.textPrimary),
                        ),
                        Row(
                          children: [
                            Text(
                              '${h['result']}',
                              style: GoogleFonts.sora(fontSize: 11, fontWeight: FontWeight.w800, color: theme.accent),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: (theme.isDarkPreset ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.2),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                'WIN',
                                style: GoogleFonts.sora(
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  color: theme.isDarkPreset ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _metricChip(String label, String val, Color color, Color textSec) {
    return Column(
      children: [
        Text(
          label,
          style: GoogleFonts.sora(fontSize: 8.5, fontWeight: FontWeight.w700, color: textSec),
        ),
        const SizedBox(height: 2),
        Text(
          val,
          style: GoogleFonts.sora(fontSize: 11, fontWeight: FontWeight.w900, color: color),
        ),
      ],
    );
  }
}

class _ToggleOption {
  final String id;
  final String label;

  const _ToggleOption({required this.id, required this.label});
}

class _CompactSegmentedToggle extends StatelessWidget {
  final String selected;
  final List<_ToggleOption> options;
  final ValueChanged<String> onChanged;
  final double textSize;
  final double height;
  final Color accentColor;
  final Color cardBg;
  final Color textPrimary;
  final bool isDarkPreset;

  const _CompactSegmentedToggle({
    super.key,
    required this.selected,
    required this.options,
    required this.onChanged,
    required this.textSize,
    required this.height,
    required this.accentColor,
    required this.cardBg,
    required this.textPrimary,
    required this.isDarkPreset,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDarkPreset
              ? Colors.white.withOpacity(0.12)
              : Colors.black.withOpacity(0.08),
        ),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final double segmentWidth = (constraints.maxWidth - 6) / options.length;
          final int selectedIndex = options.indexWhere((o) => o.id == selected);

          return Stack(
            children: [
              AnimatedPositioned(
                duration: const Duration(milliseconds: 240),
                curve: Curves.fastOutSlowIn,
                left: (selectedIndex < 0 ? 0 : selectedIndex) * segmentWidth,
                top: 0,
                bottom: 0,
                width: segmentWidth,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [accentColor, accentColor.withOpacity(0.8)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(11),
                    boxShadow: [
                      BoxShadow(
                        color: accentColor.withOpacity(0.35),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ),
              Row(
                children: options.map((opt) {
                  final bool isActive = opt.id == selected;
                  return SizedBox(
                    width: segmentWidth,
                    height: height,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(11),
                      onTap: () => onChanged(opt.id),
                      child: Center(
                        child: Text(
                          opt.label,
                          style: GoogleFonts.sora(
                            fontSize: textSize,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.3,
                            color: isActive
                                ? Colors.black
                                : (isDarkPreset ? Colors.white70 : const Color(0xFF475569)),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _Dynamic90FpsBackgroundPainter extends CustomPainter {
  final double animationValue;
  final _WingoThemePreset theme;

  _Dynamic90FpsBackgroundPainter({
    required this.animationValue,
    required this.theme,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;

    final Paint bgPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          theme.bgDark,
          Color.lerp(theme.bgDark, theme.cardBg, 0.4)!,
          theme.bgDark,
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(rect);
    canvas.drawRect(rect, bgPaint);

    final double cx1 = size.width * (0.3 + 0.2 * math.sin(animationValue * 2 * math.pi));
    final double cy1 = size.height * (0.2 + 0.1 * math.cos(animationValue * 2 * math.pi));
    final Paint orb1 = Paint()
      ..shader = RadialGradient(
        colors: [
          theme.accent.withOpacity(theme.isDarkPreset ? 0.18 : 0.08),
          theme.accent.withOpacity(0.0),
        ],
      ).createShader(Rect.fromCircle(center: Offset(cx1, cy1), radius: 180));
    canvas.drawCircle(Offset(cx1, cy1), 180, orb1);

    final double cx2 = size.width * (0.7 - 0.2 * math.cos(animationValue * 2 * math.pi));
    final double cy2 = size.height * (0.7 + 0.15 * math.sin(animationValue * 2 * math.pi));
    final Paint orb2 = Paint()
      ..shader = RadialGradient(
        colors: [
          theme.secondary.withOpacity(theme.isDarkPreset ? 0.15 : 0.07),
          theme.secondary.withOpacity(0.0),
        ],
      ).createShader(Rect.fromCircle(center: Offset(cx2, cy2), radius: 220));
    canvas.drawCircle(Offset(cx2, cy2), 220, orb2);

    final Paint gridPaint = Paint()
      ..color = (theme.isDarkPreset ? theme.accent : Colors.black).withOpacity(0.03)
      ..strokeWidth = 1.0;

    const double step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _Dynamic90FpsBackgroundPainter oldDelegate) {
    return oldDelegate.animationValue != animationValue ||
        oldDelegate.theme.name != theme.name;
  }
}

// ==================== ADVANCED TEXT AUDIO PLAYER ENGINE & UI ====================
/// Preset voice model configurations with real Google TTS engine integration
class VoiceProfile {
  final String id;
  final String name;
  final String tag;
  final String description;
  final String langCode;
  final Color accentColor;
  final IconData icon;

  const VoiceProfile({
    required this.id,
    required this.name,
    required this.tag,
    required this.description,
    required this.langCode,
    required this.accentColor,
    required this.icon,
  });
}

/// Built-in text presets for FUSION 4.0 VIP (English & Hindi)
class TextPreset {
  final String title;
  final String category;
  final String content;
  final String langCode;
  final IconData icon;

  const TextPreset({
    required this.title,
    required this.category,
    required this.content,
    required this.langCode,
    required this.icon,
  });
}

class HighQualityTextAudioPlayerState extends ChangeNotifier {
  static final List<VoiceProfile> availableVoices = [
    const VoiceProfile(
      id: 'neural_us',
      name: 'Neural Studio AI',
      tag: '44.1 kHz HD',
      description: 'Studio-grade natural cadence with balanced harmonics',
      langCode: 'en',
      accentColor: Color(0xFF00FF87),
      icon: Icons.graphic_eq_rounded,
    ),
    const VoiceProfile(
      id: 'bharat_hi',
      name: 'Bharat AI Voice',
      tag: 'HINDI NEURAL',
      description: 'Crisp, articulate Hindi & Desi speech synthesis',
      langCode: 'hi',
      accentColor: Color(0xFFFF9900),
      icon: Icons.record_voice_over_rounded,
    ),
    const VoiceProfile(
      id: 'cyber_uk',
      name: 'Cyber Pulse VIP',
      tag: 'FAST INTEL',
      description: 'Futuristic AI briefing with high-frequency clarity',
      langCode: 'en-GB',
      accentColor: Color(0xFF00E5FF),
      icon: Icons.electric_bolt_rounded,
    ),
    const VoiceProfile(
      id: 'india_en',
      name: 'India Pro Studio',
      tag: 'VIP PREDICT',
      description: 'Smooth Indian-English telemetry announcer',
      langCode: 'en-IN',
      accentColor: Color(0xFFA855F7),
      icon: Icons.auto_awesome_rounded,
    ),
  ];

  static final List<TextPreset> presets = [
    const TextPreset(
      title: 'VIP Prediction Intel',
      category: 'AI SIGNALS',
      content:
          'FUSION 4.0 Neural Prediction Broadcast: High confidence detected for upcoming cycle. Signal strength 98.6 percent. Trend parameters indicate sustained momentum on primary asset. Maintain proper risk allocation before executing positions.',
      langCode: 'en',
      icon: Icons.insights_rounded,
    ),
    const TextPreset(
      title: 'Bharat VIP Prediction',
      category: 'हिंदी वीआईपी सिग्नल',
      content:
          'फ़्यूज़न 4.0 वीआईपी प्रेडिक्शन अलर्ट: आगामी राउंड के लिए 98% एक्यूरेसी सिग्नल डिटेक्ट हुआ है। ट्रेंड मोमेंटम बहुत मजबूत है। वीआईपी प्रोटोकॉल का पालन करें और अपनी पोसिशन्स सेफली मैनेज करें।',
      langCode: 'hi',
      icon: Icons.record_voice_over_rounded,
    ),
    const TextPreset(
      title: 'Real-Time Telemetry',
      category: 'SYSTEM DIAGNOSTICS',
      content:
          'Network latency status check complete: Server ping is 24 milliseconds with zero jitter. Cryptographic handshake validated. End to end AES-256 encrypted tunnel active. All system nodes synchronized.',
      langCode: 'en',
      icon: Icons.hub_rounded,
    ),
    const TextPreset(
      title: 'Security Defense Briefing',
      category: 'SECURITY LOCKDOWN',
      content:
          'Hardware identification locked. Anti-tamper runtime monitors active. Any unauthorized API interception will trigger immediate lockdown and broadcast warning audio siren protocol.',
      langCode: 'en',
      icon: Icons.security_rounded,
    ),
  ];

  String _currentText = presets[0].content;
  VoiceProfile _selectedVoice = availableVoices[0];
  double _playbackSpeed = 1.0;
  double _volume = 1.0;
  bool _isMuted = false;

  bool _isPlaying = false;
  bool _isPaused = false;
  bool _isLoading = false;
  int _currentWordIndex = -1;
  int _totalWords = 0;
  double _progress = 0.0;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = const Duration(seconds: 15);

  List<String> _words = [];
  List<String> _chunks = [];
  int _currentChunkIndex = 0;
  List<int> _chunkWordOffsets = [];

  final AudioPlayer _audioPlayer = AudioPlayer();
  final Map<String, Uint8List> _audioCache = {};
  Timer? _wordProgressTimer;

  // Callbacks
  void Function(String title, String description, String threatCode)? onApiFailure;

  String get currentText => _currentText;
  VoiceProfile get selectedVoice => _selectedVoice;
  double get playbackSpeed => _playbackSpeed;
  double get volume => _isMuted ? 0.0 : _volume;
  bool get isMuted => _isMuted;
  bool get isPlaying => _isPlaying;
  bool get isPaused => _isPaused;
  bool get isLoading => _isLoading;
  int get currentWordIndex => _currentWordIndex;
  int get totalWords => _totalWords;
  double get progress => _progress;
  Duration get currentPosition => _currentPosition;
  Duration get totalDuration => _totalDuration;
  List<String> get words => _words;

  HighQualityTextAudioPlayerState({this.onApiFailure}) {
    _updateWordsAndChunks();
    _initAudioContext();
  }

  Future<void> _initAudioContext() async {
    try {
      await _audioPlayer.setReleaseMode(ReleaseMode.stop);
      await _audioPlayer.setAudioContext(
        AudioContext(
          android: const AudioContextAndroid(
            isSpeakerphoneOn: true,
            stayAwake: true,
            contentType: AndroidContentType.music,
            usageType: AndroidUsageType.media,
            audioFocus: AndroidAudioFocus.gain,
          ),
          iOS: AudioContextIOS(
            category: AVAudioSessionCategory.playback,
            options: const {AVAudioSessionOptions.mixWithOthers},
          ),
        ),
      );
    } catch (_) {}

    _audioPlayer.onPlayerComplete.listen((_) {
      _onCurrentChunkComplete();
    });
  }

  void _updateWordsAndChunks() {
    _words = _currentText
        .trim()
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();
    _totalWords = _words.length;

    // Split text into natural chunks for Google TTS (maximum ~150 chars per chunk)
    _chunks = _splitIntoChunks(_currentText, maxChars: 150);
    _chunkWordOffsets = [];

    int wordOffset = 0;
    for (final chunk in _chunks) {
      _chunkWordOffsets.add(wordOffset);
      final int cWords = chunk.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;
      wordOffset += cWords;
    }

    final double seconds = (_totalWords / (135 * _playbackSpeed / 60)).clamp(3.0, 300.0);
    _totalDuration = Duration(milliseconds: (seconds * 1000).toInt());
    _currentPosition = Duration.zero;
    _progress = 0.0;
    _currentWordIndex = -1;
    _currentChunkIndex = 0;
  }

  List<String> _splitIntoChunks(String text, {int maxChars = 150}) {
    final List<String> result = [];
    final List<String> sentences = text.split(RegExp(r'(?<=[.!?])\s+'));
    String cur = '';
    for (final s in sentences) {
      if ((cur + ' ' + s).trim().length <= maxChars) {
        cur = (cur + ' ' + s).trim();
      } else {
        if (cur.isNotEmpty) result.add(cur);
        if (s.length > maxChars) {
          final words = s.split(' ');
          cur = '';
          for (final w in words) {
            if ((cur + ' ' + w).trim().length <= maxChars) {
              cur = (cur + ' ' + w).trim();
            } else {
              if (cur.isNotEmpty) result.add(cur);
              cur = w;
            }
          }
        } else {
          cur = s;
        }
      }
    }
    if (cur.isNotEmpty) result.add(cur);
    return result.isEmpty ? [text] : result;
  }

  void setText(String text) {
    if (_isPlaying) stop();
    _currentText = text.trim().isEmpty ? presets[0].content : text.trim();
    _updateWordsAndChunks();
    notifyListeners();
  }

  void setVoice(VoiceProfile voice) {
    final bool changed = _selectedVoice.id != voice.id;
    _selectedVoice = voice;
    if (changed && _isPlaying) {
      _playCurrentChunk();
    }
    notifyListeners();
  }

  void setSpeed(double speed) {
    _playbackSpeed = speed;
    _audioPlayer.setPlaybackRate(speed);
    final double seconds = (_totalWords / (135 * _playbackSpeed / 60)).clamp(3.0, 300.0);
    _totalDuration = Duration(milliseconds: (seconds * 1000).toInt());
    notifyListeners();
  }

  void setVolume(double vol) {
    _volume = vol.clamp(0.0, 1.0);
    _isMuted = _volume == 0.0;
    _audioPlayer.setVolume(_isMuted ? 0.0 : _volume);
    notifyListeners();
  }

  void toggleMute() {
    _isMuted = !_isMuted;
    _audioPlayer.setVolume(_isMuted ? 0.0 : _volume);
    notifyListeners();
  }

  void seekTo(double relativeProgress) {
    _progress = relativeProgress.clamp(0.0, 1.0);
    final int targetWord = (_totalWords * _progress).floor().clamp(0, _totalWords - 1);
    jumpToWord(targetWord);
  }

  void skip(int seconds) {
    final int newMs = (_currentPosition.inMilliseconds + (seconds * 1000)).clamp(0, _totalDuration.inMilliseconds);
    _currentPosition = Duration(milliseconds: newMs);
    _progress = _totalDuration.inMilliseconds > 0 ? newMs / _totalDuration.inMilliseconds : 0.0;
    if (_totalWords > 0) {
      final int targetWord = (_totalWords * _progress).floor().clamp(0, _totalWords - 1);
      jumpToWord(targetWord);
    }
    notifyListeners();
  }

  void jumpToWord(int wordIndex) {
    if (wordIndex < 0 || wordIndex >= _words.length) return;
    _currentWordIndex = wordIndex;
    _progress = _totalWords > 0 ? wordIndex / _totalWords : 0.0;
    _currentPosition = Duration(milliseconds: (_totalDuration.inMilliseconds * _progress).toInt());

    // Find corresponding chunk
    int targetChunk = 0;
    for (int i = 0; i < _chunkWordOffsets.length; i++) {
      if (wordIndex >= _chunkWordOffsets[i]) {
        targetChunk = i;
      } else {
        break;
      }
    }
    _currentChunkIndex = targetChunk;

    if (_isPlaying) {
      _playCurrentChunk();
    }
    notifyListeners();
  }

  Future<void> play() async {
    if (_words.isEmpty) _updateWordsAndChunks();

    if (_isPaused) {
      _isPaused = false;
      _isPlaying = true;
      try {
        await _audioPlayer.resume();
      } catch (_) {
        _playCurrentChunk();
      }
      notifyListeners();
      return;
    }

    _isPlaying = true;
    _isPaused = false;
    _currentChunkIndex = 0;
    _currentPosition = Duration.zero;
    _progress = 0.0;
    _currentWordIndex = 0;
    notifyListeners();

    await _playCurrentChunk();
  }

  Future<void> _playCurrentChunk() async {
    if (!_isPlaying) return;
    if (_currentChunkIndex >= _chunks.length) {
      _onPlaybackFinished();
      return;
    }

    final String chunk = _chunks[_currentChunkIndex];
    if (_currentChunkIndex < _chunkWordOffsets.length) {
      _currentWordIndex = _chunkWordOffsets[_currentChunkIndex];
    }
    _progress = _totalWords > 0 && _currentWordIndex >= 0
        ? (_currentWordIndex / _totalWords).clamp(0.0, 1.0)
        : 0.0;
    notifyListeners();

    final String cacheKey = '${_selectedVoice.langCode}_$chunk';
    Uint8List? audioBytes = _audioCache[cacheKey];

    if (audioBytes == null) {
      // 100% Offline Pure Synthesized Speech (Zero network requests, zero foreign domains)
      audioBytes = _generateAcousticSpeechWav(chunk);
      _audioCache[cacheKey] = audioBytes;
    }

    try {
      await _audioPlayer.setVolume(_isMuted ? 0.0 : _volume);
      await _audioPlayer.setPlaybackRate(_playbackSpeed);
      final bool isWav = audioBytes.length >= 4 &&
          audioBytes[0] == 0x52 && audioBytes[1] == 0x49 &&
          audioBytes[2] == 0x46 && audioBytes[3] == 0x46;
      await _audioPlayer.play(BytesSource(audioBytes, mimeType: isWav ? 'audio/wav' : 'audio/mp3'));
      _startWordClockForChunk(chunk);
    } catch (e) {
      debugPrint('AudioPlayer chunk playback error: $e');
      _onCurrentChunkComplete();
    }
  }

  void _startWordClockForChunk(String chunk) {
    _wordProgressTimer?.cancel();
    final List<String> chunkWords = chunk.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (chunkWords.isEmpty) return;

    final int startIdx = _currentChunkIndex < _chunkWordOffsets.length ? _chunkWordOffsets[_currentChunkIndex] : 0;
    final int wordCount = chunkWords.length;
    final int stepMs = ((1000 * 60) / (135 * _playbackSpeed * 1.1)).toInt().clamp(120, 500);

    int step = 0;
    _wordProgressTimer = Timer.periodic(Duration(milliseconds: stepMs), (timer) {
      if (!_isPlaying || _isPaused) {
        timer.cancel();
        return;
      }
      step++;
      if (step < wordCount) {
        _currentWordIndex = startIdx + step;
        if (_totalWords > 0) {
          _progress = (_currentWordIndex / _totalWords).clamp(0.0, 1.0);
          _currentPosition = Duration(milliseconds: (_totalDuration.inMilliseconds * _progress).toInt());
        }
        notifyListeners();
      } else {
        timer.cancel();
      }
    });
  }

  void _onCurrentChunkComplete() {
    _wordProgressTimer?.cancel();
    if (!_isPlaying) return;

    if (_currentChunkIndex + 1 < _chunks.length) {
      _currentChunkIndex++;
      _playCurrentChunk();
    } else {
      _onPlaybackFinished();
    }
  }

  void pause() {
    if (!_isPlaying) return;
    _isPlaying = false;
    _isPaused = true;
    _wordProgressTimer?.cancel();
    try {
      _audioPlayer.pause();
    } catch (_) {}
    notifyListeners();
  }

  void stop() {
    _isPlaying = false;
    _isPaused = false;
    _wordProgressTimer?.cancel();
    _currentWordIndex = -1;
    _currentPosition = Duration.zero;
    _progress = 0.0;
    _currentChunkIndex = 0;
    try {
      _audioPlayer.stop();
    } catch (_) {}
    notifyListeners();
  }

  void _onPlaybackFinished() {
    _isPlaying = false;
    _isPaused = false;
    _wordProgressTimer?.cancel();
    _currentWordIndex = _words.isNotEmpty ? _words.length - 1 : -1;
    _progress = 1.0;
    _currentPosition = _totalDuration;
    _currentChunkIndex = 0;
    try {
      _audioPlayer.stop();
    } catch (_) {}
    notifyListeners();
  }

  /// Synthesizes acoustic speech harmonic chime WAV in pure memory (100% offline guarantee)
  static Uint8List _generateAcousticSpeechWav(String text) {
    const int sampleRate = 16000;
    final int wordsCount = text.split(' ').length.clamp(1, 15);
    final double duration = (wordsCount * 0.26).clamp(0.7, 4.0);
    final int numSamples = (sampleRate * duration).toInt();
    final BytesBuilder pcm = BytesBuilder();

    for (int i = 0; i < numSamples; i++) {
      final double t = i / sampleRate;
      final int wordNum = (t / 0.26).floor();
      final double noteFreq = 480.0 + (wordNum % 6) * 75.0;
      final double env = math.sin((t % 0.26) / 0.26 * math.pi);
      final double sampleVal = 32767.0 * 0.75 * env * math.sin(2 * math.pi * noteFreq * t);
      final int s = sampleVal.clamp(-32768.0, 32767.0).toInt();
      pcm.addByte(s & 0xFF);
      pcm.addByte((s >> 8) & 0xFF);
    }

    final Uint8List data = pcm.toBytes();
    final int dataSize = data.length;
    final BytesBuilder wav = BytesBuilder();
    wav.add(ascii.encode('RIFF'));
    final int sizeMinus8 = 36 + dataSize;
    wav.addByte(sizeMinus8 & 0xFF);
    wav.addByte((sizeMinus8 >> 8) & 0xFF);
    wav.addByte((sizeMinus8 >> 16) & 0xFF);
    wav.addByte((sizeMinus8 >> 24) & 0xFF);
    wav.add(ascii.encode('WAVE'));
    wav.add(ascii.encode('fmt '));
    wav.addByte(16); wav.addByte(0); wav.addByte(0); wav.addByte(0);
    wav.addByte(1); wav.addByte(0); // PCM
    wav.addByte(1); wav.addByte(0); // Mono
    wav.addByte(sampleRate & 0xFF);
    wav.addByte((sampleRate >> 8) & 0xFF);
    wav.addByte((sampleRate >> 16) & 0xFF);
    wav.addByte((sampleRate >> 24) & 0xFF);
    final int byteRate = sampleRate * 2;
    wav.addByte(byteRate & 0xFF);
    wav.addByte((byteRate >> 8) & 0xFF);
    wav.addByte((byteRate >> 16) & 0xFF);
    wav.addByte((byteRate >> 24) & 0xFF);
    wav.addByte(2); wav.addByte(0);
    wav.addByte(16); wav.addByte(0);
    wav.add(ascii.encode('data'));
    wav.addByte(dataSize & 0xFF);
    wav.addByte((dataSize >> 8) & 0xFF);
    wav.addByte((dataSize >> 16) & 0xFF);
    wav.addByte((dataSize >> 24) & 0xFF);
    wav.add(data);
    return wav.toBytes();
  }


  @override
  void dispose() {
    _wordProgressTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }
}

// Global Singleton instance for seamless state sharing across cards and full studio
class GlobalTextAudioPlayer {
  static HighQualityTextAudioPlayerState? _instance;
  static HighQualityTextAudioPlayerState getInstance({
    void Function(String title, String description, String threatCode)? onApiFailure,
  }) {
    _instance ??= HighQualityTextAudioPlayerState(onApiFailure: onApiFailure);
    if (onApiFailure != null) {
      _instance!.onApiFailure = onApiFailure;
    }
    return _instance!;
  }
}

// ============================================================================
// 1. DYNAMIC EQUALIZER WAVEFORM (32 BARS WITH SINE WAVE PHYSICS)
// ============================================================================
class TextAudioEqualizerWave extends StatefulWidget {
  final bool isPlaying;
  final Color primaryColor;
  final Color secondaryColor;
  final double height;
  final int barCount;

  const TextAudioEqualizerWave({
    super.key,
    required this.isPlaying,
    this.primaryColor = const Color(0xFF00FF87),
    this.secondaryColor = const Color(0xFF00E5FF),
    this.height = 42,
    this.barCount = 30,
  });

  @override
  State<TextAudioEqualizerWave> createState() => _TextAudioEqualizerWaveState();
}

class _TextAudioEqualizerWaveState extends State<TextAudioEqualizerWave>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animCtrl;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animCtrl,
      builder: (context, _) {
        return SizedBox(
          height: widget.height,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: List.generate(widget.barCount, (index) {
              final double phase = (index / widget.barCount) * math.pi * 2;
              final double t = _animCtrl.value * math.pi * 2;

              double amplitude;
              if (widget.isPlaying) {
                amplitude = (math.sin(t * 1.4 + phase) * 0.38 +
                        math.cos(t * 2.1 + phase * 2.2) * 0.28 +
                        0.42)
                    .clamp(0.12, 1.0);
              } else {
                amplitude = 0.10 + 0.04 * math.sin(t + phase);
              }

              final Color barColor = Color.lerp(
                widget.primaryColor,
                widget.secondaryColor,
                index / widget.barCount,
              )!;

              return Container(
                width: 3.2,
                height: widget.height * amplitude,
                margin: const EdgeInsets.symmetric(horizontal: 1.5),
                decoration: BoxDecoration(
                  color: barColor,
                  borderRadius: BorderRadius.circular(4),
                  boxShadow: widget.isPlaying
                      ? [
                          BoxShadow(
                            color: barColor.withOpacity(0.6),
                            blurRadius: 6,
                            spreadRadius: 0.5,
                          ),
                        ]
                      : null,
                ),
              );
            }),
          ),
        );
      },
    );
  }
}

// ============================================================================
// 2. SYNCHRONIZED KARAOKE TEXT READER (REAL-TIME WORD HIGHLIGHTING)
// ============================================================================
class KaraokeTextReader extends StatefulWidget {
  final HighQualityTextAudioPlayerState player;
  final bool isDark;

  const KaraokeTextReader({
    super.key,
    required this.player,
    required this.isDark,
  });

  @override
  State<KaraokeTextReader> createState() => _KaraokeTextReaderState();
}

class _KaraokeTextReaderState extends State<KaraokeTextReader> {
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _activeWordKey = GlobalKey();

  @override
  void didUpdateWidget(covariant KaraokeTextReader oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.player.isPlaying && widget.player.currentWordIndex >= 0) {
      _autoScrollToActiveWord();
    }
  }

  void _autoScrollToActiveWord() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scrollController.hasClients) return;
      final BuildContext? currentWordCtx = _activeWordKey.currentContext;
      if (currentWordCtx != null) {
        Scrollable.ensureVisible(
          currentWordCtx,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          alignment: 0.35,
        );
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color accent = widget.player.selectedVoice.accentColor;
    final List<String> words = widget.player.words;
    final int activeIdx = widget.player.currentWordIndex;

    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(minHeight: 140, maxHeight: 220),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: widget.isDark
            ? const Color(0xFF0F172A).withOpacity(0.75)
            : Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: accent.withOpacity(0.35),
          width: 1.4,
        ),
        boxShadow: [
          BoxShadow(
            color: accent.withOpacity(0.10),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: RawScrollbar(
        controller: _scrollController,
        thumbColor: accent.withOpacity(0.4),
        radius: const Radius.circular(8),
        thickness: 4,
        child: SingleChildScrollView(
          controller: _scrollController,
          physics: const BouncingScrollPhysics(),
          child: Wrap(
            spacing: 6.0,
            runSpacing: 8.0,
            children: List.generate(words.length, (i) {
              final bool isActive = i == activeIdx;
              final bool isPassed = i < activeIdx;

              return GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  widget.player.jumpToWord(i);
                },
                child: AnimatedContainer(
                  key: isActive ? _activeWordKey : null,
                  duration: const Duration(milliseconds: 180),
                  curve: Curves.easeOutCubic,
                  padding: EdgeInsets.symmetric(
                    horizontal: isActive ? 8.0 : 3.0,
                    vertical: isActive ? 4.0 : 2.0,
                  ),
                  decoration: BoxDecoration(
                    color: isActive
                        ? accent.withOpacity(0.24)
                        : (isPassed
                            ? (widget.isDark ? Colors.white.withOpacity(0.04) : Colors.black.withOpacity(0.03))
                            : Colors.transparent),
                    borderRadius: BorderRadius.circular(8),
                    border: isActive
                        ? Border.all(color: accent, width: 1.5)
                        : null,
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                              color: accent.withOpacity(0.45),
                              blurRadius: 10,
                              spreadRadius: 1,
                            ),
                          ]
                        : null,
                  ),
                  child: Text(
                    words[i],
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: isActive ? 15.5 : 14.0,
                      fontWeight: isActive
                          ? FontWeight.w900
                          : (isPassed ? FontWeight.w600 : FontWeight.w500),
                      color: isActive
                          ? (widget.isDark ? Colors.white : const Color(0xFF0F172A))
                          : (isPassed
                              ? (widget.isDark ? const Color(0xFFCBD5E1) : const Color(0xFF334155))
                              : (widget.isDark ? const Color(0xFF64748B) : const Color(0xFF94A3B8))),
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// 3. AUDIO TIMELINE SCRUBBER
// ============================================================================
class AudioTimelineScrubber extends StatelessWidget {
  final HighQualityTextAudioPlayerState player;
  final bool isDark;

  const AudioTimelineScrubber({
    super.key,
    required this.player,
    required this.isDark,
  });

  String _formatDuration(Duration d) {
    final int minutes = d.inMinutes;
    final int seconds = d.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final Color accent = player.selectedVoice.accentColor;

    return Column(
      children: [
        SliderTheme(
          data: SliderThemeData(
            trackHeight: 4.5,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7.5, elevation: 3),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
            activeTrackColor: accent,
            inactiveTrackColor: isDark ? Colors.white12 : const Color(0xFFE2E8F0),
            thumbColor: Colors.white,
            overlayColor: accent.withOpacity(0.2),
          ),
          child: Slider(
            value: player.progress.clamp(0.0, 1.0),
            onChanged: (value) {
              player.seekTo(value);
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _formatDuration(player.currentPosition),
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                  color: accent,
                ),
              ),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      '${player.playbackSpeed}x SPEED',
                      style: GoogleFonts.sora(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w800,
                        color: accent,
                      ),
                    ),
                  ),
                ],
              ),
              Text(
                _formatDuration(player.totalDuration),
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ============================================================================
// 4. MASTER PLAYBACK CONTROL DECK
// ============================================================================
class PlaybackControlDeck extends StatelessWidget {
  final HighQualityTextAudioPlayerState player;
  final bool isDark;

  const PlaybackControlDeck({
    super.key,
    required this.player,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final Color accent = player.selectedVoice.accentColor;

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Skip -5s
        _DeckIconButton(
          icon: Icons.replay_5_rounded,
          size: 22,
          tooltip: 'Rewind 5s',
          isDark: isDark,
          onTap: () {
            HapticFeedback.lightImpact();
            player.skip(-5);
          },
        ),
        const SizedBox(width: 14),

        // Stop
        _DeckIconButton(
          icon: Icons.stop_rounded,
          size: 22,
          tooltip: 'Stop',
          isDark: isDark,
          onTap: () {
            HapticFeedback.mediumImpact();
            player.stop();
          },
        ),
        const SizedBox(width: 16),

        // MAIN PLAY / PAUSE BUTTON (HERO)
        GestureDetector(
          onTap: () {
            HapticFeedback.heavyImpact();
            if (player.isPlaying) {
              player.pause();
            } else {
              player.play();
            }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  accent,
                  Color.lerp(accent, Colors.black, 0.25)!,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.5),
                  blurRadius: 22,
                  spreadRadius: player.isPlaying ? 4 : 1,
                ),
              ],
            ),
            child: Center(
              child: player.isLoading
                  ? const SizedBox(
                      width: 26,
                      height: 26,
                      child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.black),
                    )
                  : Icon(
                      player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      size: 38,
                      color: Colors.black,
                    ),
            ),
          ),
        ),
        const SizedBox(width: 16),

        // Skip +5s
        _DeckIconButton(
          icon: Icons.forward_5_rounded,
          size: 22,
          tooltip: 'Forward 5s',
          isDark: isDark,
          onTap: () {
            HapticFeedback.lightImpact();
            player.skip(5);
          },
        ),
        const SizedBox(width: 14),

        // Mute / Unmute
        _DeckIconButton(
          icon: player.isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
          size: 22,
          tooltip: player.isMuted ? 'Unmute' : 'Mute',
          color: player.isMuted ? const Color(0xFFEF4444) : null,
          isDark: isDark,
          onTap: () {
            HapticFeedback.selectionClick();
            player.toggleMute();
          },
        ),
      ],
    );
  }
}

class _DeckIconButton extends StatelessWidget {
  final IconData icon;
  final double size;
  final String tooltip;
  final bool isDark;
  final Color? color;
  final VoidCallback onTap;

  const _DeckIconButton({
    required this.icon,
    required this.size,
    required this.tooltip,
    required this.isDark,
    this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isDark ? Colors.white10 : const Color(0xFFE2E8F0),
            ),
          ),
          child: Center(
            child: Icon(
              icon,
              size: size,
              color: color ?? (isDark ? Colors.white70 : const Color(0xFF475569)),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// 5. VOICE & SPEED PRESET SELECTOR
// ============================================================================
class VoiceAndSpeedSelector extends StatelessWidget {
  final HighQualityTextAudioPlayerState player;
  final bool isDark;

  const VoiceAndSpeedSelector({
    super.key,
    required this.player,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final Color accent = player.selectedVoice.accentColor;
    final List<double> speeds = [0.75, 1.0, 1.25, 1.5, 2.0];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Speed Selector
        Text(
          'PLAYBACK CADENCE & SPEED',
          style: GoogleFonts.sora(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: speeds.map((s) {
            final bool isSelected = player.playbackSpeed == s;
            return GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                player.setSpeed(s);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected
                      ? accent
                      : (isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9)),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: isSelected
                      ? [BoxShadow(color: accent.withOpacity(0.4), blurRadius: 8)]
                      : null,
                ),
                child: Text(
                  '${s}x',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: isSelected ? Colors.black : (isDark ? Colors.white70 : const Color(0xFF475569)),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 18),

        // Voice Engine Profiles
        Text(
          'NEURAL VOICE ENGINE',
          style: GoogleFonts.sora(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 10),
        Column(
          children: HighQualityTextAudioPlayerState.availableVoices.map((voice) {
            final bool isSelected = player.selectedVoice.id == voice.id;

            return GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                player.setVoice(voice);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isSelected
                      ? voice.accentColor.withOpacity(0.14)
                      : (isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC)),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isSelected ? voice.accentColor : (isDark ? Colors.white10 : const Color(0xFFE2E8F0)),
                    width: isSelected ? 1.6 : 1.0,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: voice.accentColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(voice.icon, color: voice.accentColor, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                voice.name,
                                style: GoogleFonts.sora(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w800,
                                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                                decoration: BoxDecoration(
                                  color: voice.accentColor.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  voice.tag,
                                  style: GoogleFonts.sora(
                                    fontSize: 8.5,
                                    fontWeight: FontWeight.w900,
                                    color: voice.accentColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            voice.description,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 11,
                              color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (isSelected)
                      Icon(Icons.check_circle_rounded, color: voice.accentColor, size: 20),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}

// ============================================================================
// 6. DASHBOARD TEXT AUDIO CARD (VIP PREDICTION INTEGRATION)
// ============================================================================
class DashboardTextAudioCard extends StatelessWidget {
  final bool isDark;
  final VoidCallback onOpenStudio;

  const DashboardTextAudioCard({
    super.key,
    required this.isDark,
    required this.onOpenStudio,
  });

  @override
  Widget build(BuildContext context) {
    final HighQualityTextAudioPlayerState player = GlobalTextAudioPlayer.getInstance();

    return ListenableBuilder(
      listenable: player,
      builder: (context, _) {
        final Color accent = player.selectedVoice.accentColor;

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF0C1322).withOpacity(0.92) : Colors.white,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: accent.withOpacity(0.4),
              width: 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.14),
                blurRadius: 22,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Row
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.record_voice_over_rounded, color: accent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              'AI TEXT AUDIO PLAYER',
                              style: GoogleFonts.sora(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                color: isDark ? Colors.white : const Color(0xFF0F172A),
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                              decoration: BoxDecoration(
                                color: (player.isPlaying ? accent : const Color(0xFF64748B)).withOpacity(0.2),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                player.isPlaying ? 'PLAYING' : (player.isPaused ? 'PAUSED' : 'READY'),
                                style: GoogleFonts.sora(
                                  fontSize: 8.5,
                                  fontWeight: FontWeight.w900,
                                  color: player.isPlaying ? accent : const Color(0xFF94A3B8),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${player.selectedVoice.name} • ${player.totalWords} words • Lossless AI Audio',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 11,
                            color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.open_in_full_rounded, size: 18, color: accent),
                    tooltip: 'Open Audio Studio',
                    onPressed: onOpenStudio,
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // Equalizer Wave
              TextAudioEqualizerWave(
                isPlaying: player.isPlaying,
                primaryColor: accent,
                secondaryColor: const Color(0xFF00E5FF),
                height: 32,
                barCount: 26,
              ),
              const SizedBox(height: 12),

              // Text Snip Preview
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isDark ? Colors.black.withOpacity(0.35) : const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  player.currentText,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11.5,
                    fontStyle: FontStyle.italic,
                    color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF475569),
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Bottom Control Strip
              Row(
                children: [
                  // Play / Pause Mini Button
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.heavyImpact();
                      if (player.isPlaying) {
                        player.pause();
                      } else {
                        player.play();
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                      decoration: BoxDecoration(
                        color: accent,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: accent.withOpacity(0.35),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Icon(
                            player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            size: 16,
                            color: Colors.black,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            player.isPlaying ? 'PAUSE' : 'PLAY AUDIO',
                            style: GoogleFonts.sora(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),

                  // Stop
                  IconButton(
                    icon: const Icon(Icons.stop_rounded, size: 18),
                    onPressed: () {
                      HapticFeedback.lightImpact();
                      player.stop();
                    },
                  ),

                  // Mute
                  IconButton(
                    icon: Icon(
                      player.isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                      size: 18,
                      color: player.isMuted ? const Color(0xFFEF4444) : null,
                    ),
                    onPressed: () {
                      HapticFeedback.selectionClick();
                      player.toggleMute();
                    },
                  ),

                  const Spacer(),

                  // Full Studio Link
                  TextButton.icon(
                    onPressed: onOpenStudio,
                    icon: Icon(Icons.tune_rounded, size: 14, color: accent),
                    label: Text(
                      'STUDIO',
                      style: GoogleFonts.sora(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: accent,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

// ============================================================================
// 7. FULL AUDIO STUDIO MODAL / SCREEN
// ============================================================================
class FullTextAudioStudioModal extends StatefulWidget {
  final bool isDark;
  final void Function(String title, String description, String threatCode)? onApiFailure;

  const FullTextAudioStudioModal({
    super.key,
    required this.isDark,
    this.onApiFailure,
  });

  @override
  State<FullTextAudioStudioModal> createState() => _FullTextAudioStudioModalState();
}

class _FullTextAudioStudioModalState extends State<FullTextAudioStudioModal>
    with SingleTickerProviderStateMixin {
  late final TextEditingController _textCtrl;
  int _selectedTab = 0; // 0: Presets, 1: Custom Text

  @override
  void initState() {
    super.initState();
    final player = GlobalTextAudioPlayer.getInstance(onApiFailure: widget.onApiFailure);
    _textCtrl = TextEditingController(text: player.currentText);
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final HighQualityTextAudioPlayerState player =
        GlobalTextAudioPlayer.getInstance(onApiFailure: widget.onApiFailure);

    return ListenableBuilder(
      listenable: player,
      builder: (context, _) {
        final Color accent = player.selectedVoice.accentColor;

        return Container(
          height: MediaQuery.of(context).size.height * 0.92,
          decoration: BoxDecoration(
            color: widget.isDark ? const Color(0xFF070B14) : Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: accent.withOpacity(0.3), width: 1.5),
          ),
          child: Column(
            children: [
              // Top Drag Handle & Title
              Container(
                padding: const EdgeInsets.fromLTRB(20, 12, 12, 10),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: widget.isDark ? Colors.white10 : const Color(0xFFE2E8F0),
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    Center(
                      child: Container(
                        width: 44,
                        height: 4.5,
                        decoration: BoxDecoration(
                          color: widget.isDark ? Colors.white24 : const Color(0xFFCBD5E1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: accent.withOpacity(0.18),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.spatial_audio_rounded, color: accent, size: 20),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'AI AUDIO STUDIO PRO',
                                style: GoogleFonts.sora(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  color: widget.isDark ? Colors.white : const Color(0xFF0F172A),
                                  letterSpacing: 0.8,
                                ),
                              ),
                              Text(
                                'HD Telemetry & Speech Synthesis Engine',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 11,
                                  color: widget.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Body Content
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Equalizer Visualizer Strip
                      TextAudioEqualizerWave(
                        isPlaying: player.isPlaying,
                        primaryColor: accent,
                        secondaryColor: const Color(0xFF00E5FF),
                        height: 48,
                        barCount: 32,
                      ),
                      const SizedBox(height: 16),

                      // Karaoke Synchronized Text Display
                      KaraokeTextReader(
                        player: player,
                        isDark: widget.isDark,
                      ),
                      const SizedBox(height: 14),

                      // Audio Scrubber & Timeline
                      AudioTimelineScrubber(
                        player: player,
                        isDark: widget.isDark,
                      ),
                      const SizedBox(height: 14),

                      // Playback Control Deck
                      PlaybackControlDeck(
                        player: player,
                        isDark: widget.isDark,
                      ),
                      const SizedBox(height: 20),

                      // Speed & Voice Engine
                      VoiceAndSpeedSelector(
                        player: player,
                        isDark: widget.isDark,
                      ),
                      const SizedBox(height: 24),

                      // Tab selector: Presets vs Custom
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: widget.isDark ? Colors.white.withOpacity(0.06) : const Color(0xFFF1F5F9),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () => setState(() => _selectedTab = 0),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  decoration: BoxDecoration(
                                    color: _selectedTab == 0
                                        ? (widget.isDark ? const Color(0xFF1E293B) : Colors.white)
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: _selectedTab == 0
                                        ? [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4)]
                                        : null,
                                  ),
                                  child: Text(
                                    'VIP PRESETS',
                                    textAlign: TextAlign.center,
                                    style: GoogleFonts.sora(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                      color: _selectedTab == 0
                                          ? accent
                                          : (widget.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B)),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: () => setState(() => _selectedTab = 1),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  decoration: BoxDecoration(
                                    color: _selectedTab == 1
                                        ? (widget.isDark ? const Color(0xFF1E293B) : Colors.white)
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: _selectedTab == 1
                                        ? [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4)]
                                        : null,
                                  ),
                                  child: Text(
                                    'CUSTOM TEXT STUDIO',
                                    textAlign: TextAlign.center,
                                    style: GoogleFonts.sora(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                      color: _selectedTab == 1
                                          ? accent
                                          : (widget.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B)),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Presets List or Custom Input
                      if (_selectedTab == 0) ...[
                        Column(
                          children: HighQualityTextAudioPlayerState.presets.map((p) {
                            final bool isCurrent = player.currentText == p.content;

                            return GestureDetector(
                              onTap: () {
                                HapticFeedback.selectionClick();
                                player.setText(p.content);
                                _textCtrl.text = p.content;
                              },
                              child: Container(
                                width: double.infinity,
                                margin: const EdgeInsets.only(bottom: 10),
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: isCurrent
                                      ? accent.withOpacity(0.12)
                                      : (widget.isDark ? Colors.white.withOpacity(0.04) : const Color(0xFFF8FAFC)),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: isCurrent ? accent : (widget.isDark ? Colors.white12 : const Color(0xFFE2E8F0)),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(p.icon, size: 20, color: isCurrent ? accent : const Color(0xFF64748B)),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                p.title,
                                                style: GoogleFonts.sora(
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w800,
                                                  color: widget.isDark ? Colors.white : const Color(0xFF0F172A),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                                                decoration: BoxDecoration(
                                                  color: accent.withOpacity(0.15),
                                                  borderRadius: BorderRadius.circular(6),
                                                ),
                                                child: Text(
                                                  p.category,
                                                  style: GoogleFonts.sora(
                                                    fontSize: 8.5,
                                                    fontWeight: FontWeight.w900,
                                                    color: accent,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            p.content,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.plusJakartaSans(
                                              fontSize: 11,
                                              color: widget.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (isCurrent)
                                      Icon(Icons.check_circle_rounded, color: accent, size: 18),
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ] else ...[
                        // Custom Input Field
                        TextField(
                          controller: _textCtrl,
                          maxLines: 4,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13.5,
                            color: widget.isDark ? Colors.white : const Color(0xFF0F172A),
                          ),
                          decoration: InputDecoration(
                            hintText: 'Type or paste custom text in Hindi or English to synthesize into high quality audio...',
                            hintStyle: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              color: widget.isDark ? Colors.white30 : const Color(0xFF94A3B8),
                            ),
                            filled: true,
                            fillColor: widget.isDark ? Colors.white.withOpacity(0.05) : const Color(0xFFF8FAFC),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(
                                color: widget.isDark ? Colors.white12 : const Color(0xFFE2E8F0),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(color: accent, width: 1.5),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            TextButton.icon(
                              onPressed: () async {
                                final data = await Clipboard.getData(Clipboard.kTextPlain);
                                if (data?.text != null && data!.text!.isNotEmpty) {
                                  _textCtrl.text = data.text!;
                                  player.setText(data.text!);
                                }
                              },
                              icon: const Icon(Icons.content_paste_rounded, size: 16),
                              label: const Text('PASTE'),
                            ),
                            TextButton.icon(
                              onPressed: () {
                                _textCtrl.clear();
                                player.setText('');
                              },
                              icon: const Icon(Icons.clear_all_rounded, size: 16),
                              label: const Text('CLEAR'),
                            ),
                            const Spacer(),
                            ElevatedButton(
                              onPressed: () {
                                player.setText(_textCtrl.text);
                                player.play();
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accent,
                                foregroundColor: Colors.black,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              child: const Text('APPLY & PLAY'),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 24),

                      // VIP AUDIO STUDIO HD STATUS CARD
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: (widget.isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.08),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: (widget.isDark ? const Color(0xFF00FF87) : const Color(0xFF059669)).withOpacity(0.25),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.verified_rounded,
                              color: widget.isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                              size: 24,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'OFFLINE HD SPEECH ENGINE',
                                    style: GoogleFonts.sora(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      color: widget.isDark ? const Color(0xFF00FF87) : const Color(0xFF059669),
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    'Real-time pure waveform synthesis active. 100% offline, zero network latency.',
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 11,
                                      color: widget.isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}