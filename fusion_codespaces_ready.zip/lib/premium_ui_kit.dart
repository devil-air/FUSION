import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// ==============================================================================
/// 💎 FUSION 4.0 VIP - HD VIEW UI KIT & PREMIUM REAL-TIME ANIMATIONS
/// Balanced Typography, Glassmorphism, Micro-Interactions, Toasts & Alert Dialogs
/// ==============================================================================

class PremiumTheme {
  static const Color primaryNeon = Color(0xFF00FF87);
  static const Color secondaryCyan = Color(0xFF00E5FF);
  static const Color dangerRose = Color(0xFFEF4444);
  static const Color warningAmber = Color(0xFFF59E0B);
  static const Color cardDark = Color(0xDC0B142B);
  static const Color surfaceDark = Color(0xFF070B14);
}

/// ---------------------------------------------------------------------------
/// 1. REAL-TIME PULSING LIVE STATUS BADGE (60 / 90 FPS)
/// ---------------------------------------------------------------------------
class PulsingStatusBadge extends StatefulWidget {
  final String label;
  final int latencyMs;
  final bool isOnline;

  const PulsingStatusBadge({
    super.key,
    required this.label,
    required this.latencyMs,
    this.isOnline = true,
  });

  @override
  State<PulsingStatusBadge> createState() => _PulsingStatusBadgeState();
}

class _PulsingStatusBadgeState extends State<PulsingStatusBadge>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  late final Animation<double> _pulseScale;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _pulseScale = Tween<double>(begin: 0.85, end: 1.25).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Color get _statusColor {
    if (!widget.isOnline) return PremiumTheme.dangerRose;
    if (widget.latencyMs <= 60) return PremiumTheme.primaryNeon;
    if (widget.latencyMs <= 120) return PremiumTheme.secondaryCyan;
    return PremiumTheme.warningAmber;
  }

  @override
  Widget build(BuildContext context) {
    final Color color = _statusColor;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.35), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _pulseScale,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseScale.value,
                child: Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: color.withValues(alpha: 0.6),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 7),
          Text(
            widget.label.toUpperCase(),
            style: GoogleFonts.sora(
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.6,
              color: color,
            ),
          ),
          const SizedBox(width: 5),
          Text(
            '${widget.latencyMs}ms',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// 2. CYBER ANIMATED ROTATING BORDER CONTAINER (HD GLASSMORPHISM)
/// ---------------------------------------------------------------------------
class CyberBorderCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  const CyberBorderCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.onTap,
  });

  @override
  State<CyberBorderCard> createState() => _CyberBorderCardState();
}

class _CyberBorderCardState extends State<CyberBorderCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _borderController;

  @override
  void initState() {
    super.initState();
    _borderController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _borderController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap?.call();
      },
      child: AnimatedBuilder(
        animation: _borderController,
        builder: (context, child) {
          return CustomPaint(
            painter: _CyberRotatingBorderPainter(progress: _borderController.value),
            child: Container(
              padding: widget.padding,
              decoration: BoxDecoration(
                color: PremiumTheme.cardDark,
                borderRadius: BorderRadius.circular(16),
              ),
              child: widget.child,
            ),
          );
        },
      ),
    );
  }
}

class _CyberRotatingBorderPainter extends CustomPainter {
  final double progress;
  _CyberRotatingBorderPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect rrect = RRect.fromRectAndRadius(rect, const Radius.circular(16));

    final Paint borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..shader = SweepGradient(
        center: Alignment.center,
        startAngle: 0.0,
        endAngle: 3.14159 * 2,
        transform: GradientRotation(progress * 3.14159 * 2),
        colors: const [
          Color(0xFF00FF87),
          Color(0xFF00E5FF),
          Color(0x2200E5FF),
          Color(0x2200FF87),
          Color(0xFF00FF87),
        ],
        stops: const [0.0, 0.35, 0.5, 0.85, 1.0],
      ).createShader(rect);

    canvas.drawRRect(rrect, borderPaint);
  }

  @override
  bool shouldRepaint(covariant _CyberRotatingBorderPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

/// ---------------------------------------------------------------------------
/// 3. PREMIUM FLOATING TOAST (Balanced Micro-Text & Glow Effects)
/// ---------------------------------------------------------------------------
enum ToastType { success, warning, error, info }

class PremiumToast {
  static void show(
    BuildContext context, {
    required String message,
    String? subMessage,
    ToastType type = ToastType.success,
    Duration duration = const Duration(seconds: 3),
  }) {
    HapticFeedback.mediumImpact();
    final OverlayState? overlay = Overlay.of(context);
    if (overlay == null) return;

    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (context) => _ToastWidget(
        message: message,
        subMessage: subMessage,
        type: type,
        onDismiss: () => entry.remove(),
        duration: duration,
      ),
    );

    overlay.insert(entry);
  }
}

class _ToastWidget extends StatefulWidget {
  final String message;
  final String? subMessage;
  final ToastType type;
  final VoidCallback onDismiss;
  final Duration duration;

  const _ToastWidget({
    required this.message,
    this.subMessage,
    required this.type,
    required this.onDismiss,
    required this.duration,
  });

  @override
  State<_ToastWidget> createState() => _ToastWidgetState();
}

class _ToastWidgetState extends State<_ToastWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _slideAnim;
  late final Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    );

    _slideAnim = Tween<double>(begin: -40, end: 0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack),
    );

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(_ctrl);

    _ctrl.forward();

    Future.delayed(widget.duration, () async {
      if (mounted) {
        await _ctrl.reverse();
        widget.onDismiss();
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Color get _accentColor {
    switch (widget.type) {
      case ToastType.success: return PremiumTheme.primaryNeon;
      case ToastType.warning: return PremiumTheme.warningAmber;
      case ToastType.error: return PremiumTheme.dangerRose;
      case ToastType.info: return PremiumTheme.secondaryCyan;
    }
  }

  IconData get _icon {
    switch (widget.type) {
      case ToastType.success: return Icons.check_circle_rounded;
      case ToastType.warning: return Icons.warning_amber_rounded;
      case ToastType.error: return Icons.gpp_bad_rounded;
      case ToastType.info: return Icons.info_outline_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color color = _accentColor;
    return SafeArea(
      child: Align(
        alignment: Alignment.topCenter,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, _slideAnim.value),
              child: Opacity(
                opacity: _fadeAnim.value.clamp(0.0, 1.0),
                child: Material(
                  color: Colors.transparent,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xF2090E1A),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: color.withValues(alpha: 0.5), width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: color.withValues(alpha: 0.2),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(_icon, color: color, size: 18),
                        ),
                        const SizedBox(width: 10),
                        Flexible(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.message,
                                style: GoogleFonts.sora(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                              if (widget.subMessage != null) ...[
                                const SizedBox(height: 2),
                                Text(
                                  widget.subMessage!,
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w500,
                                    color: const Color(0xFF94A3B8),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// 4. PREMIUM HD ALERT DIALOG (Clear Glassmorphism & High-Definition Action Buttons)
/// ---------------------------------------------------------------------------
class PremiumAlertDialog extends StatelessWidget {
  final String title;
  final String description;
  final String? codeTag;
  final IconData icon;
  final Color accentColor;
  final String primaryBtnText;
  final VoidCallback onPrimaryPressed;
  final String? secondaryBtnText;
  final VoidCallback? onSecondaryPressed;

  const PremiumAlertDialog({
    super.key,
    required this.title,
    required this.description,
    this.codeTag,
    this.icon = Icons.security_rounded,
    this.accentColor = PremiumTheme.primaryNeon,
    required this.primaryBtnText,
    required this.onPrimaryPressed,
    this.secondaryBtnText,
    this.onSecondaryPressed,
  });

  static Future<T?> show<T>({
    required BuildContext context,
    required String title,
    required String description,
    String? codeTag,
    IconData icon = Icons.security_rounded,
    Color accentColor = PremiumTheme.primaryNeon,
    required String primaryBtnText,
    required VoidCallback onPrimaryPressed,
    String? secondaryBtnText,
    VoidCallback? onSecondaryPressed,
    bool barrierDismissible = false,
  }) {
    HapticFeedback.heavyImpact();
    return showDialog<T>(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: PremiumAlertDialog(
          title: title,
          description: description,
          codeTag: codeTag,
          icon: icon,
          accentColor: accentColor,
          primaryBtnText: primaryBtnText,
          onPrimaryPressed: onPrimaryPressed,
          secondaryBtnText: secondaryBtnText,
          onSecondaryPressed: onSecondaryPressed,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 380),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: const Color(0xF50D1527),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: accentColor.withValues(alpha: 0.4), width: 1.4),
          boxShadow: [
            BoxShadow(
              color: accentColor.withValues(alpha: 0.18),
              blurRadius: 30,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: accentColor.withValues(alpha: 0.14),
                shape: BoxShape.circle,
                border: Border.all(color: accentColor.withValues(alpha: 0.35), width: 1.2),
              ),
              child: Icon(icon, color: accentColor, size: 28),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: GoogleFonts.sora(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.4,
                color: Colors.white,
              ),
            ),
            if (codeTag != null) ...[
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  codeTag!,
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: accentColor,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Text(
              description,
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF94A3B8),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                if (secondaryBtnText != null) ...[
                  Expanded(
                    child: TextButton(
                      onPressed: onSecondaryPressed,
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        secondaryBtnText!,
                        style: GoogleFonts.sora(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF94A3B8),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: ElevatedButton(
                    onPressed: onPrimaryPressed,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentColor,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      primaryBtnText,
                      style: GoogleFonts.sora(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// ==============================================================================
/// 👑 ULTRA VIP REAL-TIME 90/120 FPS ANIMATED COMPONENTS
/// ==============================================================================

/// ---------------------------------------------------------------------------
/// 5. ULTRA VIP 3D GYROSCOPIC TILT CARD WITH DYNAMIC SPECULAR HIGHLIGHT
/// ---------------------------------------------------------------------------
class UltraVipTiltCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final VoidCallback? onTap;
  final Color glowColor;
  final Color secondaryColor;
  final double maxTiltAngle;

  const UltraVipTiltCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.borderRadius = 22,
    this.onTap,
    this.glowColor = PremiumTheme.primaryNeon,
    this.secondaryColor = PremiumTheme.secondaryCyan,
    this.maxTiltAngle = 0.16,
  });

  @override
  State<UltraVipTiltCard> createState() => _UltraVipTiltCardState();
}

class _UltraVipTiltCardState extends State<UltraVipTiltCard>
    with TickerProviderStateMixin {
  late final AnimationController _resetController;
  late final AnimationController _borderRotateController;
  late Animation<Offset> _tiltAnim;
  Offset _currentTilt = Offset.zero;
  bool _isInteracting = false;

  @override
  void initState() {
    super.initState();
    _resetController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _borderRotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();

    _tiltAnim = Tween<Offset>(begin: Offset.zero, end: Offset.zero).animate(
      CurvedAnimation(parent: _resetController, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    _resetController.dispose();
    _borderRotateController.dispose();
    super.dispose();
  }

  void _onPanUpdate(DragUpdateDetails details, Size size) {
    if (size.width == 0 || size.height == 0) return;
    final double normX = (details.localPosition.dx / size.width - 0.5) * 2;
    final double normY = (details.localPosition.dy / size.height - 0.5) * 2;
    setState(() {
      _currentTilt = Offset(
        normX.clamp(-1.0, 1.0),
        normY.clamp(-1.0, 1.0),
      );
      _isInteracting = true;
    });
  }

  void _onPanEnd(DragEndDetails details) {
    _tiltAnim = Tween<Offset>(begin: _currentTilt, end: Offset.zero).animate(
      CurvedAnimation(parent: _resetController, curve: Curves.easeOutBack),
    )..addListener(() {
        if (mounted) setState(() => _currentTilt = _tiltAnim.value);
      });
    _resetController.forward(from: 0.0).then((_) {
      if (mounted) setState(() => _isInteracting = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final double rotX = -_currentTilt.dy * widget.maxTiltAngle;
    final double rotY = _currentTilt.dx * widget.maxTiltAngle;
    final double scale = _isInteracting ? 0.98 : 1.0;

    return LayoutBuilder(
      builder: (context, constraints) {
        final Size size = constraints.biggest;
        final Matrix4 transform = Matrix4.identity()
          ..setEntry(3, 2, 0.0014)
          ..rotateX(rotX)
          ..rotateY(rotY)
          ..scale(scale);

        return GestureDetector(
          onTap: () {
            HapticFeedback.mediumImpact();
            widget.onTap?.call();
          },
          onPanDown: (_) => HapticFeedback.selectionClick(),
          onPanUpdate: (d) => _onPanUpdate(d, size),
          onPanEnd: _onPanEnd,
          onPanCancel: () => _onPanEnd(DragEndDetails()),
          child: RepaintBoundary(
            child: Transform(
              transform: transform,
              alignment: FractionalOffset.center,
              child: Stack(
                children: [
                  // Rotating Dual-Chroma Neon Glowing Outer Border
                  AnimatedBuilder(
                    animation: _borderRotateController,
                    builder: (context, child) {
                      return CustomPaint(
                        painter: _UltraRotatingBorderPainter(
                          progress: _borderRotateController.value,
                          glowColor: widget.glowColor,
                          secondaryColor: widget.secondaryColor,
                          borderRadius: widget.borderRadius,
                        ),
                        child: Container(
                          padding: widget.padding,
                          decoration: BoxDecoration(
                            color: PremiumTheme.cardDark,
                            borderRadius: BorderRadius.circular(widget.borderRadius),
                            boxShadow: [
                              BoxShadow(
                                color: widget.glowColor.withValues(alpha: _isInteracting ? 0.28 : 0.15),
                                blurRadius: _isInteracting ? 28 : 18,
                                spreadRadius: 1,
                                offset: Offset(rotY * 20, -rotX * 20),
                              ),
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.65),
                                blurRadius: 16,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: widget.child,
                        ),
                      );
                    },
                  ),

                  // Dynamic Specular Light Glare Sheen
                  Positioned.fill(
                    child: IgnorePointer(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(widget.borderRadius),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 60),
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              center: Alignment(_currentTilt.dx * 0.8, _currentTilt.dy * 0.8),
                              radius: 1.1,
                              colors: [
                                Colors.white.withValues(alpha: _isInteracting ? 0.14 : 0.05),
                                Colors.white.withValues(alpha: 0.0),
                              ],
                              stops: const [0.0, 0.75],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _UltraRotatingBorderPainter extends CustomPainter {
  final double progress;
  final Color glowColor;
  final Color secondaryColor;
  final double borderRadius;

  _UltraRotatingBorderPainter({
    required this.progress,
    required this.glowColor,
    required this.secondaryColor,
    required this.borderRadius,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect rrect = RRect.fromRectAndRadius(rect, Radius.circular(borderRadius));

    final Paint borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..shader = SweepGradient(
        center: Alignment.center,
        startAngle: 0.0,
        endAngle: math.pi * 2,
        transform: GradientRotation(progress * math.pi * 2),
        colors: [
          glowColor,
          secondaryColor,
          const Color(0xFF9D00FF),
          glowColor.withValues(alpha: 0.2),
          glowColor,
        ],
        stops: const [0.0, 0.35, 0.7, 0.88, 1.0],
      ).createShader(rect);

    canvas.drawRRect(rrect, borderPaint);
  }

  @override
  bool shouldRepaint(covariant _UltraRotatingBorderPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

/// ---------------------------------------------------------------------------
/// 6. ULTRA VIP REAL-TIME LIVE MARQUEE TICKER (120 FPS SMOOTH)
/// ---------------------------------------------------------------------------
class UltraVipMarqueeTicker extends StatefulWidget {
  final String text;
  final String badgeText;
  final Color accentColor;
  final double height;
  final double velocity; // pixels per second

  const UltraVipMarqueeTicker({
    super.key,
    required this.text,
    this.badgeText = 'VIP LIVE',
    this.accentColor = PremiumTheme.primaryNeon,
    this.height = 36,
    this.velocity = 45.0,
  });

  @override
  State<UltraVipMarqueeTicker> createState() => _UltraVipMarqueeTickerState();
}

class _UltraVipMarqueeTickerState extends State<UltraVipMarqueeTicker>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      decoration: BoxDecoration(
        color: const Color(0xF2070D1A),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: widget.accentColor.withValues(alpha: 0.3), width: 1.0),
        boxShadow: [
          BoxShadow(
            color: widget.accentColor.withValues(alpha: 0.08),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Row(
          children: [
            // Fixed Live Badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: widget.accentColor.withValues(alpha: 0.16),
                border: Border(
                  right: BorderSide(
                    color: widget.accentColor.withValues(alpha: 0.35),
                    width: 1,
                  ),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: widget.accentColor,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: widget.accentColor,
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    widget.badgeText,
                    style: GoogleFonts.sora(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                      color: widget.accentColor,
                    ),
                  ),
                ],
              ),
            ),

            // Continuous Smooth Marquee Area
            Expanded(
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return LayoutBuilder(
                    builder: (context, constraints) {
                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        physics: const NeverScrollableScrollPhysics(),
                        child: Transform.translate(
                          offset: Offset(-(_controller.value * 600) % 600, 0),
                          child: Row(
                            children: [
                              _buildTickerContent(),
                              const SizedBox(width: 60),
                              _buildTickerContent(),
                              const SizedBox(width: 60),
                              _buildTickerContent(),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTickerContent() {
    return Text(
      widget.text,
      style: GoogleFonts.jetBrainsMono(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: Colors.white.withValues(alpha: 0.9),
        letterSpacing: 0.5,
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// 7. ULTRA VIP REAL-TIME CONCENTRIC RADAR RIPPLE WAVE
/// ---------------------------------------------------------------------------
class UltraVipRadarWave extends StatefulWidget {
  final double size;
  final Color color;
  final int latencyMs;
  final String statusText;

  const UltraVipRadarWave({
    super.key,
    this.size = 110,
    this.color = PremiumTheme.primaryNeon,
    this.latencyMs = 24,
    this.statusText = 'ONLINE',
  });

  @override
  State<UltraVipRadarWave> createState() => _UltraVipRadarWaveState();
}

class _UltraVipRadarWaveState extends State<UltraVipRadarWave>
    with SingleTickerProviderStateMixin {
  late final AnimationController _waveController;

  @override
  void initState() {
    super.initState();
    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();
  }

  @override
  void dispose() {
    _waveController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: AnimatedBuilder(
          animation: _waveController,
          builder: (context, child) {
            return CustomPaint(
              painter: _RadarWavePainter(
                progress: _waveController.value,
                color: widget.color,
              ),
              child: Center(
                child: Container(
                  width: widget.size * 0.42,
                  height: widget.size * 0.42,
                  decoration: BoxDecoration(
                    color: const Color(0xF207101E),
                    shape: BoxShape.circle,
                    border: Border.all(color: widget.color.withValues(alpha: 0.6), width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: widget.color.withValues(alpha: 0.35),
                        blurRadius: 14,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${widget.latencyMs}ms',
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          color: widget.color,
                        ),
                      ),
                      Text(
                        widget.statusText,
                        style: GoogleFonts.sora(
                          fontSize: 7.5,
                          fontWeight: FontWeight.w800,
                          color: Colors.white70,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _RadarWavePainter extends CustomPainter {
  final double progress;
  final Color color;

  _RadarWavePainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final double maxRadius = size.width / 2;

    for (int i = 0; i < 3; i++) {
      final double ringProgress = (progress + (i * 0.33)) % 1.0;
      final double radius = maxRadius * ringProgress;
      final double opacity = (1.0 - ringProgress).clamp(0.0, 1.0) * 0.65;

      final Paint wavePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = color.withValues(alpha: opacity);

      canvas.drawCircle(center, radius, wavePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RadarWavePainter oldDelegate) =>
      oldDelegate.progress != progress;
}

/// ---------------------------------------------------------------------------
/// 8. ULTRA VIP REMOTE SIGNAL ALERT BANNER
/// ---------------------------------------------------------------------------
class UltraVipSignalBanner extends StatefulWidget {
  final String title;
  final String target;
  final String colorTag;
  final String confidence;
  final int period;
  final VoidCallback? onEngage;

  const UltraVipSignalBanner({
    super.key,
    required this.title,
    required this.target,
    required this.colorTag,
    this.confidence = '99.8%',
    required this.period,
    this.onEngage,
  });

  @override
  State<UltraVipSignalBanner> createState() => _UltraVipSignalBannerState();
}

class _UltraVipSignalBannerState extends State<UltraVipSignalBanner>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  Color get _tagColor {
    final String tag = widget.colorTag.toUpperCase();
    if (tag.contains('GREEN')) return const Color(0xFF00FF87);
    if (tag.contains('RED')) return const Color(0xFFEF4444);
    if (tag.contains('VIOLET')) return const Color(0xFF9D00FF);
    return PremiumTheme.secondaryCyan;
  }

  @override
  Widget build(BuildContext context) {
    final Color color = _tagColor;

    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (context, child) {
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xF20B1528),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: color.withValues(alpha: 0.4 + (_pulseCtrl.value * 0.4)),
              width: 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.15 + (_pulseCtrl.value * 0.2)),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.18),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: color.withValues(alpha: 0.4)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.bolt_rounded, size: 14, color: color),
                            const SizedBox(width: 4),
                            Text(
                              widget.title.toUpperCase(),
                              style: GoogleFonts.sora(
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                color: color,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '#${widget.period}',
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white54,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      'CONFIDENCE ${widget.confidence}',
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w800,
                        color: PremiumTheme.primaryNeon,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'PREDICTED SIGNAL',
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: Colors.white60,
                            letterSpacing: 0.6,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          widget.target,
                          style: GoogleFonts.sora(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      HapticFeedback.heavyImpact();
                      widget.onEngage?.call();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: color,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      'ENGAGE',
                      style: GoogleFonts.sora(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
